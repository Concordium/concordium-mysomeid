/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src-injected/index.ts":
/*!*******************************!*\
  !*** ./src-injected/index.ts ***!
  \*******************************/
/***/ (function() {


var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
console.log("Installing MySoMeId Injected.");
var widgets = {};
var messageContexts = {};
var InjectedMessageHandler = /** @class */ (function () {
    function InjectedMessageHandler() {
        var _this = this;
        this.sendMessageWResponse = function (to, type, payload) { return __awaiter(_this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        _this.sendMessage(to, type, payload).addResolver(resolve);
                    })];
            });
        }); };
        this.onMessage = function (message) {
            var _a, _b, _c;
            // console.log("Injected: onMessage" , msg);
            if (((_a = message === null || message === void 0 ? void 0 : message.data) === null || _a === void 0 ? void 0 : _a.origin) !== 'mysome') {
                return;
            }
            var data = message.data;
            var type = data.type, from = data.from, to = data.to, payload = data.payload;
            console.log("Injected: message ", data);
            if (from === 'injected') { // Dont process message from self!
                return;
            }
            if (to === 'background') {
                console.log("Injected: forwarding message (routing through content) ", data);
                // Route to content in order for content to send to background.
                window.postMessage({
                    to: 'content',
                    type: 'forward',
                    from: 'injected',
                    serial: Math.round(Math.random() * 999999999999),
                    origin: 'mysome',
                    payload: data,
                }, "*");
                return;
            }
            if (to !== 'injected') {
                console.log("Injected: ignored message ", data);
                return;
            }
            if ((type === null || type === void 0 ? void 0 : type.indexOf('-response')) > 0) {
                var handler = messageContexts[data.responseTo];
                if (!handler) {
                    return;
                }
                handler.resolve(data);
                delete messageContexts[data.responseTo]; // free some memory.
                return;
            }
            if (type === 'console.log') {
                console.log.apply(console, __spreadArray([payload.text], ((_b = payload === null || payload === void 0 ? void 0 : payload.more) !== null && _b !== void 0 ? _b : {}), false));
                return;
            }
            else if (type === 'console.error') {
                console.error.apply(console, __spreadArray([payload.text], ((_c = payload === null || payload === void 0 ? void 0 : payload.more) !== null && _c !== void 0 ? _c : {}), false));
                return;
            }
            else if (type === 'redirect') {
                var url = payload.url;
                window.location.href = url;
            }
        };
        console.log("InjectedWidget: subscribe to messages");
        window.addEventListener('message', this.onMessage);
    }
    InjectedMessageHandler.prototype.sendMessage = function (to, type, payload) {
        // When sending a message to the injected-widget we need to use the iframe ANDt he payload needs to contain the id of the iframe.
        var target = window;
        var origin = '*';
        var enc = function (v) { return v; };
        if (to === 'injected-widget') {
            var id = payload.id;
            if (id === undefined && Object.keys(widgets).length > 0) {
                id = Object.keys(widgets)[0];
            }
            var iframe = void 0;
            if (id !== undefined && Number.isFinite(id) && id >= 0 && widgets[id]) {
                iframe = document.getElementById("mysome-frame-iframe-".concat(id));
            }
            if (!iframe) {
                throw new Error('No iframe with id #' + id);
            }
            if (!(iframe === null || iframe === void 0 ? void 0 : iframe.contentWindow)) {
                console.error('No iframe content window for iframe #' + id);
            }
            target = iframe === null || iframe === void 0 ? void 0 : iframe.contentWindow;
            origin = "*";
            enc = function (v) { return JSON.stringify(v); };
        }
        var serial = Math.round(Math.random() * 999999999999999);
        var data = enc({
            to: to,
            type: type,
            from: 'injected',
            serial: serial,
            origin: 'mysome',
            payload: payload,
        });
        // console.log("sending ", data);
        var resolvers = [];
        messageContexts[serial] = {
            addResolver: function (r) { return resolvers.push(r); },
            resolve: function (data) {
                resolvers.forEach(function (r) { return r(data); });
            },
            serial: serial,
        };
        target === null || target === void 0 ? void 0 : target.postMessage(data, origin);
        return messageContexts[serial];
    };
    return InjectedMessageHandler;
}());
var messageHandler = new InjectedMessageHandler();
var createPopup = function () {
    messageHandler.sendMessage("content", "create-popup", {});
};
var createBadge = function () {
    messageHandler.sendMessage("content", "create-badge", {});
};
var createTour = function () {
    messageHandler.sendMessage("content", "create-tour", {});
};
var reloadTabs = function (args) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "reload-tabs", __assign({}, (args !== null && args !== void 0 ? args : {})))];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var updateRegistration = function (state) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!state || typeof state !== 'object') {
                    throw new Error('Invalid state for registration');
                }
                return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "update-registration", {
                        store: 'state',
                        state: state,
                    })];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var getState = function (store) { return __awaiter(void 0, void 0, void 0, function () {
    var response;
    var _a;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { store: store })];
            case 1:
                response = _b.sent();
                return [2 /*return*/, (_a = response === null || response === void 0 ? void 0 : response.store) !== null && _a !== void 0 ? _a : null];
        }
    });
}); };
var getStateValue = function (store, key) { return __awaiter(void 0, void 0, void 0, function () {
    var response;
    var _a, _b;
    return __generator(this, function (_c) {
        switch (_c.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { store: store })];
            case 1:
                response = _c.sent();
                return [2 /*return*/, (_b = (_a = response === null || response === void 0 ? void 0 : response.store) === null || _a === void 0 ? void 0 : _a[key]) !== null && _b !== void 0 ? _b : null];
        }
    });
}); };
var setStateValue = function (store, key, value) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { store: store, key: key, value: value })];
            case 1:
                _a.sent();
                return [2 /*return*/];
        }
    });
}); };
var getPlatformRequests = function () { return __awaiter(void 0, void 0, void 0, function () {
    var response, requests;
    var _a, _b, _c, _d;
    return __generator(this, function (_e) {
        switch (_e.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { store: 'platform-requests' })];
            case 1:
                response = _e.sent();
                requests = (_b = (_a = response === null || response === void 0 ? void 0 : response.store) === null || _a === void 0 ? void 0 : _a.array) !== null && _b !== void 0 ? _b : [];
                console.log("getPlatform requests (state) ", requests);
                return [2 /*return*/, (_d = (_c = requests === null || requests === void 0 ? void 0 : requests.store) === null || _c === void 0 ? void 0 : _c.array) !== null && _d !== void 0 ? _d : []];
        }
    });
}); };
var createPlatformRequest = function (platform, requestType) { return __awaiter(void 0, void 0, void 0, function () {
    var response, value;
    var _a, _b, _c;
    return __generator(this, function (_d) {
        switch (_d.label) {
            case 0: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { store: 'platform-requests' })];
            case 1:
                response = _d.sent();
                console.log("createPlatformRequest requests (before adding) ", (_a = response === null || response === void 0 ? void 0 : response.store) === null || _a === void 0 ? void 0 : _a.array);
                value = __spreadArray(__spreadArray([], ((_c = (_b = response === null || response === void 0 ? void 0 : response.store) === null || _b === void 0 ? void 0 : _b.array) !== null && _c !== void 0 ? _c : []), true), [
                    {
                        id: Math.round(Math.random() * 99999999).toString(),
                        created: new Date().getTime(),
                        platform: platform,
                        requestType: requestType,
                        status: 'created',
                    }
                ], false);
                return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { store: 'platform-requests', key: 'array', value: value })];
            case 2:
                _d.sent();
                return [2 /*return*/];
        }
    });
}); };
var getRegistrations = function () { return __awaiter(void 0, void 0, void 0, function () {
    var state;
    var _a, _b;
    return __generator(this, function (_c) {
        switch (_c.label) {
            case 0:
                console.log("getRegistrations");
                return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { store: 'state' })];
            case 1:
                state = _c.sent();
                console.log("getRegistrations return ", { state: state });
                return [2 /*return*/, (_b = (_a = state === null || state === void 0 ? void 0 : state.state) === null || _a === void 0 ? void 0 : _a['regs']) !== null && _b !== void 0 ? _b : null];
        }
    });
}); };
var MySoMeAPI = /** @class */ (function () {
    function MySoMeAPI() {
        var _this = this;
        this.messageHandler = messageHandler;
        this.createPopup = createPopup;
        this.createBadge = createBadge;
        this.sendMessage = function (to, type, payload) {
            messageHandler.sendMessage(to, type, payload);
        };
        this.sendMessageWResponse = function (to, type, payload) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, messageHandler.sendMessageWResponse(to, type, payload)];
            });
        }); };
        this.updateReg = updateRegistration;
        this.updateRegistration = updateRegistration;
        this.getRegistrations = getRegistrations;
        this.getPlatformRequests = getPlatformRequests;
        this.createPlatformRequest = createPlatformRequest;
        this.getStateValue = getStateValue;
        this.setStateValue = setStateValue;
        this.getState = getState;
        this.reloadTabs = reloadTabs;
    }
    return MySoMeAPI;
}());
window.mysome = new MySoMeAPI();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src-injected/index.ts"]();
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBLGlEQUFpRCxPQUFPO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QiwrREFBK0QsaUJBQWlCO0FBQzVHO0FBQ0Esb0NBQW9DLE1BQU0sK0JBQStCLFlBQVk7QUFDckYsbUNBQW1DLE1BQU0sbUNBQW1DLFlBQVk7QUFDeEYsZ0NBQWdDO0FBQ2hDO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLDZCQUE2QiwwQkFBMEIsY0FBYyxxQkFBcUI7QUFDeEcsaUJBQWlCLG9EQUFvRCxxRUFBcUUsY0FBYztBQUN4Six1QkFBdUIsc0JBQXNCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QyxtQ0FBbUMsU0FBUztBQUM1QyxtQ0FBbUMsV0FBVyxVQUFVO0FBQ3hELDBDQUEwQyxjQUFjO0FBQ3hEO0FBQ0EsOEdBQThHLE9BQU87QUFDckgsaUZBQWlGLGlCQUFpQjtBQUNsRyx5REFBeUQsZ0JBQWdCLFFBQVE7QUFDakYsK0NBQStDLGdCQUFnQixnQkFBZ0I7QUFDL0U7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBLFVBQVUsWUFBWSxhQUFhLFNBQVMsVUFBVTtBQUN0RCxvQ0FBb0MsU0FBUztBQUM3QztBQUNBO0FBQ0E7QUFDQSw2RUFBNkUsT0FBTztBQUNwRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1FQUFtRTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQixhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlEO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBLG1MQUFtTDtBQUNuTDtBQUNBO0FBQ0E7QUFDQSxxTEFBcUw7QUFDckw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsMkJBQTJCO0FBQ25FO0FBQ0EsaURBQWlELGlCQUFpQjtBQUNsRSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBLDREQUE0RDtBQUM1RDtBQUNBO0FBQ0EsMkRBQTJEO0FBQzNEO0FBQ0EsbUNBQW1DO0FBQ25DO0FBQ0E7QUFDQSxxSEFBcUgsK0NBQStDO0FBQ3BLO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsQ0FBQztBQUNELDRDQUE0QztBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBLEtBQUs7QUFDTCxDQUFDO0FBQ0Qsa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEdBQTBHLGNBQWM7QUFDeEg7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsQ0FBQztBQUNELDRDQUE0QztBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDBHQUEwRyxjQUFjO0FBQ3hIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRCxtREFBbUQ7QUFDbkQ7QUFDQTtBQUNBLDBHQUEwRyxzQ0FBc0M7QUFDaEo7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsQ0FBQztBQUNELHdDQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLDBHQUEwRyw0QkFBNEI7QUFDdEk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRCwrREFBK0Q7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwR0FBMEcsNEJBQTRCO0FBQ3RJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNHQUFzRyx3REFBd0Q7QUFDOUo7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsQ0FBQztBQUNELHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzR0FBc0csZ0JBQWdCO0FBQ3RIO0FBQ0E7QUFDQSwwREFBMEQsY0FBYztBQUN4RTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDs7Ozs7Ozs7VUUvVEE7VUFDQTtVQUNBO1VBQ0E7VUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL215c29tZWlkLy4vc3JjLWluamVjdGVkL2luZGV4LnRzIiwid2VicGFjazovL215c29tZWlkL3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vbXlzb21laWQvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL215c29tZWlkL3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2Fzc2lnbiA9ICh0aGlzICYmIHRoaXMuX19hc3NpZ24pIHx8IGZ1bmN0aW9uICgpIHtcbiAgICBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24odCkge1xuICAgICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpXG4gICAgICAgICAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHQ7XG4gICAgfTtcbiAgICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn07XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcbiAgICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICAgIH1cbn07XG52YXIgX19zcHJlYWRBcnJheSA9ICh0aGlzICYmIHRoaXMuX19zcHJlYWRBcnJheSkgfHwgZnVuY3Rpb24gKHRvLCBmcm9tLCBwYWNrKSB7XG4gICAgaWYgKHBhY2sgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMikgZm9yICh2YXIgaSA9IDAsIGwgPSBmcm9tLmxlbmd0aCwgYXI7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgaWYgKGFyIHx8ICEoaSBpbiBmcm9tKSkge1xuICAgICAgICAgICAgaWYgKCFhcikgYXIgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tLCAwLCBpKTtcbiAgICAgICAgICAgIGFyW2ldID0gZnJvbVtpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcbn07XG5jb25zb2xlLmxvZyhcIkluc3RhbGxpbmcgTXlTb01lSWQgSW5qZWN0ZWQuXCIpO1xudmFyIHdpZGdldHMgPSB7fTtcbnZhciBtZXNzYWdlQ29udGV4dHMgPSB7fTtcbnZhciBJbmplY3RlZE1lc3NhZ2VIYW5kbGVyID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEluamVjdGVkTWVzc2FnZUhhbmRsZXIoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHRoaXMuc2VuZE1lc3NhZ2VXUmVzcG9uc2UgPSBmdW5jdGlvbiAodG8sIHR5cGUsIHBheWxvYWQpIHsgcmV0dXJuIF9fYXdhaXRlcihfdGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnNlbmRNZXNzYWdlKHRvLCB0eXBlLCBwYXlsb2FkKS5hZGRSZXNvbHZlcihyZXNvbHZlKTtcbiAgICAgICAgICAgICAgICAgICAgfSldO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pOyB9O1xuICAgICAgICB0aGlzLm9uTWVzc2FnZSA9IGZ1bmN0aW9uIChtZXNzYWdlKSB7XG4gICAgICAgICAgICB2YXIgX2EsIF9iLCBfYztcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiSW5qZWN0ZWQ6IG9uTWVzc2FnZVwiICwgbXNnKTtcbiAgICAgICAgICAgIGlmICgoKF9hID0gbWVzc2FnZSA9PT0gbnVsbCB8fCBtZXNzYWdlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtZXNzYWdlLmRhdGEpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5vcmlnaW4pICE9PSAnbXlzb21lJykge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBkYXRhID0gbWVzc2FnZS5kYXRhO1xuICAgICAgICAgICAgdmFyIHR5cGUgPSBkYXRhLnR5cGUsIGZyb20gPSBkYXRhLmZyb20sIHRvID0gZGF0YS50bywgcGF5bG9hZCA9IGRhdGEucGF5bG9hZDtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSW5qZWN0ZWQ6IG1lc3NhZ2UgXCIsIGRhdGEpO1xuICAgICAgICAgICAgaWYgKGZyb20gPT09ICdpbmplY3RlZCcpIHsgLy8gRG9udCBwcm9jZXNzIG1lc3NhZ2UgZnJvbSBzZWxmIVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0byA9PT0gJ2JhY2tncm91bmQnKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJJbmplY3RlZDogZm9yd2FyZGluZyBtZXNzYWdlIChyb3V0aW5nIHRocm91Z2ggY29udGVudCkgXCIsIGRhdGEpO1xuICAgICAgICAgICAgICAgIC8vIFJvdXRlIHRvIGNvbnRlbnQgaW4gb3JkZXIgZm9yIGNvbnRlbnQgdG8gc2VuZCB0byBiYWNrZ3JvdW5kLlxuICAgICAgICAgICAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgICAgIHRvOiAnY29udGVudCcsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdmb3J3YXJkJyxcbiAgICAgICAgICAgICAgICAgICAgZnJvbTogJ2luamVjdGVkJyxcbiAgICAgICAgICAgICAgICAgICAgc2VyaWFsOiBNYXRoLnJvdW5kKE1hdGgucmFuZG9tKCkgKiA5OTk5OTk5OTk5OTkpLFxuICAgICAgICAgICAgICAgICAgICBvcmlnaW46ICdteXNvbWUnLFxuICAgICAgICAgICAgICAgICAgICBwYXlsb2FkOiBkYXRhLFxuICAgICAgICAgICAgICAgIH0sIFwiKlwiKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodG8gIT09ICdpbmplY3RlZCcpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkluamVjdGVkOiBpZ25vcmVkIG1lc3NhZ2UgXCIsIGRhdGEpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICgodHlwZSA9PT0gbnVsbCB8fCB0eXBlID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0eXBlLmluZGV4T2YoJy1yZXNwb25zZScpKSA+IDApIHtcbiAgICAgICAgICAgICAgICB2YXIgaGFuZGxlciA9IG1lc3NhZ2VDb250ZXh0c1tkYXRhLnJlc3BvbnNlVG9dO1xuICAgICAgICAgICAgICAgIGlmICghaGFuZGxlcikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGhhbmRsZXIucmVzb2x2ZShkYXRhKTtcbiAgICAgICAgICAgICAgICBkZWxldGUgbWVzc2FnZUNvbnRleHRzW2RhdGEucmVzcG9uc2VUb107IC8vIGZyZWUgc29tZSBtZW1vcnkuXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGUgPT09ICdjb25zb2xlLmxvZycpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZy5hcHBseShjb25zb2xlLCBfX3NwcmVhZEFycmF5KFtwYXlsb2FkLnRleHRdLCAoKF9iID0gcGF5bG9hZCA9PT0gbnVsbCB8fCBwYXlsb2FkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXlsb2FkLm1vcmUpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IHt9KSwgZmFsc2UpKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlID09PSAnY29uc29sZS5lcnJvcicpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yLmFwcGx5KGNvbnNvbGUsIF9fc3ByZWFkQXJyYXkoW3BheWxvYWQudGV4dF0sICgoX2MgPSBwYXlsb2FkID09PSBudWxsIHx8IHBheWxvYWQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHBheWxvYWQubW9yZSkgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDoge30pLCBmYWxzZSkpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGUgPT09ICdyZWRpcmVjdCcpIHtcbiAgICAgICAgICAgICAgICB2YXIgdXJsID0gcGF5bG9hZC51cmw7XG4gICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSB1cmw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnNvbGUubG9nKFwiSW5qZWN0ZWRXaWRnZXQ6IHN1YnNjcmliZSB0byBtZXNzYWdlc1wiKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCB0aGlzLm9uTWVzc2FnZSk7XG4gICAgfVxuICAgIEluamVjdGVkTWVzc2FnZUhhbmRsZXIucHJvdG90eXBlLnNlbmRNZXNzYWdlID0gZnVuY3Rpb24gKHRvLCB0eXBlLCBwYXlsb2FkKSB7XG4gICAgICAgIC8vIFdoZW4gc2VuZGluZyBhIG1lc3NhZ2UgdG8gdGhlIGluamVjdGVkLXdpZGdldCB3ZSBuZWVkIHRvIHVzZSB0aGUgaWZyYW1lIEFORHQgaGUgcGF5bG9hZCBuZWVkcyB0byBjb250YWluIHRoZSBpZCBvZiB0aGUgaWZyYW1lLlxuICAgICAgICB2YXIgdGFyZ2V0ID0gd2luZG93O1xuICAgICAgICB2YXIgb3JpZ2luID0gJyonO1xuICAgICAgICB2YXIgZW5jID0gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHY7IH07XG4gICAgICAgIGlmICh0byA9PT0gJ2luamVjdGVkLXdpZGdldCcpIHtcbiAgICAgICAgICAgIHZhciBpZCA9IHBheWxvYWQuaWQ7XG4gICAgICAgICAgICBpZiAoaWQgPT09IHVuZGVmaW5lZCAmJiBPYmplY3Qua2V5cyh3aWRnZXRzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgaWQgPSBPYmplY3Qua2V5cyh3aWRnZXRzKVswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBpZnJhbWUgPSB2b2lkIDA7XG4gICAgICAgICAgICBpZiAoaWQgIT09IHVuZGVmaW5lZCAmJiBOdW1iZXIuaXNGaW5pdGUoaWQpICYmIGlkID49IDAgJiYgd2lkZ2V0c1tpZF0pIHtcbiAgICAgICAgICAgICAgICBpZnJhbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1mcmFtZS1pZnJhbWUtXCIuY29uY2F0KGlkKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlmcmFtZSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gaWZyYW1lIHdpdGggaWQgIycgKyBpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIShpZnJhbWUgPT09IG51bGwgfHwgaWZyYW1lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBpZnJhbWUuY29udGVudFdpbmRvdykpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdObyBpZnJhbWUgY29udGVudCB3aW5kb3cgZm9yIGlmcmFtZSAjJyArIGlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRhcmdldCA9IGlmcmFtZSA9PT0gbnVsbCB8fCBpZnJhbWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGlmcmFtZS5jb250ZW50V2luZG93O1xuICAgICAgICAgICAgb3JpZ2luID0gXCIqXCI7XG4gICAgICAgICAgICBlbmMgPSBmdW5jdGlvbiAodikgeyByZXR1cm4gSlNPTi5zdHJpbmdpZnkodik7IH07XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHNlcmlhbCA9IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIDk5OTk5OTk5OTk5OTk5OSk7XG4gICAgICAgIHZhciBkYXRhID0gZW5jKHtcbiAgICAgICAgICAgIHRvOiB0byxcbiAgICAgICAgICAgIHR5cGU6IHR5cGUsXG4gICAgICAgICAgICBmcm9tOiAnaW5qZWN0ZWQnLFxuICAgICAgICAgICAgc2VyaWFsOiBzZXJpYWwsXG4gICAgICAgICAgICBvcmlnaW46ICdteXNvbWUnLFxuICAgICAgICAgICAgcGF5bG9hZDogcGF5bG9hZCxcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwic2VuZGluZyBcIiwgZGF0YSk7XG4gICAgICAgIHZhciByZXNvbHZlcnMgPSBbXTtcbiAgICAgICAgbWVzc2FnZUNvbnRleHRzW3NlcmlhbF0gPSB7XG4gICAgICAgICAgICBhZGRSZXNvbHZlcjogZnVuY3Rpb24gKHIpIHsgcmV0dXJuIHJlc29sdmVycy5wdXNoKHIpOyB9LFxuICAgICAgICAgICAgcmVzb2x2ZTogZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlcnMuZm9yRWFjaChmdW5jdGlvbiAocikgeyByZXR1cm4gcihkYXRhKTsgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2VyaWFsOiBzZXJpYWwsXG4gICAgICAgIH07XG4gICAgICAgIHRhcmdldCA9PT0gbnVsbCB8fCB0YXJnZXQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRhcmdldC5wb3N0TWVzc2FnZShkYXRhLCBvcmlnaW4pO1xuICAgICAgICByZXR1cm4gbWVzc2FnZUNvbnRleHRzW3NlcmlhbF07XG4gICAgfTtcbiAgICByZXR1cm4gSW5qZWN0ZWRNZXNzYWdlSGFuZGxlcjtcbn0oKSk7XG52YXIgbWVzc2FnZUhhbmRsZXIgPSBuZXcgSW5qZWN0ZWRNZXNzYWdlSGFuZGxlcigpO1xudmFyIGNyZWF0ZVBvcHVwID0gZnVuY3Rpb24gKCkge1xuICAgIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlKFwiY29udGVudFwiLCBcImNyZWF0ZS1wb3B1cFwiLCB7fSk7XG59O1xudmFyIGNyZWF0ZUJhZGdlID0gZnVuY3Rpb24gKCkge1xuICAgIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlKFwiY29udGVudFwiLCBcImNyZWF0ZS1iYWRnZVwiLCB7fSk7XG59O1xudmFyIGNyZWF0ZVRvdXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2UoXCJjb250ZW50XCIsIFwiY3JlYXRlLXRvdXJcIiwge30pO1xufTtcbnZhciByZWxvYWRUYWJzID0gZnVuY3Rpb24gKGFyZ3MpIHsgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XG4gICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlV1Jlc3BvbnNlKFwiYmFja2dyb3VuZFwiLCBcInJlbG9hZC10YWJzXCIsIF9fYXNzaWduKHt9LCAoYXJncyAhPT0gbnVsbCAmJiBhcmdzICE9PSB2b2lkIDAgPyBhcmdzIDoge30pKSldO1xuICAgICAgICAgICAgY2FzZSAxOiByZXR1cm4gWzIgLypyZXR1cm4qLywgX2Euc2VudCgpXTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7IH07XG52YXIgdXBkYXRlUmVnaXN0cmF0aW9uID0gZnVuY3Rpb24gKHN0YXRlKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgIGlmICghc3RhdGUgfHwgdHlwZW9mIHN0YXRlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc3RhdGUgZm9yIHJlZ2lzdHJhdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJ1cGRhdGUtcmVnaXN0cmF0aW9uXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0b3JlOiAnc3RhdGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGU6IHN0YXRlLFxuICAgICAgICAgICAgICAgICAgICB9KV07XG4gICAgICAgICAgICBjYXNlIDE6IHJldHVybiBbMiAvKnJldHVybiovLCBfYS5zZW50KCldO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsgfTtcbnZhciBnZXRTdGF0ZSA9IGZ1bmN0aW9uIChzdG9yZSkgeyByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgcmVzcG9uc2U7XG4gICAgdmFyIF9hO1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcbiAgICAgICAgc3dpdGNoIChfYi5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJnZXQtc3RhdGVcIiwgeyBzdG9yZTogc3RvcmUgfSldO1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gX2Iuc2VudCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCAoX2EgPSByZXNwb25zZSA9PT0gbnVsbCB8fCByZXNwb25zZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVzcG9uc2Uuc3RvcmUpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IG51bGxdO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsgfTtcbnZhciBnZXRTdGF0ZVZhbHVlID0gZnVuY3Rpb24gKHN0b3JlLCBrZXkpIHsgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJlc3BvbnNlO1xuICAgIHZhciBfYSwgX2I7XG4gICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYykge1xuICAgICAgICBzd2l0Y2ggKF9jLmxhYmVsKSB7XG4gICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlV1Jlc3BvbnNlKFwiYmFja2dyb3VuZFwiLCBcImdldC1zdGF0ZVwiLCB7IHN0b3JlOiBzdG9yZSB9KV07XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBfYy5zZW50KCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIChfYiA9IChfYSA9IHJlc3BvbnNlID09PSBudWxsIHx8IHJlc3BvbnNlID09PSB2b2lkIDAgPyB2b2lkIDAgOiByZXNwb25zZS5zdG9yZSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hW2tleV0pICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IG51bGxdO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsgfTtcbnZhciBzZXRTdGF0ZVZhbHVlID0gZnVuY3Rpb24gKHN0b3JlLCBrZXksIHZhbHVlKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJzZXQtc3RhdGVcIiwgeyBzdG9yZTogc3RvcmUsIGtleToga2V5LCB2YWx1ZTogdmFsdWUgfSldO1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9O1xudmFyIGdldFBsYXRmb3JtUmVxdWVzdHMgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHZhciByZXNwb25zZSwgcmVxdWVzdHM7XG4gICAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2UpIHtcbiAgICAgICAgc3dpdGNoIChfZS5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJnZXQtc3RhdGVcIiwgeyBzdG9yZTogJ3BsYXRmb3JtLXJlcXVlc3RzJyB9KV07XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBfZS5zZW50KCk7XG4gICAgICAgICAgICAgICAgcmVxdWVzdHMgPSAoX2IgPSAoX2EgPSByZXNwb25zZSA9PT0gbnVsbCB8fCByZXNwb25zZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVzcG9uc2Uuc3RvcmUpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5hcnJheSkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogW107XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXRQbGF0Zm9ybSByZXF1ZXN0cyAoc3RhdGUpIFwiLCByZXF1ZXN0cyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIChfZCA9IChfYyA9IHJlcXVlc3RzID09PSBudWxsIHx8IHJlcXVlc3RzID09PSB2b2lkIDAgPyB2b2lkIDAgOiByZXF1ZXN0cy5zdG9yZSkgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLmFycmF5KSAhPT0gbnVsbCAmJiBfZCAhPT0gdm9pZCAwID8gX2QgOiBbXV07XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9O1xudmFyIGNyZWF0ZVBsYXRmb3JtUmVxdWVzdCA9IGZ1bmN0aW9uIChwbGF0Zm9ybSwgcmVxdWVzdFR5cGUpIHsgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJlc3BvbnNlLCB2YWx1ZTtcbiAgICB2YXIgX2EsIF9iLCBfYztcbiAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9kKSB7XG4gICAgICAgIHN3aXRjaCAoX2QubGFiZWwpIHtcbiAgICAgICAgICAgIGNhc2UgMDogcmV0dXJuIFs0IC8qeWllbGQqLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoXCJiYWNrZ3JvdW5kXCIsIFwiZ2V0LXN0YXRlXCIsIHsgc3RvcmU6ICdwbGF0Zm9ybS1yZXF1ZXN0cycgfSldO1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gX2Quc2VudCgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY3JlYXRlUGxhdGZvcm1SZXF1ZXN0IHJlcXVlc3RzIChiZWZvcmUgYWRkaW5nKSBcIiwgKF9hID0gcmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLnN0b3JlKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuYXJyYXkpO1xuICAgICAgICAgICAgICAgIHZhbHVlID0gX19zcHJlYWRBcnJheShfX3NwcmVhZEFycmF5KFtdLCAoKF9jID0gKF9iID0gcmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLnN0b3JlKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuYXJyYXkpICE9PSBudWxsICYmIF9jICE9PSB2b2lkIDAgPyBfYyA6IFtdKSwgdHJ1ZSksIFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIDk5OTk5OTk5KS50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlZDogbmV3IERhdGUoKS5nZXRUaW1lKCksXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGF0Zm9ybTogcGxhdGZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1ZXN0VHlwZTogcmVxdWVzdFR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6ICdjcmVhdGVkJyxcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF0sIGZhbHNlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJzZXQtc3RhdGVcIiwgeyBzdG9yZTogJ3BsYXRmb3JtLXJlcXVlc3RzJywga2V5OiAnYXJyYXknLCB2YWx1ZTogdmFsdWUgfSldO1xuICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgIF9kLnNlbnQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9O1xudmFyIGdldFJlZ2lzdHJhdGlvbnMgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHZhciBzdGF0ZTtcbiAgICB2YXIgX2EsIF9iO1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2MpIHtcbiAgICAgICAgc3dpdGNoIChfYy5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0UmVnaXN0cmF0aW9uc1wiKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJnZXQtc3RhdGVcIiwgeyBzdG9yZTogJ3N0YXRlJyB9KV07XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgc3RhdGUgPSBfYy5zZW50KCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXRSZWdpc3RyYXRpb25zIHJldHVybiBcIiwgeyBzdGF0ZTogc3RhdGUgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIChfYiA9IChfYSA9IHN0YXRlID09PSBudWxsIHx8IHN0YXRlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzdGF0ZS5zdGF0ZSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hWydyZWdzJ10pICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IG51bGxdO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsgfTtcbnZhciBNeVNvTWVBUEkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gTXlTb01lQVBJKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB0aGlzLm1lc3NhZ2VIYW5kbGVyID0gbWVzc2FnZUhhbmRsZXI7XG4gICAgICAgIHRoaXMuY3JlYXRlUG9wdXAgPSBjcmVhdGVQb3B1cDtcbiAgICAgICAgdGhpcy5jcmVhdGVCYWRnZSA9IGNyZWF0ZUJhZGdlO1xuICAgICAgICB0aGlzLnNlbmRNZXNzYWdlID0gZnVuY3Rpb24gKHRvLCB0eXBlLCBwYXlsb2FkKSB7XG4gICAgICAgICAgICBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZSh0bywgdHlwZSwgcGF5bG9hZCk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuc2VuZE1lc3NhZ2VXUmVzcG9uc2UgPSBmdW5jdGlvbiAodG8sIHR5cGUsIHBheWxvYWQpIHsgcmV0dXJuIF9fYXdhaXRlcihfdGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UodG8sIHR5cGUsIHBheWxvYWQpXTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTsgfTtcbiAgICAgICAgdGhpcy51cGRhdGVSZWcgPSB1cGRhdGVSZWdpc3RyYXRpb247XG4gICAgICAgIHRoaXMudXBkYXRlUmVnaXN0cmF0aW9uID0gdXBkYXRlUmVnaXN0cmF0aW9uO1xuICAgICAgICB0aGlzLmdldFJlZ2lzdHJhdGlvbnMgPSBnZXRSZWdpc3RyYXRpb25zO1xuICAgICAgICB0aGlzLmdldFBsYXRmb3JtUmVxdWVzdHMgPSBnZXRQbGF0Zm9ybVJlcXVlc3RzO1xuICAgICAgICB0aGlzLmNyZWF0ZVBsYXRmb3JtUmVxdWVzdCA9IGNyZWF0ZVBsYXRmb3JtUmVxdWVzdDtcbiAgICAgICAgdGhpcy5nZXRTdGF0ZVZhbHVlID0gZ2V0U3RhdGVWYWx1ZTtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZVZhbHVlID0gc2V0U3RhdGVWYWx1ZTtcbiAgICAgICAgdGhpcy5nZXRTdGF0ZSA9IGdldFN0YXRlO1xuICAgICAgICB0aGlzLnJlbG9hZFRhYnMgPSByZWxvYWRUYWJzO1xuICAgIH1cbiAgICByZXR1cm4gTXlTb01lQVBJO1xufSgpKTtcbndpbmRvdy5teXNvbWUgPSBuZXcgTXlTb01lQVBJKCk7XG4iLCIiLCIvLyBzdGFydHVwXG4vLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbi8vIFRoaXMgZW50cnkgbW9kdWxlIGlzIHJlZmVyZW5jZWQgYnkgb3RoZXIgbW9kdWxlcyBzbyBpdCBjYW4ndCBiZSBpbmxpbmVkXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IHt9O1xuX193ZWJwYWNrX21vZHVsZXNfX1tcIi4vc3JjLWluamVjdGVkL2luZGV4LnRzXCJdKCk7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=