/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src-content/attention.svg":
/*!***********************************!*\
  !*** ./src-content/attention.svg ***!
  \***********************************/
/***/ (function(module) {

module.exports = "data:image/svg+xml;charset=utf-8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxOHB4IiB2aWV3Qm94PSIwIDAgMTggMTgiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDU1LjIgKDc4MTgxKSAtIGh0dHBzOi8vc2tldGNoYXBwLmNvbSAtLT4KICAgIDx0aXRsZT5BdHRlbnRpb24gQmFkZ2U8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iQXR0ZW50aW9uLUJhZGdlIj4KICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbCIgZmlsbD0iI0RENTU1NSIgY3g9IjkiIGN5PSI5IiByPSI5Ij48L2NpcmNsZT4KICAgICAgICAgICAgPHBhdGggZD0iTTguNTQ1NDEwMTYsMTIuMzYzMjgxMiBMNy45NzQxMjEwOSw0LjMyMTI4OTA2IEw5Ljg5MzA2NjQxLDQuMzIxMjg5MDYgTDkuMzA3MTI4OTEsMTIuMzYzMjgxMiBMOC41NDU0MTAxNiwxMi4zNjMyODEyIFogTTguMTcxODc1LDE1IEw4LjE3MTg3NSwxMy40NjkyMzgzIEw5LjcwMjYzNjcyLDEzLjQ2OTIzODMgTDkuNzAyNjM2NzIsMTUgTDguMTcxODc1LDE1IFoiIGlkPSIhIiBmaWxsPSIjRkZGRkZGIiBmaWxsLXJ1bGU9Im5vbnplcm8iPjwvcGF0aD4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="

/***/ }),

/***/ "./src-content/logo.svg":
/*!******************************!*\
  !*** ./src-content/logo.svg ***!
  \******************************/
/***/ (function(module) {

module.exports = "data:image/svg+xml;charset=utf-8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMzYxcHgiIGhlaWdodD0iNDYxcHgiIHZpZXdCb3g9IjAgMCAzNjEgNDYxIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA1NS4yICg3ODE4MSkgLSBodHRwczovL3NrZXRjaGFwcC5jb20gLS0+CiAgICA8dGl0bGU+c2hpZWxkPC90aXRsZT4KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPgogICAgPGRlZnM+CiAgICAgICAgPGxpbmVhckdyYWRpZW50IHgxPSI2Ni43NDIyODc2JSIgeTE9Ijg3LjQyMTA0MDglIiB4Mj0iMzIuODA1MzkyNSUiIHkyPSI5LjQ0NTMwNjAyJSIgaWQ9ImxpbmVhckdyYWRpZW50LTEiPgogICAgICAgICAgICA8c3RvcCBzdG9wLWNvbG9yPSIjNzRCRUU0IiBvZmZzZXQ9IjAlIj48L3N0b3A+CiAgICAgICAgICAgIDxzdG9wIHN0b3AtY29sb3I9IiMyMUE3RkYiIG9mZnNldD0iMzAuMDQ0MTE5MyUiPjwvc3RvcD4KICAgICAgICAgICAgPHN0b3Agc3RvcC1jb2xvcj0iIzFFQTVGRiIgb2Zmc2V0PSI1NC43NjEwMzk0JSI+PC9zdG9wPgogICAgICAgICAgICA8c3RvcCBzdG9wLWNvbG9yPSIjMjE3RUZGIiBvZmZzZXQ9IjgxLjAzNjU2MTclIj48L3N0b3A+CiAgICAgICAgICAgIDxzdG9wIHN0b3AtY29sb3I9IiMyMzVGRTciIG9mZnNldD0iMTAwJSI+PC9zdG9wPgogICAgICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICA8L2RlZnM+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0ic2hpZWxkIj4KICAgICAgICAgICAgPHBhdGggZD0iTTMuMDkwOTkzNzksNzIuMTExMzUyNCBDODAuODMzNjM5NCwzOS45MDE0NDU4IDEzOS4wMDM2MDksMTYuMDM0MzE4NCAxNzcuNjAwOTAyLDAuNTA5OTcwMzI0IEMxNzkuMzQwNTQ3LC0wLjE4OTczODAyNCAxNzkuNzAxMjE1LC0wLjE0OTk1MTI0NyAxODEuNTk2NzQ5LDAuNTA5OTcwMzI0IEMyMDQuNzU0MDYzLDguNTcyMDgyMDMgMjYzLjIxNjY2MiwzMi40MzkyMDk0IDM1Ni45ODQ1NDksNzIuMTExMzUyNCBDMzYxLjcyNDA3NiwxNzYuNzk1NjExIDM2MS43MjQwNzYsMjM5LjIzMDk3NCAzNTYuOTg0NTQ5LDI1OS40MTc0NDMgQzM0OS44NzUyNTgsMjg5LjY5NzE0NyAzNDEuNzEwODksMzE1LjE0NjUgMzMwLjM2OTE1MywzMzUuMDgyODAxIEMzMDAuOTE4NDIyLDM4Ni44NTA3NjIgMjUwLjgwNzk2Miw0MjguNjc0ODMxIDE4MC4wMzc3NzEsNDYwLjU1NTAwOCBDMTAxLjU0NDM5NSw0MjMuOTYwNjMzIDUxLjU4MDU2NCwzODIuMTM2NTY0IDMwLjE0NjI3OTYsMzM1LjA4MjgwMSBDMjAuOTczMDcxOSwzMTQuOTQ1MjUyIDcuNzE2MDg5NjksMjk0LjQyODYxMyAzLjA5MDk5Mzc5LDI1OS40MTc0NDMgQy0xLjAzMDMzMTI2LDIyOC4yMTk3MzEgLTEuMDMwMzMxMjYsMTY1Ljc4NDM2NyAzLjA5MDk5Mzc5LDcyLjExMTM1MjQgWiIgaWQ9IlJlY3RhbmdsZSIgZmlsbD0idXJsKCNsaW5lYXJHcmFkaWVudC0xKSI+PC9wYXRoPgogICAgICAgICAgICA8ZyBpZD0iR3JvdXAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMS4wMDAwMDAsIDk5LjAwMDAwMCkiIHN0cm9rZT0iI0ZGRkZGRiI+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMTIyLjg4OTEzNSw1Ljg1MzY3NDc3IEM4OC4yODQ2MzI4LDIuNTkyMTczNCA2MC4wMDE0OTA4LDguNjc2MjAyMjkgMzguMDM5NzA5NiwyNC4xMDU3NjE0IEMyMS42MzQ5OTE3LDM1LjYzMTEyNzMgNS4yNzk1OTc0Miw2MC44ODIxMDYxIDMuMDI5NzE3MDUsODcuMzQ0MjMwNyBDLTQuMDkwNDE4OTIsMTcxLjA4ODIwNiAyNy42NzkxNDQ5LDE4MC40MTQ2ODggMzguMDM5NzA5NiwxODQuOTIxNTI2IEM0OC40MDAyNzQyLDE4OS40MjgzNjQgNzIuMTE3MzU3NSwxOTEuMDIxMjQ2IDkwLjg3NTA5NjksMTc2LjM5MjI0NCBDMTA5LjYzMjgzNiwxNjEuNzYzMjQyIDEwOS42MzI4MzYsMTQwLjU1MzE2MyAxMDguNjAwMjcyLDEyMS45NDcyNzIiIGlkPSJMaW5lIiBzdHJva2Utd2lkdGg9IjEyIiBzdHJva2UtbGluZWNhcD0ic3F1YXJlIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNNTUuNjE5MTExMiwxMjkuMTA2ODg4IEM1NS42MTkxMTEyLDk5LjM2NjAwODYgNTkuNTU3MDY5Miw4NC4zOTc4NDE2IDgyLjE4MzQ1NDEsNjguNzk2MjA3NyBDOTQuMzYxNTE4Nyw2MC4zOTkwMzMxIDExNy45MjExOTIsNjAuNjY1Mjk2OCAxMzMuNTMyMzAzLDY4Ljc5NjIwNzcgQzE2Ny43ODgyODksODYuNjM4MTM5MiAxNjEuNzc4ODM1LDEyNS45MjI2NzQgMTYxLjc3ODgzNSwxNTAuNTg0MjE5IEMxNjEuNzc4ODM1LDE3NS4yNDU3NjMgMTU0LjcyNjM1NSwyMTIuMDI4NTI1IDEyMS4xODkyODQsMjMxLjAwOTE0NyBDODcuNjUyMjEzOSwyNDkuOTg5NzY5IDY3LjQwNDAwNjcsMjQ3LjQ2OTc2NCA0Mi4zNjEyOTM1LDI0NS4xNzIzMSIgaWQ9IkxpbmUiIHN0cm9rZS13aWR0aD0iMTIiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0xNTUuOTAxNTg3LDUwLjIyNDk3OTEgQzE0OC41NzAxMzksNDEuOTU4NDE0IDEyMC41MzA2MzUsMzIuMTc4NDY4IDk3LjE2NTA0NCwzNS4xMzYxNjI1IEM2OC4wNjE2OTQzLDM4LjgyMDE2MTYgNTEuNjM1NjQ0OCw0Ni44MDQ3NzI4IDM5LjM5MjY0ODgsNjguODQwMzAwOCBDMjguNDMwNjUwMSw4OC41NzAyMjg3IDI4LjQzMDY1MDEsMTE2LjE2NzQ1MyAyOS43NDM3MTMzLDEyOC4zMjQ2NjQgQzMxLjQ5MjYxODksMTQ0LjUxNzE5NCAzNS40NTc0MzQyLDE2MS45NzQ3MjEgNTguNjMwODQzMywxNjEuOTc0NzIxIEM4Mi41MTA3NDY1LDE2MS45NzQ3MjEgODIuNTEwNzQ2NSwxMzguNjkxNjEgODIuMTgzNDU0MSwxMTYuMTY3NDUzIEM4MS45Mjk5NzI3LDk4LjcyMjk0NTQgOTQuNTMzODUzNCw4OS45NTI3MDg4IDEwOS4wNDQzODcsODkuOTUyNzA4OCBDMTIyLjg4OTEzNSw4OS45NTI3MDg4IDEzNC43OTQ3NzQsMTAwLjA0NzM1MyAxMzQuNzk0Nzc0LDExNi4xNjc0NTMgQzEzNC43OTQ3NzQsMTQxLjg4MTQzMyAxNDEuMjQ3Mjg5LDE4MS43MzEzNTQgMTA2LjQ1MjE5MSwyMDQuNjM0MDU2IEM3MS42NTcwOTI4LDIyNy41MzY3NTcgMjEuMTIwNDY2NywyMTUuMDAwOTczIDkuMTE5OTA2MiwyMDEuMDUxNjA0IiBpZD0iTGluZSIgc3Ryb2tlLXdpZHRoPSIxMiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSI+PC9wYXRoPgogICAgICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbCIgZmlsbD0iI0ZGRkZGRiIgY3g9IjM2LjUiIGN5PSIyNDQuNSIgcj0iNS41Ij48L2NpcmNsZT4KICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIGZpbGw9IiNGRkZGRkYiIGN4PSI1LjUiIGN5PSIxOTYuNSIgcj0iNS41Ij48L2NpcmNsZT4KICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIGZpbGw9IiNGRkZGRkYiIGN4PSIxMDguMiIgY3k9IjExNS41IiByPSI1LjUiPjwvY2lyY2xlPgogICAgICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbCIgZmlsbD0iI0ZGRkZGRiIgY3g9IjU1LjciIGN5PSIxMzUuNSIgcj0iNS41Ij48L2NpcmNsZT4KICAgICAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIGZpbGw9IiNGRkZGRkYiIGN4PSIxNTkuNSIgY3k9IjU0LjUiIHI9IjUuNSI+PC9jaXJjbGU+CiAgICAgICAgICAgICAgICA8Y2lyY2xlIGlkPSJPdmFsIiBmaWxsPSIjRkZGRkZGIiBjeD0iMTI4LjUiIGN5PSI2LjQiIHI9IjUuNSI+PC9jaXJjbGU+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=="

/***/ }),

/***/ "./src-content/badge.ts":
/*!******************************!*\
  !*** ./src-content/badge.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createBadge = void 0;
var attention_svg_1 = __importDefault(__webpack_require__(/*! ./attention.svg */ "./src-content/attention.svg"));
var logo_svg_1 = __importDefault(__webpack_require__(/*! ./logo.svg */ "./src-content/logo.svg"));
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
var createBadge = function (_a) {
    var _b = _a.showAttention, showAttention = _b === void 0 ? false : _b;
    var id = "mysome-badge";
    if (document.getElementById(id)) {
        return;
    }
    var e = document.createElement('div');
    e.id = id;
    var top = ''; // 'top: calc(50% - 32px)';
    var bottom = 'bottom: 12px';
    var z = '9998';
    e.innerHTML = "\n\t  <div id=\"mysome-access-badge\" style=\"position: fixed; left: 16px; ".concat(top, "; ").concat(bottom, "; z-index: ").concat(z, "; display: flex; cursor: pointer; filter: drop-shadow(1px 0px 4px #2b2b2b61);\">\n\t\t<a id=\"mysome-access-badge-link\" style=\"display: flex;\">\n\t\t  <img src=\"").concat(logo_svg_1.default, "\" width=\"60\" height=\"60\">\n\t\t  <span id=\"mysome-access-badge-attention\" style=\"position: absolute; top: -1px; right: 5px; color: white; width: 18px; text-align: center; height: 18px;\">\n\t\t\t<img src=\"").concat(attention_svg_1.default, "\" width=\"18px\" height=\"18px\"></img>\n\t\t  </span>\n\t\t</a>\n\t  </div>\n\t");
    document.body.appendChild(e);
    var eventHandler = function (e) {
        var _a, _b;
        (_b = (_a = root_1.mysome.widgets[id]) === null || _a === void 0 ? void 0 : _a.click) === null || _b === void 0 ? void 0 : _b.forEach(function (x) {
            try {
                x(e);
            }
            catch (e) {
                console.error(e);
            }
        });
    };
    var anchor = document.getElementById("mysome-access-badge-link");
    anchor === null || anchor === void 0 ? void 0 : anchor.addEventListener("click", eventHandler);
    var attention = document.getElementById("mysome-access-badge-attention");
    if (attention) {
        attention.style.visibility = !showAttention ? 'hidden' : 'initial';
    }
    root_1.mysome.widgets[id] = {
        element: e,
        click: [],
        addClickHandler: function (fn) {
            root_1.mysome.widgets[id].click.push(fn);
        },
        showAttention: function (v) {
            if (attention) {
                attention.style.visibility = !v ? 'hidden' : 'initial';
            }
        },
        show: function () {
            e.style.display = 'initial';
        },
        hide: function () {
            e.style.display = 'none';
        },
    };
    return root_1.mysome.widgets[id];
};
exports.createBadge = createBadge;


/***/ }),

/***/ "./src-content/content-messaging.ts":
/*!******************************************!*\
  !*** ./src-content/content-messaging.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createContentMessageHandler = exports.getMessageHandler = exports.isMySOMEIDMessage = void 0;
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
var isMySOMEIDMessage = function (msg) { return (msg === null || msg === void 0 ? void 0 : msg.origin) === 'mysome' && !!(msg === null || msg === void 0 ? void 0 : msg.type); };
exports.isMySOMEIDMessage = isMySOMEIDMessage;
// export const isMySOMEIDEvent = (msg: any) => msg?.origin === 'mysome' && msg?.isEvent === true;
/*export type MySoMeIdExtensionResponse = {
    msg: any;
    response: any;
};*/
/* export type MessageHandler = {
    sendMessage: (msg: any) => void;
}; */
// let injectedMessageHandler: MessageHandler | null;
/*export const getInjectedMessageHandler = (): MessageHandler => {
    if ( !injectedMessageHandler ) {
        throw new Error('MYSOMEID-Content: No message handler created');
    }
    return injectedMessageHandler;
};*/
/*export const createInjectedMessageHandler = (): MessageHandler => {
    if ( injectedMessageHandler ) {
        throw new Error('MYSOMEID-Content: Message handler already created');
    }

    const sendMessage = (msg: any) => {
        window.postMessage(msg, 'mysomeid-injected');
    };

    window.addEventListener('message', ({ data: msg, origin }) => {
        if ( origin?.indexOf("mysomeid") === 0 ) {
            console.log("MYSOMEID-Content: got some kind of message", {msg, origin});
        }
    });

    injectedMessageHandler = {
        sendMessage
    };

    return injectedMessageHandler;
};*/
var messageHandler;
var getMessageHandler = function () {
    return (0, exports.createContentMessageHandler)();
};
exports.getMessageHandler = getMessageHandler;
var createContentMessageHandler = function () {
    if (messageHandler) {
        return messageHandler;
    }
    var messageHandlers = [];
    var resolvers = {};
    // Create Bridge between content and popup/backend.
    var onMessage = function (_a) {
        var _b, _c, _d;
        var data = _a.data;
        if (!(0, exports.isMySOMEIDMessage)(data)) {
            return;
        }
        console.log("onMessage", data);
        if (data.type === "validate-proof-response") {
            // debugger;
        }
        var type = data.type, to = data.to;
        if (!type) {
            console.error("Ignored message with no type ", data);
            return;
        }
        if (type.indexOf('-response') > 0) {
            var resolver = resolvers[data.responseTo];
            // debugger;
            try {
                if (resolver) {
                    resolver(data.payload);
                }
                else {
                    console.warn('No response listener for', data);
                }
            }
            catch (e) {
                console.error(e);
            }
            return;
        }
        if (to === 'injected') {
            console.log("Message to injected ingored by content message handler.");
            return;
        }
        console.log('MYSOMEID-Content: Content scripts: get message ', __assign({}, data));
        if (to === 'background') {
            console.log("MYSOMEID-Content: Content scripts: forwarding message to extension.", data);
            chrome.runtime
                .sendMessage(data)
                .then(function (response) {
                console.log("MYSOMEID-Content: Content scripts. got response (BRIDGING IT).", response);
                // debugger;
                window.postMessage(response, '*');
            })
                .catch(function (error) {
                console.error(error);
                window.postMessage({
                    error: error === null || error === void 0 ? void 0 : error.message,
                }, '*');
            });
            return;
        }
        else if (to === "content" && type === 'forward') {
            console.log("Forwarding message to " + ((_b = data.payload) === null || _b === void 0 ? void 0 : _b.to), { message: data.payload });
            if (['popup', 'background'].indexOf((_c = data.payload) === null || _c === void 0 ? void 0 : _c.to) >= 0) {
                // send to background!
                chrome.runtime.sendMessage(data.payload)
                    .then(function (response) {
                    var _a;
                    console.log("MYSOMEID-Content: Content scripts. got response.", response);
                    if ((response === null || response === void 0 ? void 0 : response.error) !== undefined) {
                        console.log("MYSOMEID-Content: Response is an error: thrown as error");
                        // If an error is thrown in the background script, propagate it to inject.
                        throw new Error((_a = response.error) !== null && _a !== void 0 ? _a : undefined);
                    }
                    /*const msgResponse: MySoMeIdExtensionResponse = {
                        msg: {},
                        response,
                    };*/
                    console.log("TODO: send response back to origin. ", response);
                    //window.postMessage(  );
                    // window.postMessage(msgResponse);
                })
                    .catch(function (e) {
                    console.error(e);
                });
            }
            else {
                console.error("Unknown forwarding target : " + ((_d = data.payload) === null || _d === void 0 ? void 0 : _d.to));
            }
        }
        // The message is 
        if (to === 'content') {
            // console.log("Content: The message is for me.");
            messageHandlers.forEach(function (x) {
                try {
                    x(data);
                }
                catch (e) {
                    console.error(e);
                }
            });
            return;
        }
        /*chrome.runtime
                .sendMessage(data)
                .then((response: any) => {
                    console.log("MYSOMEID-Content: Content scripts. got response.", response);
                    if (response.error !== undefined) {
                        console.log("MYSOMEID-Content: Response is an error: thrown as error");
                        // If an error is thrown in the background script, propagate it to inject.
                        throw new Error(response.error ?? undefined);
                    }
                    const msgResponse: MySoMeIdExtensionResponse = {
                        data,
                        response,
                    };
                    window.postMessage(msgResponse);
                })
                .catch((error: Error) => {
                    console.error(error);
                    window.postMessage(new Error(error.message));
                });*/
    };
    window.addEventListener('message', onMessage);
    // Propagate events from content script extension -> inject
    chrome.runtime.onMessage.addListener(function (data) {
        console.log("MYSOMEID-Content: Got message from extension ", { data: data });
        if (!(0, exports.isMySOMEIDMessage)(data)) {
            console.log("MYSOMEID-Content: Not a MYSOMEID message");
            return;
        }
        console.log("MYSOMEID-Content: Forwarding message to content messageHandler");
        window.postMessage(data, "*"); // Forward message.
    });
    var createMessage = function (to, type, payload, extra) {
        var serial = Math.round(Math.random() * 999999999999999999);
        var data = __assign(__assign({ to: to, from: 'content', type: type, payload: payload, serial: serial }, (extra !== null && extra !== void 0 ? extra : {})), { origin: 'mysome' });
        return data;
    };
    messageHandler = {
        sendMessage: function (to, type, payload, extra) {
            var data = createMessage(to, type, payload, extra);
            if (to === 'background') {
                chrome.runtime.sendMessage(data, function (_a) {
                    var state = _a.state;
                });
                return;
            }
            if (to === 'injected-widget') {
                var id = data.payload.id;
                if (!root_1.mysome.widgets[id]) {
                    console.error("No widget with id : " + id);
                    return;
                }
                var wnd = root_1.mysome.widgets[id].iframe.contentWindow;
                if (!wnd) {
                    console.error("No frame content window available");
                    return;
                }
                wnd.postMessage(JSON.stringify(data), '*');
                return;
            }
            window.postMessage(data, '*');
        },
        sendMessageWResponse: function (to, type, payload, extra) { return __awaiter(void 0, void 0, void 0, function () {
            var data, id, wnd;
            return __generator(this, function (_a) {
                data = createMessage(to, type, payload, extra);
                if (to === 'background') {
                    return [2 /*return*/, new Promise(function (resolve) {
                            chrome.runtime.sendMessage(data, function (result) {
                                console.log("background returned result: ", result);
                                resolve(result);
                            });
                        })];
                }
                if (to === 'injected-widget') {
                    id = data.payload.id;
                    if (!root_1.mysome.widgets[id]) {
                        console.error("No widget with id : " + id);
                        return [2 /*return*/];
                    }
                    wnd = root_1.mysome.widgets[id].iframe.contentWindow;
                    if (!wnd) {
                        console.error("No frame content window available");
                        return [2 /*return*/];
                    }
                    wnd.postMessage(JSON.stringify(data), '*');
                    return [2 /*return*/];
                }
                window.postMessage(data, '*');
                return [2 /*return*/, new Promise(function (resolve) {
                        resolvers[data.serial] = resolve;
                    })];
            });
        }); },
        addMessageHandler: function (handler) {
            messageHandlers.push(handler);
        },
    };
    return messageHandler;
};
exports.createContentMessageHandler = createContentMessageHandler;


/***/ }),

/***/ "./src-content/frame.ts":
/*!******************************!*\
  !*** ./src-content/frame.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createFrameWidget = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var createFrameWidget = function (url) {
    var created = false;
    var setup = false;
    var iframeContent = url; /* "data:text/html;base64," + utf8_to_b64(`
        <head>
            <script type="text/javascript">
                console.log("iframe content");
            </script>
        </head>
        <body>
            <div>
                sadasdsa
            </div>
        </body>
    `);*/
    if (!document.getElementById("mysome-frame-root")) {
        var elem = document.createElement('div');
        elem.id = "mysome-frame-root";
        elem.innerHTML = "\n\t\t\t<style>\n\t\t\t</style>\n\t\t\t<div id=\"mysome-frame-container\" style=\"position: fixed;left: 0;top: 0;right: 0;bottom: 0;z-index: 9999;background: #c9c9c966;display: flex;align-items: center;place-content: center;\">\n\t\t\t\t<div id=\"mysome-frame-view\" style=\"background: white;max-width: 380px;height: 522px;border-radius: 4px;box-shadow: 0px 1px 34px 9px rgba(0,0,0,0.27);width: 80%;position: fixed;color: black;border-radius: 10px;\">\n\t\t\t\t\t<iframe src=\"".concat(iframeContent, "\" title=\"description\" style=\"width: 100%; height: 100%\"></iframe>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t");
        created = true;
        document.body.appendChild(elem);
    }
    else {
        utils_1.logger.error("Root element already existed! This may make the plugin stop working.");
    }
    var root = document.getElementById("mysome-frame-root");
    if (!root) {
        throw new Error("No widget found.");
    }
    if (!setup) {
        /*let btn = document.getElementById("mysome-frame-close-button") as HTMLButtonElement;
        btn.addEventListener("click", () => {
            const root = document.getElementById("mysome-frame-root");
            if ( root ) {
                root.style.display = "none";
            }
        });
        btn = document.getElementById("mysome-frame-create-button") as HTMLButtonElement;
        btn.addEventListener("click", () => {
            const linkUrl = getUrlToCreateProof();
            if ( linkUrl ) {
                window.open(linkUrl, "_blank");
            }
        });*/
        setup = true;
    }
    return {
        elements: {
            root: root,
        },
        setInitialState: function () {
        },
        hide: function () {
            root.style.display = 'none';
        },
        show: function () {
            root.style.display = 'inline-block';
        },
    };
};
exports.createFrameWidget = createFrameWidget;


/***/ }),

/***/ "./src-content/index.ts":
/*!******************************!*\
  !*** ./src-content/index.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
/* eslint-disable */
console.log("MySoMe extension");
var linked_in_1 = __importDefault(__webpack_require__(/*! ./integrations/linked-in */ "./src-content/integrations/linked-in.ts"));
var test_1 = __importDefault(__webpack_require__(/*! ./integrations/test */ "./src-content/integrations/test.ts"));
var mysome_api_1 = __importDefault(__webpack_require__(/*! ./integrations/mysome-api */ "./src-content/integrations/mysome-api.ts"));
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var content_messaging_1 = __webpack_require__(/*! ./content-messaging */ "./src-content/content-messaging.ts");
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
var platform = (0, utils_1.detectPlatform)();
// Expose the object to the console so we can run commands on it.
window.mysome = root_1.mysome;
if (platform !== null) {
    console.log("Creating message handler");
    var messageHandler = (0, content_messaging_1.getMessageHandler)();
    messageHandler.addMessageHandler(function (data) {
        var type = data.type, payload = data.payload;
        switch (type) {
            case 'create-badge':
                root_1.mysome.createBadge({ showAttention: false });
                break;
            case 'create-tour':
                root_1.mysome.createTour('li.change-background');
                break;
            case 'redirect':
                if (payload === null || payload === void 0 ? void 0 : payload.url) {
                    console.log("Redirecting url ", { url: payload === null || payload === void 0 ? void 0 : payload.url });
                    window.location.href = payload.url;
                }
                else {
                    console.error('Redirect requested - but no url given : ', payload);
                }
                break;
            case 'open-url':
                {
                    if (payload === null || payload === void 0 ? void 0 : payload.url) {
                        console.log("Opening url ", { url: payload.url });
                        window.open(payload.url, '_blank');
                    }
                    else {
                        console.error('Open url requested - but no url given : ', payload);
                    }
                }
                break;
            case 'close-widget':
                {
                    var id = payload.id, result = payload.result;
                    if (!root_1.mysome.widgets[id]) {
                        console.error("Error finding widget with id " + id);
                        return;
                    }
                    ;
                    root_1.mysome.widgets[id].onResult &&
                        root_1.mysome.widgets[id].onResult(result);
                    root_1.mysome.widgets[id].destroy();
                }
                break;
            case 'widget-created':
                {
                    var id = payload.id;
                    if (!root_1.mysome.widgets[id]) {
                        console.error("No widget exists with : " + id);
                        return;
                    }
                    ;
                    root_1.mysome.widgets[id].setCreated();
                }
                break;
        }
    });
    (0, mysome_api_1.default)();
    (function () { return __awaiter(void 0, void 0, void 0, function () {
        var e_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, utils_1.storage.init()];
                case 1:
                    _a.sent();
                    return [3 /*break*/, 3];
                case 2:
                    e_1 = _a.sent();
                    return [3 /*break*/, 3];
                case 3:
                    if (!(platform === 'li')) return [3 /*break*/, 5];
                    utils_1.logger.info("MySoMeId: Injecting plugin into LinkedIn!");
                    return [4 /*yield*/, (0, linked_in_1.default)()];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 7];
                case 5:
                    if (!(platform === 'test')) return [3 /*break*/, 7];
                    utils_1.logger.log("MySoMeId: Injecting plugin into Test page!");
                    return [4 /*yield*/, (0, test_1.default)()];
                case 6:
                    _a.sent();
                    _a.label = 7;
                case 7: return [2 /*return*/];
            }
        });
    }); })().then().catch(console.error);
}


/***/ }),

/***/ "./src-content/integrations/linked-in.ts":
/*!***********************************************!*\
  !*** ./src-content/integrations/linked-in.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var utils_1 = __webpack_require__(/*! ../utils */ "./src-content/utils.ts");
var shield_1 = __webpack_require__(/*! ../shield */ "./src-content/shield.ts");
var popup_1 = __webpack_require__(/*! ../popup */ "./src-content/popup.ts");
var root_1 = __webpack_require__(/*! ../root */ "./src-content/root.ts");
var tour_1 = __webpack_require__(/*! ../tour */ "./src-content/tour.ts");
var tracking_1 = __webpack_require__(/*! ../tracking */ "./src-content/tracking.ts");
var content_messaging_1 = __webpack_require__(/*! ../content-messaging */ "./src-content/content-messaging.ts");
var nvisit = 0;
var root = null;
var state = {
    proofUrl: '',
    pageHasBeenVerified: false,
};
var TEST = false;
var WEBSITE_BASE_URL = function () { return TEST ? "http://localhost:3000" : "https://app.testnet.mysome.id"; };
var SERVICE_BASE_URL = function () { return TEST ? 'https://api.testnet.mysome.id/v1' : "https://api.testnet.mysome.id/v1"; };
var welcomeShown = null;
var shield = null;
var profileStatus = (0, tracking_1.createTracker)({
    name: 'profileStatus',
    cmp: function (curValue, compareWith) {
        if (!curValue || !compareWith) {
            return curValue !== compareWith; // If both are null then false if one of them is a valid value then true.
        }
        if (curValue.status !== compareWith.status &&
            curValue.page !== compareWith.page &&
            curValue.type !== compareWith.type) {
            return true;
        }
        return false; // No change.
    }
});
function setPageStatus(page, type) {
    var _a;
    var ps = (_a = profileStatus.get()) !== null && _a !== void 0 ? _a : {
        status: null,
        page: page,
        type: type,
    };
    ps.page = page;
    ps.type = type;
    profileStatus.update({
        query: function () { return ps; },
    });
}
function setProfileStatusResolved(page, type, status) {
    var _a;
    var ps = (_a = profileStatus.get()) !== null && _a !== void 0 ? _a : {
        status: status,
        page: page,
        type: type,
    };
    ps.page = page;
    ps.type = type;
    ps.status = status;
    profileStatus.update({
        query: function () { return ps; },
    });
}
function qsa(s) {
    var _a;
    return Array.prototype.slice.call((_a = document.querySelectorAll(s)) !== null && _a !== void 0 ? _a : []);
}
function qs(s) {
    return document.querySelector(s);
}
HTMLElement.prototype.qsa = function (s) {
    var _a;
    return Array.prototype.slice.call((_a = document.querySelectorAll(s)) !== null && _a !== void 0 ? _a : []);
};
var _d = HTMLElement.prototype.qs = function (s) {
    return document.querySelector(s);
};
var fetchQRFromImage = function (url) { return __awaiter(void 0, void 0, void 0, function () {
    var base, validateUrl, qr, e_1;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                console.log("Getting QR code from url : " + url);
                if (!url) {
                    throw new Error('No url provided');
                }
                _a.label = 1;
            case 1:
                _a.trys.push([1, 3, , 4]);
                base = SERVICE_BASE_URL();
                validateUrl = "".concat(base, "/qr/validate?url=").concat(encodeURIComponent(url));
                console.log("Getting QR code for : " + url);
                return [4 /*yield*/, fetch(validateUrl)
                        .then(function (response) {
                        if (response.status >= 200 && response.status < 300) {
                            return response.text();
                        }
                        ;
                        console.error("No QR code found " + response.status);
                        var error = new Error(response.statusText);
                        error.response = response;
                        throw error;
                    })
                        .then(function (response) { return JSON.parse(response); })
                        .then(function (data) {
                        var _a;
                        return (data === null || data === void 0 ? void 0 : data.error) ? null : (_a = data === null || data === void 0 ? void 0 : data.result) !== null && _a !== void 0 ? _a : null;
                    }).catch(function (err) {
                        console.error(err);
                        if (err != null && 'response' in err && err.response.status === 401) {
                            console.error("Connetion error");
                        }
                        throw err;
                    })];
            case 2:
                qr = _a.sent();
                return [2 /*return*/, {
                        qr: qr,
                        connectionError: false,
                    }];
            case 3:
                e_1 = _a.sent();
                console.error(e_1);
                return [2 /*return*/, {
                        qr: null,
                        connectionError: true,
                    }];
            case 4: return [2 /*return*/];
        }
    });
}); };
var verifyProfile = function (profileUserId, backgroundUrl, profilePictureUrl) { return __awaiter(void 0, void 0, void 0, function () {
    var qrResult, connectionError, _a, qr, err, profileImageUrl, _b, qr, err;
    return __generator(this, function (_c) {
        switch (_c.label) {
            case 0:
                qrResult = null;
                connectionError = false;
                if (backgroundUrl === 'default') {
                    console.log("Background is the default and contains no QR.");
                }
                if (profilePictureUrl === 'default' || profilePictureUrl === 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7') {
                    console.log("Profile picture is the default and contains no QR.");
                }
                if (!(!qrResult && backgroundUrl && backgroundUrl !== 'default')) return [3 /*break*/, 2];
                return [4 /*yield*/, fetchQRFromImage(backgroundUrl)];
            case 1:
                _a = _c.sent(), qr = _a.qr, err = _a.connectionError;
                if (qr) {
                    (0, utils_1.verbose)("QR in background: YES");
                    qrResult = qr;
                }
                else {
                    (0, utils_1.verbose)("QR in background: NO");
                }
                if (!qr && err) {
                    connectionError = true;
                }
                return [3 /*break*/, 3];
            case 2:
                (0, utils_1.verbose)("Fetching QR result from background image: No background image found.");
                _c.label = 3;
            case 3:
                if (!(!qrResult && profilePictureUrl && profilePictureUrl !== 'default' && profilePictureUrl !== 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7')) return [3 /*break*/, 5];
                (0, utils_1.verbose)("Fetching QR result from profile image");
                profileImageUrl = profilePictureUrl;
                return [4 /*yield*/, fetchQRFromImage(profileImageUrl)];
            case 4:
                _b = _c.sent(), qr = _b.qr, err = _b.connectionError;
                if (qr) {
                    (0, utils_1.verbose)("QR in background: YES");
                    qrResult = qr;
                }
                else {
                    (0, utils_1.verbose)("QR in background: NO");
                }
                if (!qr && err) {
                    connectionError = true;
                }
                _c.label = 5;
            case 5: return [2 /*return*/, {
                    qrResult: qrResult,
                    connectionError: connectionError,
                    profileUserId: profileUserId,
                }];
        }
    });
}); };
var ensureWidget = function () {
    utils_1.logger.info("Adding mysome.id Widget");
    var nameElement = (document.querySelectorAll("h1")[0]);
    if (!nameElement || !nameElement.parentElement) {
        utils_1.logger.error("Failed to find profile name element - No Widget Anchor.");
        return null;
    }
    var widget = (0, shield_1.createShieldWidget)(nameElement.parentElement, {
        onClicked: function (state, proofUrl) {
            console.log('Shield clicked', { state: state, proofUrl: proofUrl });
            root_1.mysome.badgeClickHandler &&
                root_1.mysome.badgeClickHandler({
                    origin: 'shield',
                    profile: 'other',
                    proofUrl: proofUrl
                });
        },
    });
    (0, utils_1.verbose)("Widget created", widget);
    widget.setInitialState();
    return widget;
};
(function () { return __awaiter(void 0, void 0, void 0, function () {
    var staging;
    var _a;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4 /*yield*/, utils_1.storage.get("staging", true)];
            case 1:
                staging = (_a = (_b.sent())) !== null && _a !== void 0 ? _a : false;
                TEST = !!staging;
                console.log("test ", TEST);
                return [2 /*return*/];
        }
    });
}); })().then().catch(console.error);
var trackProofQR = (0, tracking_1.createTracker)({
    name: 'proofQR',
});
var trackUrl = (0, tracking_1.createTracker)({
    name: 'url',
    query: function () { return window.location.href; },
});
var trackOnProfileUrl = (0, tracking_1.createTracker)({
    name: 'onProfileUrl',
    query: function () { return !!(0, utils_1.isOnLinkedInProfileUrl)(); }
});
var trackOnFeedUrl = (0, tracking_1.createTracker)({
    name: 'onFeedUrl',
    query: function () { return (0, utils_1.isOnLinkedInFeedUrl)(); }
});
var trackOnOwnProfileOrFeed = (0, tracking_1.createTracker)({
    name: 'onOwnProfileOrFeed',
    query: function () { return (0, utils_1.onOwnLinkedInProfileOrFeedUrl)(); },
});
var trackOwnProfileName = (0, tracking_1.createTracker)({
    name: 'ownProfileName'
});
var trackProfileUserId = (0, tracking_1.createTracker)({
    name: 'profileUserId'
});
var trackProfileName = (0, tracking_1.createTracker)({
    name: 'profileName'
});
var trackOwnProfileUserId = (0, tracking_1.createTracker)({
    name: 'ownProfileUserIdObserved',
    mode: 'observed',
});
var trackOtherProfileUserId = (0, tracking_1.createTracker)({
    name: 'otherProfile',
    mode: 'observed',
});
var trackHeader = (0, tracking_1.createTracker)({
    name: 'header',
});
var trackOnOwnFeed = (0, tracking_1.createTracker)({
    name: 'onOwnFeed',
});
var trackOnOwnPage = (0, tracking_1.createTracker)({
    name: 'onOwnPage',
});
var trackBackgroundUrl = (0, tracking_1.createTracker)({
    name: 'backgroundUrl',
});
var trackVerifyStatus = (0, tracking_1.createTracker)({
    name: 'verifyStatus',
});
var trackProfilePictureUrl = (0, tracking_1.createTracker)({
    name: 'profilePictureUrl',
});
var trackPathname = (0, tracking_1.createTracker)({ name: 'route' });
var createHeartbeat = function () {
    // let updatePageStatus = false;
    var startTime = new Date().getTime();
    return function () {
        var timeSinceStart = new Date().getTime() - startTime;
        var url = trackUrl.update().value;
        var pathname = trackPathname.update({
            query: function () {
                var _a;
                return (_a = window.location.pathname) !== null && _a !== void 0 ? _a : '';
            },
        }).value;
        var onProfileUrl = trackOnProfileUrl.update({
        // prerequisites: [urlChanged], // TODO: support input and prerequistes to optimise.
        }).value;
        var onFeedUrl = trackOnFeedUrl.update({
        // prerequisites: [urlChanged],
        }).value;
        var _a = trackOnOwnProfileOrFeed.update({
            throttle: 1000,
            /*on: (value: boolean) => { // called when changed.
                if ( value ) {
                    verbose("You are on your own profile.");
                } else {
                    verbose("You are not on your own page");
                }
            }*/
        }), onOwnPageOrFeed = _a.value, onOwnPageOrFeedChanged = _a.dirty;
        trackOwnProfileName.update({
            throttle: 2000,
            query: function () {
                var _a;
                if (!onProfileUrl && !onFeedUrl) {
                    // console.log("Not on feed url or profile url");
                    return null;
                }
                if (onProfileUrl) {
                    return (0, utils_1.getUsersNameOnProfile)();
                }
                return (_a = (0, utils_1.getUsersNameOnFeed)()) !== null && _a !== void 0 ? _a : null;
            }
        });
        var profileUserId = trackProfileUserId.update({
            /* prerequisites: [ // Only run if we are on a profile url or on the feed.
                trackOnProfileUrl.get() || trackOnFeedUrl.get(),
            ],*/
            query: function () {
                if (!onProfileUrl && !onFeedUrl) {
                    // console.log("Not on feed url or profile url");
                    return null;
                }
                if (onProfileUrl) {
                    var value = (0, utils_1.getUserIdInUrl)();
                    // console.log("resolved profile url profile name :"  + value);
                    return value;
                }
                else if (onFeedUrl) {
                    var value = (0, utils_1.getUserIdOnPageFeed)();
                    // console.log("resolved feed profile name :"  + value);
                    return value;
                }
                return null;
            },
        }).value;
        // This is observed just once.
        trackOwnProfileUserId.update({
            prerequisites: [
                !!onOwnPageOrFeed,
                profileUserId !== null,
                trackOwnProfileUserId.get() === null,
            ],
            query: function () {
                console.log('ownProfile value : ' + trackOwnProfileUserId.get());
                console.log('ownProfile new Value : ' + profileUserId);
                return profileUserId;
            },
        });
        // this tracks if we landed on the url of another user.
        /*trackOtherProfileUserId.update({
            throttle: 1000,
            prerequisites: [
                !onOwnPageOrFeed,
                onProfileUrl === true,
                !!profileUserId,
                timeSinceStart > 3000,
            ],
            query: () => {
                if ( !!document.querySelector("button[aria-label=\"Edit intro\"]") ) {
                    return null;
                }
                console.log('otherProfile new Value : ' + getUserIdInUrl() );
                return getUserIdInUrl();
            },
        });*/
        var _b = trackHeader.update({
            throttle: 2000,
            // resetThrottle: profileUserIdChanged,
            query: function () {
                // console.log("checking header : " + onProfileUrl);
                if (!onProfileUrl) {
                    return null;
                }
                var newHeader = document.querySelector("h1");
                //console.error("header : " + newHeader);
                return newHeader;
            },
            cmp: function (header, newHeader) {
                return !!((!header && newHeader) ||
                    (header && !newHeader) ||
                    (header && !header.isEqualNode(newHeader)));
            }
        }), header = _b.value, headerChanged = _b.dirty;
        // update when the status of the header has changed.
        trackProfileName.update({
            prerequisites: [
                headerChanged
            ],
            query: function () {
                var _a;
                if (!header) {
                    return null;
                }
                return (_a = (0, utils_1.getUsersNameOnProfile)()) !== null && _a !== void 0 ? _a : null;
            },
        });
        var backgroundUrl = trackBackgroundUrl.update({
            throttle: 1000,
            resetThrottle: headerChanged,
            query: function () {
                var _a;
                if (trackOnFeedUrl.get()) {
                    var el = qs("div.feed-identity-module__member-bg-image");
                    var url_1 = el ? [0].reduce(function (acc) { return acc === null || acc === void 0 ? void 0 : acc.slice(0, acc.length - 2); }, el === null || el === void 0 ? void 0 : el.style.backgroundImage.replace("url(\"", "")) : null;
                    return url_1;
                }
                else if (trackOnProfileUrl.get()) {
                    var el = qs("#profile-background-image-target-image");
                    if (!el && qs('div.profile-background-image--default')) {
                        return 'default';
                    }
                    var url_2 = (_a = el === null || el === void 0 ? void 0 : el.src) !== null && _a !== void 0 ? _a : null;
                    return url_2;
                }
                return null;
            },
        }).value;
        var profilePictureUrl = trackProfilePictureUrl.update({
            throttle: 1000,
            resetThrottle: headerChanged,
            query: function () {
                var _a, _b;
                if (!onProfileUrl && !onFeedUrl) {
                    return null;
                }
                if (onProfileUrl) {
                    var images = qsa("img.pv-top-card-profile-picture__image, img.profile-photo-edit__preview");
                    // verbose("Profile image url", images);
                    if (images.length > 0) {
                        var profileImageUrl = (_a = images[0]) === null || _a === void 0 ? void 0 : _a.src;
                        if (profileImageUrl === 'https://static.licdn.com/sc/h/13m4dq9c31s1sl7p7h82gh1vh') {
                            var style = getComputedStyle(images[0]).backgroundImage;
                            var url_3 = images[0] ? [0].reduce(function (acc) { return acc === null || acc === void 0 ? void 0 : acc.slice(0, acc.length - 2); }, getComputedStyle(images[0]).backgroundImage.replace("url(\"", "")) : null;
                            return url_3;
                        }
                        return profileImageUrl;
                    }
                    else {
                        var editPhoto = qs('.profile-photo-edit');
                        if (editPhoto) {
                            return 'default';
                        }
                    }
                    return null;
                }
                if (onFeedUrl) {
                    var smallProfileImageUrl = qs("img.feed-identity-module__member-photo");
                    return (_b = smallProfileImageUrl === null || smallProfileImageUrl === void 0 ? void 0 : smallProfileImageUrl.src) !== null && _b !== void 0 ? _b : null;
                }
                return null;
            },
        }).value;
        trackOnOwnFeed.update({
            throttle: 1000,
            resetThrottle: headerChanged,
            query: function () {
                /*console.log({
                    onOwnPageOrFeed,
                    trackOnFeedUrl: trackOnFeedUrl.get(),
                    el: qs("div.feed-identity-module__member-bg-image"),
                });*/
                if (!onOwnPageOrFeed) {
                    return false;
                }
                if (!trackOnFeedUrl.get()) {
                    return false;
                }
                if (qs("div.feed-identity-module__member-bg-image")) {
                    return true;
                }
                return false;
            },
        });
        /* const {value: onOwnPage} = */ trackOnOwnPage.update({
            throttle: 1000,
            query: function () {
                if (!onOwnPageOrFeed || !onProfileUrl) {
                    return false;
                }
                var el = qs("#profile-background-image-target-image");
                var backgroundImg = onProfileUrl ? el : qs('div.profile-background-image--default');
                return onProfileUrl && !!backgroundImg;
            },
        });
        // Set the status weather we should be updating verification. This can be used to trigger a verification
        trackVerifyStatus.update({
            // throttle: 250,
            query: function () {
                // console.log('trackVerifyStatus : ' + backgroundUrl);
                var ret = (onProfileUrl || onFeedUrl) &&
                    ((onProfileUrl && !!header) || onFeedUrl) &&
                    ((onProfileUrl && !!shield) || onFeedUrl) &&
                    !!backgroundUrl &&
                    !!profilePictureUrl &&
                    !!profileUserId ?
                    url + backgroundUrl + profilePictureUrl + profileUserId : null;
                /* console.log('trackVerifyStatus : ', {
                    "(onProfileUrl || onFeedUrl)": (onProfileUrl || onFeedUrl),
                    '((onProfileUrl && !!header) || onFeedUrl)': ((onProfileUrl && !!header) || onFeedUrl),
                    '((onProfileUrl && !!shield) || onFeedUrl)':((onProfileUrl && !!shield) || onFeedUrl),
                    "!!backgroundUrl": backgroundUrl,
                    "!!profilePictureUrl": profilePictureUrl,
                    "!!profileUserId": profileUserId,
                    ret
                });	*/
                return ret;
            },
        });
    };
};
var sleep = function (dt) {
    if (dt === void 0) { dt = 1000; }
    return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        return [2 /*return*/, new Promise(function (resolve) { return setTimeout(resolve, dt); })];
    }); });
};
var changeBackgroundTour = {
    onTourStart: function (tour) {
        tour.background = (0, tour_1.createTourWidget)();
        tour.background.show();
    },
    onTourDone: function (tour) {
        tour.background.hide();
    },
    onTourError: function (tour) {
        var _a;
        (_a = tour === null || tour === void 0 ? void 0 : tour.loadingPopup) === null || _a === void 0 ? void 0 : _a.destroy();
    },
    onTourCancel: function (tour) {
        var _a, _b;
        var u = (_b = (_a = (0, utils_1.getUserIdInUrl)()) !== null && _a !== void 0 ? _a : (0, utils_1.getUserIdOnPageFeed)()) !== null && _b !== void 0 ? _b : '';
        if (u) {
            utils_1.registrations.setRegStep(root_1.mysome.platform, u, 6).then().catch(console.error);
        }
        else {
            console.error('No user id while cancelling tour - could not change the status of the registration.');
        }
    },
    steps: [
        {
            activate: function (tour) { return __awaiter(void 0, void 0, void 0, function () {
                var context;
                var _a, _b;
                return __generator(this, function (_c) {
                    context = (0, popup_1.showFinalizePopup)({
                        u: (_b = (_a = (0, utils_1.getUserIdInUrl)()) !== null && _a !== void 0 ? _a : (0, utils_1.getUserIdOnPageFeed)()) !== null && _b !== void 0 ? _b : '',
                        p: root_1.mysome.platform,
                    });
                    context.onResult = function (v) {
                        if (v === 'cancel') {
                            tour.cancel();
                        }
                        else if (v === 'continue') {
                            tour.loadingPopup = (0, popup_1.showLoadingPopup)({
                                message: 'Changing your background',
                                bgColor: '#000000FF'
                            });
                            tour.nextStep();
                        }
                    };
                    return [2 /*return*/];
                });
            }); },
        },
        {
            activate: function (tour) { return __awaiter(void 0, void 0, void 0, function () {
                var userId, loc, onProfile, onFeed, max_1, a, max, reg, editBgButton, _a, blob, imageType, file, container, changeBackgroundFound, addBackgroundViewFound, editProfileBackgroundButton, max, input, max, input, notFnd, applyButton, cnt;
                var _b, _c, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
                return __generator(this, function (_t) {
                    switch (_t.label) {
                        case 0:
                            userId = null;
                            userId = (0, utils_1.getUserIdInUrl)();
                            loc = window.location.href.toLowerCase();
                            onProfile = loc.indexOf('/in/' + userId + '/') >= 0 &&
                                qs('.profile-topcard-background-image-edit__icon');
                            if (!!onProfile) return [3 /*break*/, 7];
                            console.log('# 2a');
                            onFeed = loc.indexOf('/feed/') >= 0;
                            if (!!onFeed) return [3 /*break*/, 3];
                            (_b = document.querySelector("a.app-aware-link")) === null || _b === void 0 ? void 0 : _b.click();
                            max_1 = 0;
                            _t.label = 1;
                        case 1:
                            if (!!document.querySelector(".feed-identity-module")) return [3 /*break*/, 3];
                            if (max_1++ > 4 * 60) {
                                throw new Error('Timed out');
                            }
                            return [4 /*yield*/, sleep(250)];
                        case 2:
                            _t.sent();
                            return [3 /*break*/, 1];
                        case 3:
                            console.log('# 2b');
                            a = (_c = document.querySelector(".feed-identity-module")) === null || _c === void 0 ? void 0 : _c.querySelector('a');
                            a === null || a === void 0 ? void 0 : a.click();
                            console.log('# 2c');
                            if (!a) {
                                console.error('Feed profile link not found.');
                            }
                            max = 0;
                            console.log('# 2d');
                            _t.label = 4;
                        case 4:
                            if (!!document.querySelector(".profile-topcard-background-image-edit")) return [3 /*break*/, 6];
                            if (max++ > 4 * 60) {
                                throw new Error('Timed out');
                            }
                            return [4 /*yield*/, sleep(250)];
                        case 5:
                            _t.sent();
                            return [3 /*break*/, 4];
                        case 6:
                            console.log('# 2e');
                            _t.label = 7;
                        case 7:
                            console.log('# 2f');
                            userId = (0, utils_1.getUserIdInUrl)();
                            if (!userId) {
                                console.log('# 2g');
                                tour.endWithError('Failed changing background (1)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            reg = utils_1.registrations.select(root_1.mysome.platform, userId);
                            console.log('# 2g');
                            if (!reg) {
                                tour.endWithError('Failed changing background (2)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            console.log('# 3');
                            editBgButton = (_e = document.querySelector(".profile-topcard-background-image-edit")) === null || _e === void 0 ? void 0 : _e.querySelector("button");
                            // document.querySelector<HTMLElement>(".profile-topcard-background-image-edit")?.querySelector<HTMLElement>("button");
                            if (!editBgButton) {
                                tour.endWithError('Failed changing background (3)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            editBgButton === null || editBgButton === void 0 ? void 0 : editBgButton.click();
                            // Give it some time to render.
                            return [4 /*yield*/, sleep(250)];
                        case 8:
                            // Give it some time to render.
                            _t.sent();
                            console.log('# 4 - fetching stored background image');
                            _a = (0, utils_1.base64ToBlob)(reg.image), blob = _a.blob, imageType = _a.imageType;
                            file = new File([blob], 'image.png', { type: imageType !== null && imageType !== void 0 ? imageType : 'image/png', lastModified: new Date().getTime() });
                            container = new DataTransfer();
                            container.items.add(file);
                            changeBackgroundFound = (_h = (_g = (_f = qsa("div").find(function (x) { return x.innerText === 'Background photo'; })) === null || _f === void 0 ? void 0 : _f.parentElement) === null || _g === void 0 ? void 0 : _g.parentElement) === null || _h === void 0 ? void 0 : _h.qsa("label").find(function (x) { return x.innerText === "Change photo"; });
                            addBackgroundViewFound = qsa("h2").find(function (x) { return x.innerText.trim() === 'Add background photo'; });
                            editProfileBackgroundButton = document.querySelector('[aria-label="Edit profile background"]');
                            console.log({
                                changeBackgroundFound: changeBackgroundFound,
                                addBackgroundViewFound: addBackgroundViewFound,
                                editProfileBackgroundButton: editProfileBackgroundButton,
                            });
                            if (!(!changeBackgroundFound && addBackgroundViewFound && editProfileBackgroundButton)) return [3 /*break*/, 13];
                            console.log('# 5a - We have not previously added a background picture');
                            max = 0;
                            return [4 /*yield*/, sleep(1000)];
                        case 9:
                            _t.sent();
                            // profile-topcard-background-image_file-upload-input
                            console.log('# 6a - Locating input');
                            input = (_k = (_j = document.querySelector('input[aria-label="Edit profile background"]')) !== null && _j !== void 0 ? _j : Array.prototype.slice.call(document.querySelectorAll("input")).find(function (x) { return x.accept === 'image/*'; })) !== null && _k !== void 0 ? _k : null;
                            if (input) {
                                console.log('# 6a - dispatching change event.');
                                input.files = container.files;
                                input.dispatchEvent(new Event('change'));
                            }
                            else {
                                console.error('Failed to locate element to add the image to.');
                            }
                            _t.label = 10;
                        case 10:
                            if (!!document.querySelector('footer.image-edit-tool-footer')) return [3 /*break*/, 12];
                            console.log('# 7a');
                            return [4 /*yield*/, sleep(1000)];
                        case 11:
                            _t.sent();
                            if (max++ > 30) {
                                tour.endWithError('Failed changing background (4)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            return [3 /*break*/, 10];
                        case 12:
                            console.log('# 8a');
                            return [3 /*break*/, 17];
                        case 13:
                            console.log('# 5b - We have previously set a background image.');
                            max = 0;
                            _t.label = 14;
                        case 14:
                            if (!!document.querySelector('footer.image-edit-tool-footer')) return [3 /*break*/, 16];
                            if (max++ > 4 * 60) {
                                tour.endWithError('Failed changing background (4)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            return [4 /*yield*/, sleep(250)];
                        case 15:
                            _t.sent();
                            return [3 /*break*/, 14];
                        case 16:
                            console.log('# 6b - find the input field.');
                            input = (_p = (_o = (_m = (_l = document.querySelector('.artdeco-modal')) === null || _l === void 0 ? void 0 : _l.querySelector('input.visually-hidden')) !== null && _m !== void 0 ? _m : document.querySelector("input#background-image-cropper__file-upload-input.hidden")) !== null && _o !== void 0 ? _o : Array.prototype.slice.call(document.querySelectorAll('input')).filter(function (x) { return x.accept === 'image/*'; })[0]) !== null && _p !== void 0 ? _p : null;
                            console.log("# 6b - Background picture input", input);
                            if (!input) {
                                tour.endWithError('Failed changing background (5)', 'Please try again later or change the background manually.');
                                return [2 /*return*/];
                            }
                            console.log('# 7b');
                            input.files = container.files;
                            input.dispatchEvent(new Event('change'));
                            console.log("Background image changed");
                            _t.label = 17;
                        case 17:
                            console.log('# 8 - Apply');
                            return [4 /*yield*/, sleep(1250)];
                        case 18:
                            _t.sent();
                            notFnd = 0;
                            _t.label = 19;
                        case 19:
                            if (!document.querySelector('footer.image-edit-tool-footer')) return [3 /*break*/, 26];
                            console.log('Getting Apply Button');
                            applyButton = (_s = (_r = Array.prototype.slice.call((_q = document.querySelector('footer.image-edit-tool-footer')) === null || _q === void 0 ? void 0 : _q.querySelectorAll('span'))) === null || _r === void 0 ? void 0 : _r.filter(function (x) { var _a; return ((_a = x.innerText) === null || _a === void 0 ? void 0 : _a.indexOf('Apply')) >= 0; })[0]) === null || _s === void 0 ? void 0 : _s.parentElement;
                            console.log('Apply Button resolved : ' + (!!applyButton ? 'Yes' : 'No'));
                            if (!!applyButton) return [3 /*break*/, 21];
                            console.error("Apply button not found.");
                            return [4 /*yield*/, sleep(1000)];
                        case 20:
                            _t.sent();
                            if (notFnd++ > 10) {
                                console.error("Failed to find Apply button"); // TODO: Show error message to user.
                                tour.endWithError('Failed to change background', 'Please try setting the background manually');
                                return [2 /*return*/];
                            }
                            else {
                                console.log("Retrying finding Apply Button");
                            }
                            return [3 /*break*/, 19];
                        case 21:
                            if (!applyButton) {
                                console.error("Error - cannot find apply button.");
                            }
                            console.log("Clicking Apply button", applyButton);
                            applyButton === null || applyButton === void 0 ? void 0 : applyButton.click();
                            console.log("Clicked the apply button");
                            _t.label = 22;
                        case 22:
                            cnt = 0;
                            _t.label = 23;
                        case 23:
                            if (!(document.querySelector('footer.image-edit-tool-footer') && cnt++ < 30)) return [3 /*break*/, 25];
                            console.log("Waiting for apply to disappear");
                            return [4 /*yield*/, sleep(1000)];
                        case 24:
                            _t.sent();
                            return [3 /*break*/, 23];
                        case 25: return [3 /*break*/, 19];
                        case 26:
                            console.log('# 10');
                            tour === null || tour === void 0 ? void 0 : tour.nextStep();
                            return [2 /*return*/];
                    }
                });
            }); },
            onActivateException: function (tour) {
                tour === null || tour === void 0 ? void 0 : tour.endWithError('Failed to change background', 'Please try setting the background manually');
                tour === null || tour === void 0 ? void 0 : tour.nextStep();
            },
        },
        {
            activate: function (tour) { return __awaiter(void 0, void 0, void 0, function () {
                var u, args, context;
                var _a, _b, _c;
                return __generator(this, function (_e) {
                    u = (_b = (_a = (0, utils_1.getUserIdInUrl)()) !== null && _a !== void 0 ? _a : (0, utils_1.getUserIdOnPageFeed)()) !== null && _b !== void 0 ? _b : '';
                    args = (0, utils_1.objToUrlParms)({
                        u: u,
                        p: root_1.mysome.platform,
                        title: encodeURIComponent('Registration Done'),
                        message: encodeURIComponent('Your profile is verified.'),
                        primary: 'OK',
                        secondary: '',
                    });
                    (_c = tour === null || tour === void 0 ? void 0 : tour.loadingPopup) === null || _c === void 0 ? void 0 : _c.destroy();
                    context = root_1.mysome.createPopup("widget/index.html", "#/message?".concat(args), {
                        closeOnBgClick: false,
                        bgColor: 'transparent',
                    });
                    context.onResult = function (v) {
                        // Store the next step.
                        utils_1.registrations.setRegStep(root_1.mysome.platform, u, 6).then(function () {
                            tour.done();
                        }).catch(function (err) {
                            console.error(err);
                            tour.endWithError('Failed updating registration', 'Please retry uploading background.');
                        });
                    };
                    return [2 /*return*/];
                });
            }); },
        },
    ]
};
function showNotVerifiedPopup() {
    (0, popup_1.showMessagePopup)({
        title: 'Your LinkedIn profile is not verified',
        message: 'Secure your account now by self-issuing a certificate to prove your account ownership.<br/><br/>The certificate contains a cryptographic proof used to let other know that you are who you claim to be to prevent risks of identity theft and fraud.',
        primary: 'SECURE PROFILE',
        secondary: 'CANCEL',
        primary_link: getCreateLink(),
    });
    utils_1.storage.set("content-welcome-shown", true).then(function () { }).catch(console.error);
}
var validateProofWithProfile = function (_a) {
    var firstName = _a.firstName, lastName = _a.lastName, proofUrl = _a.proofUrl, userData = _a.userData, platform = _a.platform;
    return __awaiter(void 0, void 0, void 0, function () {
        var base, url;
        return __generator(this, function (_b) {
            base = SERVICE_BASE_URL();
            proofUrl = encodeURIComponent(proofUrl);
            firstName = encodeURIComponent(firstName);
            lastName = encodeURIComponent(lastName);
            userData = encodeURIComponent(userData);
            url = "".concat(base, "/proof/validate-proof-url?url=").concat(proofUrl, "&firstName=").concat(firstName, "&lastName=").concat(lastName, "&platform=").concat(platform, "&userData=").concat(userData);
            return [2 /*return*/, fetch(url).then(function (res) {
                    return res.json();
                }).then(function (obj) {
                    return obj !== null && obj !== void 0 ? obj : { status: null };
                })];
        });
    });
};
var getCreateLink = function () {
    var template = 'template=' + encodeURIComponent((0, utils_1.utf8_to_b64)(JSON.stringify({
        userId: trackOwnProfileUserId.get(),
        platform: root_1.mysome.platform,
        name: trackOwnProfileName.get(),
        profilePicUrl: trackProfilePictureUrl.get(),
        backgroundPicUrl: trackBackgroundUrl.get(),
    })));
    var base = WEBSITE_BASE_URL();
    return "".concat(base, "/create/2?").concat(template);
};
function showWelcomePopup() {
    (0, popup_1.showMessagePopup)({
        title: 'Thank you for installing mysome.id',
        message: 'To get started you must link a proof of account ownership to your profile<br/><br/>Tip: If you need additional assistance, you can always click on the mysome.id shield or badge',
        className: 'badge-popup',
        primary: 'Create Proof',
        secondary: 'CANCEL',
        primary_link: getCreateLink(),
    });
    utils_1.storage.set("content-welcome-shown", true).then(function () { }).catch(console.error);
}
var install = function () { return __awaiter(void 0, void 0, void 0, function () {
    var requestToFetchProfile, regs, badgeClickHandler, badge, check;
    var _a, _b;
    return __generator(this, function (_c) {
        switch (_c.label) {
            case 0:
                utils_1.logger.info("Install linkedIn Hooks");
                (0, content_messaging_1.getMessageHandler)().addMessageHandler(function (data) {
                    var type = data.type;
                    switch (type) {
                        case 'show-content-widget':
                            root_1.mysome === null || root_1.mysome === void 0 ? void 0 : root_1.mysome.badgeClickHandler();
                            break;
                    }
                });
                root = (0, root_1.createRootWidget)();
                return [4 /*yield*/, utils_1.storage.get("li.nvisit")];
            case 1:
                // How many times we have visited the website.
                nvisit = (_a = (_c.sent())) !== null && _a !== void 0 ? _a : 0;
                return [4 /*yield*/, utils_1.storage.set("li.nvisit", nvisit + 1)];
            case 2:
                _c.sent();
                return [4 /*yield*/, utils_1.storage.get("content-welcome-shown")];
            case 3:
                welcomeShown = _c.sent();
                utils_1.logger.info("welcomeShown ", welcomeShown);
                root_1.mysome.info = {
                    welcomeShown: welcomeShown,
                    'li.nvisit': nvisit + 1,
                };
                return [4 /*yield*/, utils_1.platformRequests.select('li', 'created', 'fetch-profile')];
            case 4:
                requestToFetchProfile = (_b = (_c.sent())) !== null && _b !== void 0 ? _b : null;
                root_1.mysome.requests = requestToFetchProfile !== null && requestToFetchProfile !== void 0 ? requestToFetchProfile : [];
                console.log("requests", root_1.mysome.requests);
                return [4 /*yield*/, utils_1.registrations.fetch()];
            case 5:
                regs = _c.sent();
                console.log("registrations", regs);
                // 
                root_1.mysome.tours = {
                    'li.finalize': changeBackgroundTour,
                };
                tracking_1.tracking.on('ownProfileUserIdObserved', function (userId) {
                    console.log("Own profile name obseved ", userId);
                    root_1.mysome.onPlatformObserved(root_1.mysome.platform, userId); // when a user has been logging into the platform.
                    var reqs = root_1.mysome.requests;
                    if (reqs && reqs.length > 0) {
                        console.log("requests", reqs);
                        var req = reqs[0];
                        utils_1.platformRequests.removeRequests('li').then(function () {
                            (0, popup_1.showMessagePopup)({
                                title: 'Get Profile Info',
                                message: 'Do you want to secure your profile?',
                                secondary: 'CANCEL',
                                primary: 'Continue',
                                primary_link: getCreateLink(),
                            });
                        });
                        return;
                    }
                    var reg = utils_1.registrations.select('li', userId);
                    console.log("Own Profile registration: ", reg);
                    if (reg && reg.step === 5) {
                        root_1.mysome.createTour('li.finalize');
                    }
                });
                tracking_1.tracking.on('otherProfileObserved', function (userId) {
                    var reg = utils_1.registrations.select('li', userId);
                    if (reg && reg.step === 5) {
                        console.error("Other profile observed but there is a registration! (this is not supposed to happen)", reg);
                        (0, popup_1.showMessagePopup)({
                            title: 'Warning',
                            message: "You have tried to create a proof for a profile which you dont have access to.<br/><br/>Log in to the profile to finalise the registration.",
                            primary: "Okay",
                        });
                    }
                });
                badgeClickHandler = root_1.mysome.badgeClickHandler = function (params) {
                    var _a, _b, _c, _e, _f, _g, _h, _j, _k, _l;
                    if (shield && (shield === null || shield === void 0 ? void 0 : shield.isLoading())) {
                        return;
                    }
                    var popups = (0, popup_1.countPopupsWithClassName)('badge-popup');
                    console.log('popups ', popups);
                    if (popups > 0) {
                        console.log("ignored showing popup as one other popup is already shown.");
                        return;
                    }
                    // Resolve the params that we want to open the popup
                    var u = (_b = (_a = (0, utils_1.getUserIdInUrl)()) !== null && _a !== void 0 ? _a : (0, utils_1.getUserIdOnPageFeed)()) !== null && _b !== void 0 ? _b : '';
                    var proofUrl = (params !== null && params !== void 0 ? params : {}).proofUrl;
                    if (!proofUrl) {
                        proofUrl = state.proofUrl;
                    }
                    var proofId = (_e = (_c = proofUrl === null || proofUrl === void 0 ? void 0 : proofUrl.split('/')) === null || _c === void 0 ? void 0 : _c[4]) !== null && _e !== void 0 ? _e : '';
                    var proofKey = (_g = (_f = proofUrl === null || proofUrl === void 0 ? void 0 : proofUrl.split('/')) === null || _f === void 0 ? void 0 : _f[5]) !== null && _g !== void 0 ? _g : '';
                    proofUrl = proofId && proofKey ? ['https://app.testnet.mysome.id', trackOnOwnProfileOrFeed.get() ? 'my-proof' : 'v', proofId, proofKey].join('/') : proofUrl;
                    var onProfilePage = trackOnProfileUrl.get();
                    var onOwnProfileOrFeed = trackOnOwnProfileOrFeed.get();
                    var ownUserId = trackOwnProfileUserId.get();
                    console.log("Badge clicked", {
                        ownProfileUserIdbserved: ownUserId,
                        status: profileStatus.get(),
                        u: u,
                        onProfilePage: onProfilePage,
                        onOwnProfileOrFeed: onOwnProfileOrFeed,
                        proofUrl: proofUrl,
                    });
                    // on another users profile page.
                    if (onProfilePage && !onOwnProfileOrFeed) {
                        if (profileStatus.get() !== null) {
                            var status_1 = (_j = (_h = profileStatus === null || profileStatus === void 0 ? void 0 : profileStatus.get()) === null || _h === void 0 ? void 0 : _h.status) !== null && _j !== void 0 ? _j : null;
                            var statusMessage = status_1 === 'no-connection' ?
                                'No connection to the mysome.id service' :
                                status_1 === 'not-registered' ?
                                    'This persons profile is not yet verified.<br/><br/>If you know them you can reach out to them and tell them how to secure their profile using mysome.id.' :
                                    status_1 === 'registered' ?
                                        'This persons profile is verified by mysome.id' :
                                        status_1 === 'suspecious' ?
                                            'This persons profile is not verified or suspecious' :
                                            'This profile status is unknown';
                            var goto = status_1 === 'registered' ? {
                                goto_button: 'View Proof',
                                goto_link: proofUrl,
                                secondary: 'Back',
                            } : {};
                            (0, popup_1.showMessagePopup)(__assign({ title: 'Profile Status', message: statusMessage, className: 'badge-popup', primary: (status_1 !== 'registered' ? 'Okay' : '') }, goto));
                        }
                    }
                    else if (onOwnProfileOrFeed) {
                        if (ownUserId !== null && profileStatus !== null) {
                            var tmp = profileStatus.get();
                            var status_2 = (_l = (_k = profileStatus.get()) === null || _k === void 0 ? void 0 : _k.status) !== null && _l !== void 0 ? _l : null;
                            if (status_2 === 'not-registered') {
                                var reg = utils_1.registrations.select(root_1.mysome.platform, ownUserId);
                                var step = (reg !== null && reg !== void 0 ? reg : {}).step;
                                if (step === 5) {
                                    // Continue the installation process.
                                    console.log("Continue the installation process for LinkedIn: " + ownUserId);
                                    root_1.mysome.createTour('li.finalize');
                                    return;
                                }
                                else if (step > 5) {
                                    var createLink = getCreateLink();
                                    (0, popup_1.showMessagePopup)({
                                        title: 'Your Profile Status',
                                        message: "It seems that your profile is no longer verified.<br/><br/>To resolve this, you need to provide a new verification proof and attach it to your LinkedIn profile.",
                                        className: 'badge-popup',
                                        primary: 'Create Proof',
                                        secondary: 'CANCEL',
                                        primary_link: createLink,
                                    });
                                    return;
                                }
                                else if (!reg) {
                                    showNotVerifiedPopup();
                                    return;
                                }
                            }
                            var goto = status_2 === 'registered' ? {
                                goto_button: 'View Proof',
                                goto_link: proofUrl,
                                secondary: 'Back',
                                primary: '',
                            } : {};
                            var statusMessage = status_2 === 'no-connection' ?
                                'No connection to the mysome.id service' :
                                status_2 === 'not-registered' ?
                                    'Your profile is not yet verified.' :
                                    status_2 === 'registered' ?
                                        'Your profile is verified' :
                                        status_2 === 'suspecious' ?
                                            'Your profile is invalid.<br/><br/>You will appear suspecious to other users on LinkedIn using mysome.id.<br/>To fix this you need to make sure your first name and last name matches the proof.' :
                                            'Your profile status is unknown';
                            if (!welcomeShown && status_2 === 'not-registered') {
                                showWelcomePopup();
                            }
                            else {
                                console.log('Show status with info ', goto);
                                (0, popup_1.showMessagePopup)(__assign({ title: 'Your Profile Status', message: statusMessage, className: 'badge-popup', primary: 'Okay' }, goto));
                            }
                        }
                        else if (!welcomeShown) {
                            showWelcomePopup();
                        }
                    }
                    else {
                    }
                };
                badge = root_1.mysome.createBadge({ showAttention: false });
                badge.addClickHandler(badgeClickHandler);
                // There is a background url.
                tracking_1.tracking.on('backgroundUrlChanged', function (url) {
                    /*if ( onOwnPageOrFeed ) {
                        const _s = ensureWidget();
                        if ( _s ) {
                            verifyProfile(_s, onOwnPageOrFeed);
                        }
                    }*/
                    /*setProfileStatusBackgroundUrl({
                        ...profileStatusObj,
                        url
                    });*/
                });
                tracking_1.tracking.on(trackProofQR.changeEventName, function (proof) {
                    var _a, _b, _c;
                    console.log('Proof changed : ' + proof);
                    var onOwnPageOrFeed = !!tracking_1.tracking.onOwnProfileOrFeed;
                    if (proof && proof !== 'no-connection' && proof !== 'no-proof') {
                        console.log('Proof observed', proof);
                        state.proofUrl = proof;
                        var userId = trackProfileUserId.get();
                        var name_1 = trackProfileName.get();
                        var components = (_a = name_1 === null || name_1 === void 0 ? void 0 : name_1.split(' ')) !== null && _a !== void 0 ? _a : [];
                        var firstName = (_b = components[0]) !== null && _b !== void 0 ? _b : '';
                        var lastName = (_c = components[components.length - 1]) !== null && _c !== void 0 ? _c : '';
                        validateProofWithProfile({
                            firstName: firstName,
                            lastName: lastName,
                            proofUrl: state.proofUrl,
                            userData: userId !== null && userId !== void 0 ? userId : '',
                            platform: 'li',
                        }).then(function (response) {
                            var status = response.status;
                            console.log("VERIFY Result ", response);
                            if (status === 'valid') {
                                shield === null || shield === void 0 ? void 0 : shield.setVerified(proof, onOwnPageOrFeed);
                                badge.showAttention(false);
                                setProfileStatusResolved('profile', onOwnPageOrFeed ? 'own' : 'other', 'registered');
                            }
                            else if (status === 'invalid' || status === 'suspecious') {
                                shield === null || shield === void 0 ? void 0 : shield.setSuspeciousProfile(proof);
                                badge.showAttention(true);
                                setProfileStatusResolved('profile', onOwnPageOrFeed ? 'own' : 'other', 'suspecious');
                            }
                            else {
                                console.error("Failed to evaluate the status of the proof.");
                            }
                        }).catch(function (err) {
                            console.error(err);
                        });
                    }
                    else if (proof === 'no-connection') {
                        utils_1.logger.info("No QR code detected - no connection to API");
                        shield === null || shield === void 0 ? void 0 : shield.setNoConnection();
                        badge.showAttention(true);
                        setProfileStatusResolved('profile', onOwnPageOrFeed ? 'own' : 'other', 'no-connection');
                    }
                    else if (proof === 'no-proof') {
                        utils_1.logger.info("No QR code detected - Profile not detected");
                        onOwnPageOrFeed && (shield === null || shield === void 0 ? void 0 : shield.setOwnProfileNotVerified());
                        !onOwnPageOrFeed && (shield === null || shield === void 0 ? void 0 : shield.setOtherProfileNotVerified());
                        badge.showAttention(true);
                        setProfileStatusResolved('profile', onOwnPageOrFeed ? 'own' : 'other', 'not-registered');
                    }
                    else {
                        utils_1.logger.info("No QR code detected - Profile is not verified.");
                        onOwnPageOrFeed && (shield === null || shield === void 0 ? void 0 : shield.setOwnProfileNotVerified());
                        !onOwnPageOrFeed && (shield === null || shield === void 0 ? void 0 : shield.setOtherProfileNotVerified());
                        badge.showAttention(false);
                        setProfileStatusResolved('profile', onOwnPageOrFeed ? 'own' : 'other', 'not-registered');
                    }
                });
                tracking_1.tracking.on(trackUrl.changeEventName, function (url) {
                    console.log("New url : ", url);
                    if (url.indexOf('/in/') > 0) {
                        badge.show();
                    }
                    else if (url.indexOf('/feed/') > 0) {
                        badge.show();
                    }
                    else {
                        badge.hide();
                    }
                });
                tracking_1.tracking.on(trackPathname.changeEventName, function (pathName) {
                    // If we are on the homescreen with the login form visibile then
                    // we find an open registration created less than 30 seconds ago
                    // and show a message to tell the user to login to continue their
                    // registration.
                    if ((pathName === '/home' || pathName === '/') && !!document.querySelector('form[data-id="sign-in-form"]')) {
                        utils_1.platformRequests.fetch().then(function (requests) {
                            console.log("requests", requests);
                            var foundReq = requests.find(function (x) {
                                var deltaTime = ((new Date().getTime() - x.created) / 1000);
                                return x.platform === 'li' &&
                                    x.status === 'created' &&
                                    deltaTime < 30;
                            });
                            if (foundReq) {
                                (0, popup_1.showMessagePopup)({
                                    title: 'Secure Your Profile',
                                    message: 'Log in to secure your profile with mysome.id',
                                    primary: 'Okay'
                                });
                            }
                        });
                    }
                });
                tracking_1.tracking.on(trackHeader.changeEventName, function (header) {
                    (0, utils_1.verbose)("Header: updated");
                    if (header) {
                        (0, utils_1.verbose)("Header: Aquired header"); //, {preHeader, newHeader: header});
                        shield = ensureWidget();
                    }
                    else if (!header) {
                        (0, utils_1.verbose)("Header: Lost header"); //, {preHeader, newHeader: header});
                        shield === null || shield === void 0 ? void 0 : shield.hide();
                    }
                    else {
                        (0, utils_1.verbose)("Header: changed"); //, {preHeader, newHeader: header});
                    }
                });
                tracking_1.tracking.on(trackProfileUserId.changeEventName, function (profileUserId) {
                    console.log("Profile user id changed : ", profileUserId);
                });
                tracking_1.tracking.on(trackVerifyStatus.changeEventName, function (verifyStatus) {
                    if (!verifyStatus) {
                        trackProofQR.update({
                            query: function () { return null; },
                        });
                        return;
                    }
                    // Reset proof to null if needed.
                    trackProofQR.update({
                        query: function () { return null; },
                    });
                    var profileUserId = trackProfileUserId.get();
                    if (!profileUserId) {
                        trackProofQR.update({
                            query: function () { return null; },
                        });
                        return;
                    }
                    if (!shield && trackOnProfileUrl.get()) {
                        throw new Error('Shield is supposed to be initialised.');
                    }
                    var backgroundImageUrl = trackBackgroundUrl.get();
                    var profilePictureUrl = trackProfilePictureUrl.get();
                    // const onOwnPageOrFeed = !!tracking.onOwnProfileOrFeed;
                    if (shield && trackOnProfileUrl.get()) {
                        shield.setInitialState();
                    }
                    verifyProfile(profileUserId, backgroundImageUrl, profilePictureUrl).then(function (_a) {
                        var profileUserId = _a.profileUserId, qrResult = _a.qrResult, connectionError = _a.connectionError;
                        console.log('Profile verification result ', { qrResult: qrResult, connectionError: connectionError });
                        (0, utils_1.verbose)("qrResult", qrResult);
                        if (trackProfileUserId.get() === profileUserId) {
                            if (qrResult) {
                                connectionError = false;
                                trackProofQR.update({
                                    query: function () { return qrResult; }
                                });
                            }
                            else {
                                trackProofQR.update({
                                    query: function () { return !connectionError ? 'no-proof' : 'no-connection'; }
                                });
                            }
                        }
                        else {
                            throw new Error('Profile has changed during verification');
                        }
                        // verificationStatus
                    }).catch(console.error);
                });
                tracking_1.tracking.on(profileStatus.changeEventName, function (ps) {
                    var page = ps.page, status = ps.status;
                    console.log('Profile status changed ', ps);
                    if (status === 'no-connection') {
                        // console.log('Status ', status);
                        // badge.showAttention(false); // Make sure that badge is not shown.
                        return;
                    }
                    // badge.showAttention(page !== 'other' && (status === 'not-registered' || status === 'suspecious'));
                });
                check = createHeartbeat();
                check();
                window.setInterval(check, 250);
                return [2 /*return*/, {}];
        }
    });
}); };
exports["default"] = install;


/***/ }),

/***/ "./src-content/integrations/mysome-api.ts":
/*!************************************************!*\
  !*** ./src-content/integrations/mysome-api.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
var apiCreated = false;
var fnc = function () {
    console.log("Injecting MySoMe API");
    if (apiCreated) {
        throw new Error('API already created');
    }
    var scriptElement = document.createElement("script");
    scriptElement.id = "mysomeid-injected-script";
    scriptElement.type = "text/javascript";
    scriptElement.src = chrome.runtime.getURL("injected/index.js");
    scriptElement.onload = function () {
        // scriptElement.remove();
    };
    (document.head || document.documentElement).appendChild(scriptElement);
    apiCreated = true;
};
exports["default"] = fnc;


/***/ }),

/***/ "./src-content/integrations/test.ts":
/*!******************************************!*\
  !*** ./src-content/integrations/test.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var utils_1 = __webpack_require__(/*! ../utils */ "./src-content/utils.ts");
var root_1 = __webpack_require__(/*! ../root */ "./src-content/root.ts");
var tour_1 = __webpack_require__(/*! ../tour */ "./src-content/tour.ts");
var injectCode = function () { return __awaiter(void 0, void 0, void 0, function () {
    var tour, el;
    return __generator(this, function (_a) {
        utils_1.logger.info("Install test page hooks");
        (0, root_1.createRootWidget)();
        tour = (0, tour_1.createTourWidget)();
        el = window.document.getElementById("test-div");
        if (el) {
            tour.show(el);
        }
        return [2 /*return*/, {}];
    });
}); };
exports["default"] = injectCode;


/***/ }),

/***/ "./src-content/popup.ts":
/*!******************************!*\
  !*** ./src-content/popup.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.showLoadingPopup = exports.showMessagePopup = exports.showFinalizePopup = exports.createPopup = exports.countPopupsWithClassName = void 0;
var content_messaging_1 = __webpack_require__(/*! ./content-messaging */ "./src-content/content-messaging.ts");
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var numPopups = 0;
var countPopupsWithClassName = function (className) {
    var cnt = 0;
    for (var _i = 0, _a = Object.entries(root_1.mysome.widgets); _i < _a.length; _i++) {
        var widget = _a[_i];
        cnt += widget[1].className === className ? 1 : 0;
    }
    return cnt;
};
exports.countPopupsWithClassName = countPopupsWithClassName;
var createPopup = function (src, route, options, className) {
    if (route === void 0) { route = '#/home'; }
    if (className === void 0) { className = ''; }
    if (numPopups > 0) {
        console.error("Showing more than one popup.");
    }
    numPopups++;
    var _a = options !== null && options !== void 0 ? options : {}, _b = _a.closeOnBgClick, closeOnBgClick = _b === void 0 ? true : _b, _c = _a.bgColor, bgColor = _c === void 0 ? '#c9c9c966' : _c;
    var id = Math.round(Math.random() * 9999999999999);
    root_1.mysome.widgets[id] = {
        id: id,
        src: src,
        route: route,
        className: className,
        created: false,
        creating: true,
        onResult: null,
    };
    (function () { return __awaiter(void 0, void 0, void 0, function () {
        var messageHandler, response, url, e, created, frameView, overlay, iframe, overlayClicked, cnt, interval;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!src) {
                        src = 'widget/index.html';
                    }
                    messageHandler = (0, content_messaging_1.getMessageHandler)();
                    return [4 /*yield*/, messageHandler.sendMessageWResponse('background', 'get-url', {
                            file: src,
                        })];
                case 1:
                    response = _a.sent();
                    url = response.payload.url + route;
                    console.log("url ", url);
                    e = document.createElement('div');
                    created = false;
                    e.id = "mysome-frame-".concat(id);
                    e.innerHTML = "\n\t\t\t<div id=\"mysome-frame-container-".concat(id, "\" style=\"position: fixed;left: 0;top: 0;right: 0;bottom: 0;z-index: 999999;background: ").concat(bgColor, ";display: flex;align-items: center;place-content: center; border: none;\">\n\t\t\t  \t<div id=\"mysome-frame-view-").concat(id, "\" style=\"background: white;max-width: 380px;height: 556px;border-radius: 4px;box-shadow: 0px 1px 34px 9px rgba(0,0,0,0.27);width: 80%;position: fixed;color: black;border-radius: 10px; overflow: hidden;\">\n\t\t\t\t\t<iframe id=\"mysome-frame-iframe-").concat(id, "\" allow src=\"").concat(url, "\" style=\"width: 100%; height: 100%; border: none;\">\n\t\t\t\t\t</iframe>\n\t\t  \t\t</div>\n\t\t\t</div>\n\t  \t");
                    document.body.appendChild(e);
                    frameView = document.getElementById("mysome-frame-view-".concat(id));
                    overlay = document.getElementById("mysome-frame-container-".concat(id));
                    iframe = document.getElementById("mysome-frame-iframe-".concat(id));
                    if (!frameView) {
                        throw new Error('No frame view');
                    }
                    overlayClicked = function (e) {
                        if (!closeOnBgClick)
                            return;
                        console.log("Overlay clicked");
                        root_1.mysome.widgets[id].destroy();
                    };
                    overlay === null || overlay === void 0 ? void 0 : overlay.addEventListener("click", overlayClicked);
                    frameView.style.opacity = '0';
                    cnt = 0;
                    interval = setInterval(function () {
                        if (cnt++ > 30) {
                            console.error('Timed out opening window - this happens if you close the popup before its fully shown.');
                            clearInterval(interval);
                            return;
                        }
                        if (created) {
                            return;
                        }
                        messageHandler.sendMessage("injected-widget", "widget-create", {
                            id: id,
                        });
                    }, 100);
                    root_1.mysome.widgets[id].e = e;
                    root_1.mysome.widgets[id].iframe = iframe;
                    root_1.mysome.widgets[id].url = url;
                    root_1.mysome.widgets[id].destroy = function () {
                        numPopups--;
                        var parent = e.parentElement;
                        if (!parent) {
                            console.error("no parent element of widget.");
                        }
                        overlay === null || overlay === void 0 ? void 0 : overlay.removeEventListener("click", overlayClicked);
                        parent === null || parent === void 0 ? void 0 : parent.removeChild(e);
                        if (root_1.mysome.widgets[id]) {
                            delete root_1.mysome.widgets[id];
                        }
                    };
                    root_1.mysome.widgets[id].setCreated = function () {
                        console.log("widget now created");
                        created = true;
                        root_1.mysome.widgets[id].created = true;
                        root_1.mysome.widgets[id].creating = false;
                        frameView.style.opacity = 'initial'; // show the container.
                        clearInterval(interval);
                    };
                    return [2 /*return*/];
            }
        });
    }); })();
    return root_1.mysome.widgets[id];
};
exports.createPopup = createPopup;
function showFinalizePopup(popupInfo) {
    var args = (0, utils_1.objToUrlParms)(popupInfo);
    var context = root_1.mysome.createPopup("widget/index.html", "#/finalize?".concat(args), { closeOnBgClick: false, bgColor: 'transparent' });
    return context;
}
exports.showFinalizePopup = showFinalizePopup;
function showMessagePopup(_a) {
    var platform = _a.platform, title = _a.title, message = _a.message, className = _a.className, primary = _a.primary, secondary = _a.secondary, primary_link = _a.primary_link, goto_button = _a.goto_button, goto_link = _a.goto_link;
    var args = (0, utils_1.objToUrlParms)(__assign(__assign({ u: '1', p: platform !== null && platform !== void 0 ? platform : 'li', title: encodeURIComponent(title), message: encodeURIComponent(message), primary: encodeURIComponent(primary !== null && primary !== void 0 ? primary : ''), secondary: encodeURIComponent(secondary !== null && secondary !== void 0 ? secondary : '') }, (primary_link ? { primary_link: encodeURIComponent(primary_link) } : {})), (goto_button ? { goto_button: goto_button, goto_link: encodeURIComponent(goto_link !== null && goto_link !== void 0 ? goto_link : '') } : {})));
    var popupWidget = root_1.mysome.createPopup("widget/index.html", "#/message?".concat(args), {
        closeOnBgClick: true,
        // bgColor: 'transparent',
    }, className !== null && className !== void 0 ? className : 'popup');
    return popupWidget;
}
exports.showMessagePopup = showMessagePopup;
function showLoadingPopup(params) {
    var _a = params.title, title = _a === void 0 ? 'Loading' : _a, _b = params.message, message = _b === void 0 ? 'Changing your background' : _b, _c = params.bgColor, bgColor = _c === void 0 ? 'transparent' : _c;
    var args = (0, utils_1.objToUrlParms)({
        u: '1',
        p: 'li',
        title: title,
        message: message,
        primary: null,
        loading: '1',
        secondary: null,
    });
    return root_1.mysome.createPopup("widget/index.html", "#/message?".concat(args), {
        closeOnBgClick: false,
        bgColor: bgColor
    });
}
exports.showLoadingPopup = showLoadingPopup;


/***/ }),

/***/ "./src-content/root.ts":
/*!*****************************!*\
  !*** ./src-content/root.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.mysome = exports.createRootWidget = exports.getRootWidget = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var tour_1 = __webpack_require__(/*! ./tour */ "./src-content/tour.ts");
var frame_1 = __webpack_require__(/*! ./frame */ "./src-content/frame.ts");
var popup_1 = __webpack_require__(/*! ./popup */ "./src-content/popup.ts");
var shield_1 = __webpack_require__(/*! ./shield */ "./src-content/shield.ts");
/*import {
    // PopupWidget,
    popupWidget as createPopupWidget,
} from './popup';**/
var badge_1 = __webpack_require__(/*! ./badge */ "./src-content/badge.ts");
var content_messaging_1 = __webpack_require__(/*! ./content-messaging */ "./src-content/content-messaging.ts");
var instance = null;
var getRootWidget = function () {
    if (!instance) {
        throw new Error("No root");
    }
    return instance;
};
exports.getRootWidget = getRootWidget;
var createRootWidget = function () {
    console.log("creating root");
    if (instance) {
        return instance;
    }
    var root = document.getElementById("mysome-root");
    if (!root) {
        root = document.createElement('div');
        root.id = "mysome-root";
        root.innerHTML = "\n\t\t\t<style>\n\t\t\t</style>\n\t\t\t<div id=\"mysome-dummy\"></div>\n\t\t";
        document.body.appendChild(root);
    }
    else {
        utils_1.logger.error("Root element already existed! This may make the plugin stop working.");
    }
    instance = {
        elements: {
            root: root,
        },
        methods: {
            createTourWidget: tour_1.createTourWidget,
            createFrameWidget: frame_1.createFrameWidget,
            createPopupWidget: popup_1.createPopup,
            createShieldWidget: shield_1.createShieldWidget,
        },
    };
    window.mysomeid = instance;
    console.log("Created root");
    return instance;
};
exports.createRootWidget = createRootWidget;
var onPlatformObserved = function (platform, userName) {
    var messageHandler = (0, content_messaging_1.getMessageHandler)();
    messageHandler.sendMessageWResponse('background', 'set-platform-observed', {
        platform: platform,
        userId: userName,
    }).then().catch(console.error);
};
exports.mysome = {
    widgets: {},
    createTour: tour_1.createTour,
    endTour: tour_1.endTour,
    createPopup: popup_1.createPopup,
    createShield: shield_1.createShieldWidget,
    createBadge: badge_1.createBadge,
    tour: null,
    regs: null,
    onPlatformObserved: onPlatformObserved,
    platform: 'li',
};


/***/ }),

/***/ "./src-content/shield.ts":
/*!*******************************!*\
  !*** ./src-content/shield.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createShieldWidget = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var createShieldWidget = function (nameElement, _a) {
    var onClicked = _a.onClicked;
    var resolveRootChildren = function () {
        var container = document.getElementById('mysome-shield-container');
        var shield = document.getElementById('mysome-shield-widget');
        var dots = document.getElementById('mysome-shield-dots');
        var check = document.getElementById('mysome-shield-check');
        var tooltip = document.getElementById('mysome-shield-tooltip');
        var exclaim = document.getElementById('mysome-shield-exclaim');
        /*console.log({
            container,
            shield,
            dots,
            check,
            tooltip,
        });*/
        if (!container || !dots || !shield || !check || !tooltip || !exclaim) {
            throw new Error('mysomeid: Failed to inject the mysome.id extension to profile page');
        }
        return {
            container: container,
            shield: shield,
            dots: dots,
            check: check,
            tooltip: tooltip,
            exclaim: exclaim,
        };
    };
    var shieldColorLoading = '#b9b9b9';
    var shieldColorVerified = '#4da3f8';
    // const shieldColorNotVerified = '#f8b24d';
    var shieldColorYellow = 'rgb(171 127 0)';
    var shieldColorRed = '#D5645D';
    var dotsLeftOffset = 6;
    var dotsWH = 4;
    var dotsRadius = 2;
    var dotsColor = '#000000';
    var dotsAnimColor = 'rgba(0, 0, 0, 0.2)';
    var tooltipTextVerified = 'mysome.id:</br></br>Profile Verified';
    var tooltipTextOwnProfileVerified = 'mysome.id</br></br>Your profile is secure';
    var tooltipTextNotVerified = 'mysome.id</br></br>Profile NOT verified';
    var tooltipTextOwnProfileNotVerified = 'mysome.id</br></br>You are not secured</br></br>Click to get started';
    var tooltipTextOtherProfileNotVerified = 'mysome.id</br></br>This profile is not verified.</br>';
    var tooltipTextNoConnection = 'mysome.id</br></br>No Connection</br>';
    var state;
    var created = false;
    var proofUrl = '';
    if (!document.getElementById('mysome-shield-root')) {
        var shieldShape = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjNweCIgaGVpZ2h0PSIyM3B4IiB2aWV3Qm94PSIwIDAgMjMgMjMiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9InNoaWVsZCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTEuMDAwMDAwLCAtMS4wMDAwMDApIiBmaWxsPSIjRDhEOEQ4Ij4KICAgICAgICAgICAgPGcgaWQ9Ik92YWwiPgogICAgICAgICAgICAgICAgPGVsbGlwc2UgY3g9IjEyLjUiIGN5PSIxMi41IiByeD0iMTEuNSIgcnk9IjExIj48L2VsbGlwc2U+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==';
        var checkmarkSvg = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTNweCIgaGVpZ2h0PSIxMXB4IiB2aWV3Qm94PSIwIDAgMTMgMTEiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDU1LjIgKDc4MTgxKSAtIGh0dHBzOi8vc2tldGNoYXBwLmNvbSAtLT4KICAgIDx0aXRsZT52ZXJpZmllZC11c2VyLXNoaWVsZC1jaGVjayBjb3B5IDI8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0idmVyaWZpZWQtdXNlci1zaGllbGQtY2hlY2stY29weS0yIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNi4wMDAwMDAsIC03LjAwMDAwMCkiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iUGF0aCIgcG9pbnRzPSIwIDAgMjUgMCAyNSAyNSAwIDI1Ij48L3BvbHlnb24+CiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJTaGFwZSIgZmlsbD0iIzJEMkQyRCIgZmlsbC1ydWxlPSJub256ZXJvIiBwb2ludHM9IjEwLjQxNjY2NjcgMTcuNzA4MzMzMyA2LjI1IDEzLjU0MTY2NjcgNy43MTg3NSAxMi4wNzI5MTY3IDEwLjQxNjY2NjcgMTQuNzYwNDE2NyAxNy4yODEyNSA3Ljg5NTgzMzMzIDE4Ljc1IDkuMzc1Ij48L3BvbHlnb24+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=";
        var exclaimationSvg = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iM3B4IiBoZWlnaHQ9IjE0cHgiIHZpZXdCb3g9IjAgMCAzIDE0IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA1NS4yICg3ODE4MSkgLSBodHRwczovL3NrZXRjaGFwcC5jb20gLS0+CiAgICA8dGl0bGU+ZXhjbGFpbWF0aW9uPC90aXRsZT4KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPgogICAgPGcgaWQ9IlBhZ2UtMSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9ImV4Y2xhaW1hdGlvbiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTExLjAwMDAwMCwgLTYuMDAwMDAwKSI+CiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJQYXRoIiBmaWxsPSIjRkZGRkZGIiBvcGFjaXR5PSIwIiBwb2ludHM9IjAgMCAyNSAwIDI1IDI1IDAgMjUiPjwvcG9seWdvbj4KICAgICAgICAgICAgPHBvbHlnb24gaWQ9IlNoYXBlIiBmaWxsPSIjRDhEOEQ4IiBmaWxsLXJ1bGU9Im5vbnplcm8iIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEyLjQ5MjYyNiwgMTAuOTMzMDc3KSByb3RhdGUoLTQ1LjAwMDAwMCkgdHJhbnNsYXRlKC0xMi40OTI2MjYsIC0xMC45MzMwNzcpICIgcG9pbnRzPSI5LjUxODQ3MzQgMTUuMTkyMTE0MiA4LjE3ODc2MzE0IDEzLjg1MjQwMzkgMTQuNzI5NTY2NSA2LjY3NDA0MDU4IDE2LjgwNjQ4OSA4Ljc1MDk2MzA5Ij48L3BvbHlnb24+CiAgICAgICAgICAgIDxjaXJjbGUgaWQ9Ik92YWwiIGZpbGw9IiNEOEQ4RDgiIGN4PSIxMi41IiBjeT0iMTguNSIgcj0iMS41Ij48L2NpcmNsZT4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==';
        var verifiedElem = document.createElement('div');
        verifiedElem.style.marginLeft = '10px';
        verifiedElem.style.display = 'inline';
        verifiedElem.id = 'mysome-shield-root';
        verifiedElem.innerHTML = "\n\t\t\t<style>\n\t\t\t\t#mysome-shield-dots {\n\t\t\t\t\tposition: relative;\n\t\t\t\t\twidth: ".concat(dotsWH, "px;\n\t\t\t\t\theight: ").concat(dotsWH, "px;\n\t\t\t\t\tborder-radius: ").concat(dotsRadius, "px;\n\t\t\t\t\tbackground-color: ").concat(dotsColor, ";\n\t\t\t\t\tcolor: ").concat(dotsColor, ";\n\t\t\t\t\tanimation: mysome-shield-dots 1s infinite linear alternate;\n\t\t\t\t\tanimation-delay: 0.5s;\n\t\t\t\t}\n\t\n\t\t\t\t#mysome-shield-dots::before, #mysome-shield-dots::after {\n\t\t\t\t\tcontent: \"\";\n\t\t\t\t\tdisplay: inline-block;\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\ttop: 0;\n\t\t\t\t}\n\t\n\t\t\t\t#mysome-shield-dots::before {\n\t\t\t\t\tleft: -").concat(dotsLeftOffset, "px;\n\t\t\t\t\twidth: ").concat(dotsWH, "px;\n\t\t\t\t\theight: ").concat(dotsWH, "px;\n\t\t\t\t\tborder-radius: ").concat(dotsRadius, "px;\n\t\t\t\t\tbackground-color: ").concat(dotsColor, ";\n\t\t\t\t\tcolor: ").concat(dotsColor, ";\n\t\t\t\t\tanimation: mysome-shield-dots 1s infinite alternate;\n\t\t\t\t\tanimation-delay: 0s;\n\t\t\t\t}\n\t\n\t\t\t\t#mysome-shield-dots::after {\n\t\t\t\t\tleft: ").concat(dotsLeftOffset, "px;\n\t\t\t\t\twidth: ").concat(dotsWH, "px;\n\t\t\t\t\theight: ").concat(dotsWH, "px;\n\t\t\t\t\tborder-radius: ").concat(dotsRadius, "px;\n\t\t\t\t\tbackground-color: ").concat(dotsColor, ";\n\t\t\t\t\tcolor: ").concat(dotsColor, ";\n\t\t\t\t\tanimation: mysome-shield-dots 1s infinite alternate;\n\t\t\t\t\tanimation-delay: 1s;\n\t\t\t\t}\n\n\t\t\t\t@keyframes mysome-shield-dots {\n\t\t\t\t\t0% {\n\t\t\t\t\t\tbackground-color: ").concat(dotsColor, ";\n\t\t\t\t\t}\n\t\t\t\t\t50%, 100% {\n\t\t\t\t\t\tbackground-color: ").concat(dotsAnimColor, ";\n\t\t\t\t\t}\n\t\t\t\t}\n\n\t\t\t\t#mysome-shield-container #mysome-shield-tooltip {\n\t\t\t\t\tvisibility: hidden;\n\t\t\t\t\twidth: 200px;\n\t\t\t\t\tbackground-color: black;\n\t\t\t\t\tcolor: #fff;\n\t\t\t\t\tpadding: 5px;\n\t\t\t\t\tborder-radius: 4px;\n\t\t\t\t\tbottom: 111%;\n\t\t\t\t\tmargin-left: -87px;\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\tz-index: 9999;\n\t\t\t\t\tfont-size: 14px;\n\t\t\t\t\tmin-height: 60px;\n\t\t\t\t\ttext-align: center;\n\t\t\t\t\tdisplay: flex;\n\t\t\t\t\talign-items: center;\n\t\t\t\t\tcursor: pointer;\n\t\t\t\t}\n\t\n\t\t\t\t#mysome-shield-container #mysome-shield-tooltip::after {\n\t\t\t\t\tcontent: \"\";\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\ttop: 100%;\n\t\t\t\t\tleft: 50%;\n\t\t\t\t\tmargin-left: -9px;\n\t\t\t\t\tborder-width: 8px;\t\t\t\n\t\t\t\t\tborder-style: solid;\n\t\t\t\t\tborder-color: #000 transparent transparent transparent;\n\t\t\t\t}\n\t\n\t\t\t\t#mysome-shield-container:hover #mysome-shield-tooltip {\n\t\t\t\t\tvisibility: visible;\n\t\t\t\t}\n\t\n\t\t\t</style>\n\t\n\t\t\t<div id=\"mysome-shield-container\" style=\"height: 28px;width: 1px; display: inline-block; \">\n\t\t\t\t<div id=\"mysome-shield-widget\" style=\"width: 25px;height: 28px;margin-top: 8px;display: block;-webkit-mask-image: url(").concat(shieldShape, ");-webkit-mask-position: center;-webkit-mask-size: 23px;background: ").concat(shieldColorLoading, "; -webkit-mask-repeat: no-repeat;\" alt=\"\" src=\"\">\n\t\t\t\t\t<div id=\"mysome-shield-dots\" style=\"top: 11px; left: 10px;\" ></div>\n\t\t\t\t\t<div id=\"mysome-shield-check\" style=\"background: url(").concat(checkmarkSvg, ");width: 26px;height: 27px;background-repeat: no-repeat;background-position: center;\"></div>\n\t\t\t\t\t<div id=\"mysome-shield-exclaim\" style=\"background: url(").concat(exclaimationSvg, ");width: 25px;height: 27px;background-repeat: no-repeat;background-position: center;\"></div>\n\t\t\t\t</div>\n\t\t\t\t<div id=\"mysome-shield-tooltip\">\n\t\t\t\t\t<div style=\"display: flex; width: 100%; place-content: center;\">\n\t\t\t\t\t\t<span id=\"mysome-shield-tooltip-text\">").concat(tooltipTextVerified, "</span>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t\t<div id=\"mysome-shield-dummy\" style=\"display: none\"></div>\n\t\t\t</div>\n\t\t");
        nameElement.appendChild(verifiedElem);
        created = true;
    }
    else {
        utils_1.logger.info('Shield: Root element already existed');
    }
    var root = document.getElementById('mysome-shield-root');
    if (!root) {
        throw new Error('Shield: No widget found.');
    }
    nameElement.appendChild(root);
    var _b = resolveRootChildren(), container = _b.container, shield = _b.shield, dots = _b.dots, check = _b.check, exclaim = _b.exclaim, tooltip = _b.tooltip;
    if (created) {
        var handleClick = function () {
            onClicked(state, proofUrl);
        };
        tooltip.addEventListener('click', handleClick);
        shield.addEventListener('click', handleClick);
    }
    return {
        elements: {
            container: container,
            shield: shield,
            dots: dots,
            check: check,
            exclaim: exclaim,
            tooltip: tooltip,
        },
        setInitialState: function () {
            state = 'none';
            check.style.display = 'none';
            dots.style.display = 'block';
            shield.style.display = 'block';
            shield.style.backgroundColor = shieldColorLoading;
            tooltip.style.display = 'none';
            shield.style.cursor = 'pointer';
            exclaim.style.display = 'none';
            proofUrl = '';
        },
        setNoConnection: function () {
            state = 'no-connection';
            shield.style.backgroundColor = shieldColorYellow;
            dots.style.display = 'none';
            check.style.display = 'none';
            shield.style.cursor = 'pointer';
            tooltip.style.display = 'flex';
            exclaim.style.display = 'block';
            var el = document.getElementById('mysome-shield-tooltip-text');
            if (el)
                el.innerHTML = tooltipTextNoConnection;
        },
        setOwnProfileNotVerified: function () {
            state = 'own-profile-not-verified';
            shield.style.backgroundColor = shieldColorYellow;
            dots.style.display = 'none';
            check.style.display = 'none';
            shield.style.cursor = 'pointer';
            tooltip.style.display = 'flex';
            exclaim.style.display = 'block';
            var el = document.getElementById('mysome-shield-tooltip-text');
            if (el)
                el.innerHTML = tooltipTextOwnProfileNotVerified;
        },
        setOtherProfileNotVerified: function () {
            state = 'other-profile-not-verified';
            shield.style.backgroundColor = shieldColorYellow;
            dots.style.display = 'none';
            check.style.display = 'none';
            shield.style.cursor = 'pointer';
            tooltip.style.display = 'flex';
            exclaim.style.display = 'block';
            var el = document.getElementById('mysome-shield-tooltip-text');
            if (el)
                el.innerHTML = tooltipTextOtherProfileNotVerified;
        },
        setVerified: function (_proofUrl, ownProfile) {
            state = 'verified';
            proofUrl = _proofUrl;
            shield.style.backgroundColor = shieldColorVerified;
            dots.style.display = 'none';
            check.style.display = 'block';
            tooltip.style.display = 'flex';
            shield.style.cursor = 'pointer';
            exclaim.style.display = 'none';
            var el = document.getElementById('mysome-shield-tooltip-text');
            if (el)
                el.innerHTML = ownProfile ? tooltipTextOwnProfileVerified : tooltipTextVerified;
        },
        setSuspeciousProfile: function (_proofUrl) {
            state = 'suspecious';
            proofUrl = _proofUrl;
            shield.style.backgroundColor = shieldColorRed;
            dots.style.display = 'none';
            check.style.display = 'none';
            exclaim.style.display = 'block';
            tooltip.style.display = 'flex';
            shield.style.cursor = 'pointer';
            var el = document.getElementById('mysome-shield-tooltip-text');
            if (el)
                el.innerHTML = tooltipTextNotVerified;
        },
        hide: function () {
            container.style.display = 'none';
        },
        show: function () {
            container.style.display = 'inline-block';
        },
        isLoading: function () {
            return state === 'none';
        },
    };
};
exports.createShieldWidget = createShieldWidget;


/***/ }),

/***/ "./src-content/tour.ts":
/*!*****************************!*\
  !*** ./src-content/tour.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.endTour = exports.createTour = exports.createTourWidget = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
var popup_1 = __webpack_require__(/*! ./popup */ "./src-content/popup.ts");
var instance;
var setStyle = function (e, style) {
    for (var _i = 0, _a = Object.keys(style); _i < _a.length; _i++) {
        var key = _a[_i];
        var value = style[key];
        e.style[key] = value;
    }
};
function getWindowSize() {
    var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    return { w: w, h: h };
}
var createTourWidget = function () {
    if (instance) {
        return instance;
    }
    var rootElemName = "mysome-tour-root";
    // const overlayClass = "mysome-tour-overlay";	
    // const overlayFocusClass = "mysome-tour-focus";	
    var focus = {
        width: 110,
        height: 90,
        left: 142,
        top: 90,
    };
    var maskID = "mysome-tour-mask";
    var clipID = "mysome-tour-clip";
    var root = document.getElementById(rootElemName);
    if (!root) {
        root = document.createElement('div');
        root.id = rootElemName;
        root.style.display = "none";
        root.innerHTML = "\n\t\t\t<style>\n\t\t\t</style>\n\n\t\t\t<div id=\"mysome-tour-overlay-container\" style=\"opacity: 0.7; left: 0px; top: 0px; position: fixed; z-index: 99999; pointer-events: none; color: rgb(0, 0, 0);\">\n\t\t\t   <svg id=\"mysome-tour-overlay-svg\" width=\"1280\" height=\"526\" xmlns=\"http://www.w3.org/2000/svg\" style=\"width: 1280px; height: 526px; left: 0px; top: 0px; position: fixed;\">\n\t\t\t      <defs>\n\t\t\t         <mask id=\"".concat(maskID, "\">\n\t\t\t            <rect id=\"").concat(maskID, "-rect1\" x=\"0\" y=\"0\" width=\"1280\" height=\"526\" fill=\"white\"></rect>\n\t\t\t            <rect id=\"").concat(maskID, "-rect2\" style=\"x: 390px; y: 240.203px; width: 500px; height: 86px; fill: black; rx: 0px;\"></rect>\n\t\t\t         </mask>\n\t\t\t         <clipPath id=\"").concat(clipID, "\">\n\t\t\t            <polygon id=\"").concat(clipID, "-poly\" points=\"0 0, 0 526, 390 526, 390 240.203125, 890 240.203125, 890 326.203125, 390 326.203125, 390 526, 1280 526, 1280 0\"></polygon>\n\t\t\t         </clipPath>\n\t\t\t      </defs>\n\t\t\t      <rect id=\"mysome-tour-real-mask\" style=\"x: 0px; y: 0px; width: 1280px; height: 526px; fill: currentcolor; mask: url(&quot;#mysome-tour-mask&quot;);\"></rect>\n\t\t\t      <rect id=\"mysome-tour-clickable\" style=\"x: 0px; y: 0px; width: 1280px; height: 526px; fill: currentcolor; pointer-events: auto; clip-path: url(&quot;#mysome-tour-clip&quot;);\"></rect>\n\t\t\t      <rect id=\"mysome-tour-highlight\" style=\"x: 390px; y: 240.203px; width: 500px; height: 86px; pointer-events: auto; fill: transparent; display: none;\"></rect>\n\t\t\t   </svg>\n\t\t\t</div>\n\n\t\t");
        document.body.appendChild(root);
    }
    else {
        utils_1.logger.error("Root element already existed! This may make the plugin stop working.");
    }
    var container = document.getElementById("mysome-tour-overlay-container");
    var svg = document.getElementById("mysome-tour-overlay-svg");
    var mask = document.getElementById("mysome-tour-mask");
    var rect1 = document.getElementById("mysome-tour-mask-rect1");
    var rect2 = document.getElementById("mysome-tour-mask-rect2");
    var poly = document.getElementById("mysome-tour-clip-poly");
    var realMask = document.getElementById("mysome-tour-real-mask");
    var clickable = document.getElementById("mysome-tour-clickable");
    var highlight = document.getElementById("mysome-tour-highlight");
    if (!svg || !mask || !rect1 || !rect2 || !poly || !realMask || !clickable || !highlight) {
        throw new Error("Cannot find element.");
    }
    var target = null;
    var setTarget = function (element) {
        target = element;
        console.log("set target", target);
    };
    var maskArea = {
        x: 0,
        y: 0,
        w: 0,
        h: 0,
    };
    var update = function () {
        // console.log("update ");
        if (target) {
            var domRect = target.getBoundingClientRect();
            maskArea.x = domRect.x;
            maskArea.y = domRect.y;
            maskArea.w = domRect.width;
            maskArea.h = domRect.height;
        }
        else {
            maskArea.x = 0;
            maskArea.y = 0;
            maskArea.w = 0;
            maskArea.h = 0;
        }
        var _a = getWindowSize(), overlayWidth = _a.w, overlayHeight = _a.h;
        var windowHeight = overlayHeight;
        var windowWidth = overlayWidth;
        setStyle(svg, {
            width: "".concat(overlayWidth, "px"),
            height: "".concat(overlayHeight, "px"),
            left: '0px',
            top: '0px',
        });
        setStyle(rect1, {
            x: '0',
            y: '0',
            width: "".concat(overlayWidth, "px"),
            height: "".concat(overlayHeight, "px"),
            fill: 'white',
        });
        setStyle(rect2, {
            x: "".concat(maskArea.x),
            y: "".concat(maskArea.y),
            width: "".concat(maskArea.w),
            height: "".concat(maskArea.h),
            fill: 'black',
        });
        var strPoints = "\n\t\t\t0 0,\n\t\t\t0 ".concat(windowHeight, ",\n\t\t\t").concat(maskArea.x, " ").concat(windowHeight, ",\n\t\t\t").concat(maskArea.x, " ").concat(maskArea.y, ",\n\t\t\t").concat(maskArea.x + maskArea.w, " ").concat(maskArea.y, ",\n\t\t\t").concat(maskArea.x + maskArea.w, " ").concat(maskArea.y + maskArea.h, ",\n\t\t\t").concat(maskArea.x, " ").concat(maskArea.y + maskArea.h, ",\n\t\t\t").concat(maskArea.x, " ").concat(windowHeight, ",\n\t\t\t").concat(windowWidth, " ").concat(windowHeight, ",\n\t\t\t").concat(windowWidth, " 0").replaceAll("\t", "").replaceAll("\n", "").replaceAll(",", ", ");
        poly.setAttribute("points", strPoints);
        setStyle(realMask, {
            x: '0',
            y: '0',
            width: windowWidth.toString(),
            height: windowHeight.toString(),
            fill: 'currentcolor',
            mask: "url(#".concat(maskID, ")"),
        });
        setStyle(clickable, {
            x: "0",
            y: "0",
            width: windowWidth.toString(),
            height: windowHeight.toString(),
            fill: 'currentcolor',
            pointerEvents: 'auto',
            clipPath: "url(#".concat(clipID, ")"),
        });
        setStyle(highlight, {
            x: maskArea.x.toString(),
            y: maskArea.y.toString(),
            width: maskArea.w.toString(),
            height: maskArea.h.toString(),
            pointerEvents: 'auto',
            fill: 'transparent',
            display: 'none',
        });
    };
    var updateTimer;
    var show = function (e) {
        if (!root) {
            return;
        }
        target = e;
        root.style.display = 'inline-block';
        // createTooltipWidget().show(e);
        clearInterval(updateTimer);
        window.removeEventListener("resize", update);
        update();
        updateTimer = setInterval(update, 25);
        window.addEventListener("resize", update);
    };
    var hide = function () {
        clearInterval(updateTimer);
        window.removeEventListener("resize", update);
        if (!root) {
            return;
        }
        root.style.display = 'none';
    };
    instance = {
        elements: {
            root: root,
        },
        setTarget: setTarget,
        setInitialState: function () {
        },
        hide: hide,
        show: show,
    };
    return instance;
};
exports.createTourWidget = createTourWidget;
var createTour = function (type) {
    // (mysome as any).tours = (mysome as any).tours ?? [];
    var _a = root_1.mysome.tours[type], steps = _a.steps, onTourStart = _a.onTourStart, onTourDone = _a.onTourDone, onTourError = _a.onTourError, onTourCancel = _a.onTourCancel;
    var step = 0;
    var context = steps[step];
    root_1.mysome.tour = {
        step: step,
        steps: steps,
        type: type,
        cancel: function () {
            context.deactivate &&
                context.deactivate(root_1.mysome.tour).then().catch(console.error);
            onTourCancel(root_1.mysome.tour);
            onTourDone(root_1.mysome.tour);
            context = null;
            root_1.mysome.tour = null;
        },
        done: function () {
            context.deactivate &&
                context.deactivate(root_1.mysome.tour).then().catch(console.error);
            onTourDone(root_1.mysome.tour);
            context = null;
            root_1.mysome.tour = null;
        },
        nextStep: function () {
            (context === null || context === void 0 ? void 0 : context.next) && context.next();
        },
        next: function () {
            (context === null || context === void 0 ? void 0 : context.next) && context.next();
        },
        endWithError: function (title, message) {
            try {
                context.deactivate &&
                    context.deactivate(root_1.mysome.tour).then().catch(console.error);
                onTourDone(root_1.mysome.tour);
                context = null;
            }
            catch (e) {
                console.error(e);
            }
            try {
                onTourError(root_1.mysome.tour);
            }
            catch (e) {
                console.error(e);
            }
            root_1.mysome.tour = null;
            (0, popup_1.showMessagePopup)({ title: title, message: message });
        },
    };
    onTourStart(root_1.mysome.tour);
    context.activate &&
        context.activate(root_1.mysome.tour).then().catch(function (e) {
            console.error(e);
            context === null || context === void 0 ? void 0 : context.onActivateException(root_1.mysome.tour);
        });
    var next;
    context.next = next = function () {
        context.deactivate &&
            context.deactivate(root_1.mysome.tour).then().catch(console.error);
        if (++step >= steps.length) {
            onTourDone(root_1.mysome.tour);
            context = null;
            root_1.mysome.tour = null;
        }
        else {
            context = steps[step];
            context.next = next;
            root_1.mysome.tour.step = step;
            context.activate &&
                context.activate(root_1.mysome.tour).then().catch(function (e) {
                    console.error(e);
                    context === null || context === void 0 ? void 0 : context.onActivateException(root_1.mysome.tour);
                });
        }
    };
};
exports.createTour = createTour;
var endTour = function () {
    var _a;
    var background = ((_a = root_1.mysome.tour) !== null && _a !== void 0 ? _a : {}).background;
    background === null || background === void 0 ? void 0 : background.hide();
};
exports.endTour = endTour;


/***/ }),

/***/ "./src-content/tracking.ts":
/*!*********************************!*\
  !*** ./src-content/tracking.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createTracker = exports.tracking = void 0;
var utils_1 = __webpack_require__(/*! ./utils */ "./src-content/utils.ts");
exports.tracking = {};
var trackingSubscribers = {};
exports.tracking.on = function (name, fn) {
    var _a;
    trackingSubscribers[name] = (_a = trackingSubscribers[name]) !== null && _a !== void 0 ? _a : [];
    trackingSubscribers[name].push(fn);
};
exports.tracking.off = function (name, fn) {
    var _a;
    trackingSubscribers[name] = (_a = trackingSubscribers[name]) !== null && _a !== void 0 ? _a : [];
    var index = trackingSubscribers[name].findIndex(function (x) { return x === fn; });
    if (index >= 0) {
        trackingSubscribers[name].slice(index, 1);
    }
};
exports.tracking.fire = function (name, value) {
    var _a;
    ((_a = trackingSubscribers[name]) !== null && _a !== void 0 ? _a : []).forEach(function (s) {
        try {
            s && s(value);
        }
        catch (e) {
            console.error(e);
        }
    });
};
function createTracker(args) {
    var name = args.name, query = args.query, _a = args.initialValue, initialValue = _a === void 0 ? null : _a, _b = args.mode, mode = _b === void 0 ? 'normal' : _b, _c = args.throttle, throttle = _c === void 0 ? 0 : _c, defaultCompareFn = args.cmp;
    if (['off', 'on', 'fire'].indexOf(name) >= 0) {
        throw new Error('Cannot use field name.');
    }
    var trackerState = {
        value: initialValue,
        lastChanged: 0,
        lastUpdate: 0,
    };
    exports.tracking[name] = trackerState.value;
    var update = function (args) {
        var _a;
        var _b = args !== null && args !== void 0 ? args : {}, fnSet = _b.on, fnOverrideQuery = _b.query, fnCompareOverride = _b.cmp, prerequisites = _b.prerequisites, _c = _b.throttle, throttleOverride = _c === void 0 ? 0 : _c, _d = _b.resetThrottle, resetThrottle = _d === void 0 ? false : _d;
        var _throttle = throttle !== null && throttle !== void 0 ? throttle : throttleOverride;
        var throttleWait = false;
        if (_throttle > 0) {
            var ts = new Date().getTime();
            var delta = Math.max(trackerState.lastUpdate, ts) - Math.min(trackerState.lastUpdate, ts);
            throttleWait = delta < _throttle && !resetThrottle;
        }
        var value = null;
        var prerequisitesMet = !throttleWait && (!prerequisites || prerequisites.reduce(function (arr, it) { return arr && it; }, true));
        if (prerequisitesMet) {
            trackerState.lastUpdate = new Date().getTime();
            var what = fnOverrideQuery !== null && fnOverrideQuery !== void 0 ? fnOverrideQuery : query;
            if (typeof what === 'function') {
                value = what();
            }
            else if (typeof what === 'string') {
                value = !!document.querySelector(what);
            }
            else {
                throw new Error('Invalid type ');
            }
            var compare = (_a = defaultCompareFn !== null && defaultCompareFn !== void 0 ? defaultCompareFn : fnCompareOverride) !== null && _a !== void 0 ? _a : (function (oldVal, newVal) {
                return oldVal !== newVal;
            });
            if (prerequisitesMet && compare(trackerState.value, value) || trackerState.lastChanged === 0) {
                var ignore = false;
                if (mode === 'observed' && trackerState.lastChanged !== 0) {
                    ignore = true;
                }
                if (!ignore) {
                    var valueBefore = trackerState.value;
                    trackerState.value = value;
                    trackerState.lastChanged = new Date().getTime();
                    (0, utils_1.verbose)("".concat(name, " ").concat(mode === 'normal' ? 'changed' : 'observed', " => "), value);
                    fnSet && fnSet(value);
                    exports.tracking[name] = value;
                    exports.tracking.fire("".concat(name), value);
                    exports.tracking.fire("".concat(name).concat((mode === 'normal' ? 'Changed' : 'Observed')), value);
                    return {
                        value: value,
                        dirty: true,
                        before: valueBefore,
                    };
                }
            }
        }
        return {
            value: value,
            dirty: false
        };
    };
    var timer = null;
    var start = function () {
        timer = setInterval(update, 1000);
    };
    var stop = function () {
        clearInterval(timer);
    };
    var reset = function () {
        trackerState.lastChanged = 0;
        trackerState.value = initialValue !== null && initialValue !== void 0 ? initialValue : null;
    };
    return {
        update: update,
        get: function () { return trackerState.value; },
        start: start,
        stop: stop,
        reset: reset,
        changeEventName: name + 'Changed',
    };
}
exports.createTracker = createTracker;
;


/***/ }),

/***/ "./src-content/utils.ts":
/*!******************************!*\
  !*** ./src-content/utils.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.platformRequests = exports.registrations = exports.storage = exports.onOwnLinkedInProfileOrFeedUrl = exports.objToUrlParms = exports.detectPlatform = exports.blobToBase64 = exports.getUrlToCreateProof = exports.getUsersNameOnProfile = exports.getUsersNameOnFeed = exports.$array = exports.$ = exports.$$ = exports.getUserIdOnPageFeed = exports.base64ToBlob = exports.getUserIdInUrl = exports.getPlatform = exports.isOnLinkedInFeedUrl = exports.isOnLinkedInProfileUrl = exports.b64_to_utf8 = exports.utf8_to_b64 = exports.logger = exports.verbose = exports.traverseDomAllWithTimeout = exports.traverseDomWithTimeout = void 0;
var content_messaging_1 = __webpack_require__(/*! ./content-messaging */ "./src-content/content-messaging.ts");
var root_1 = __webpack_require__(/*! ./root */ "./src-content/root.ts");
function traverseDomWithTimeout(path, timeout, interval, throwIfNotFound) {
    if (interval === void 0) { interval = 100; }
    if (throwIfNotFound === void 0) { throwIfNotFound = true; }
    return __awaiter(this, void 0, void 0, function () {
        var e, ts;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    e = null;
                    ts = new Date().getTime();
                    _a.label = 1;
                case 1:
                    if (!!e) return [3 /*break*/, 3];
                    e = document.querySelector(path);
                    if (e) {
                        return [3 /*break*/, 3];
                    }
                    if (new Date().getTime() - ts > timeout) {
                        return [3 /*break*/, 3];
                    }
                    return [4 /*yield*/, (new Promise(function (resolve) { return setTimeout(resolve, interval); }))];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 1];
                case 3:
                    if (!e && throwIfNotFound) {
                        throw new Error("Failed to find element : " + path);
                    }
                    return [2 /*return*/, e];
            }
        });
    });
}
exports.traverseDomWithTimeout = traverseDomWithTimeout;
function traverseDomAllWithTimeout(path, timeout, interval, throwIfNotFound) {
    if (interval === void 0) { interval = 100; }
    if (throwIfNotFound === void 0) { throwIfNotFound = true; }
    return __awaiter(this, void 0, void 0, function () {
        var e, ts;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    e = null;
                    ts = new Date().getTime();
                    _a.label = 1;
                case 1:
                    if (!!e) return [3 /*break*/, 3];
                    e = document.querySelectorAll(path);
                    if (e) {
                        return [3 /*break*/, 3];
                    }
                    if (new Date().getTime() - ts > timeout) {
                        return [3 /*break*/, 3];
                    }
                    return [4 /*yield*/, (new Promise(function (resolve) { return setTimeout(resolve, interval); }))];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 1];
                case 3:
                    if (!e && throwIfNotFound) {
                        throw new Error("Failed to find element : " + path);
                    }
                    return [2 /*return*/, e];
            }
        });
    });
}
exports.traverseDomAllWithTimeout = traverseDomAllWithTimeout;
var verbose = function (s) {
    var rest = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        rest[_i - 1] = arguments[_i];
    }
    console.log.apply(console, __spreadArray(['MySoMe: VERBOSE:'], __spreadArray([s], rest, true), false));
};
exports.verbose = verbose;
exports.logger = {
    info: function (s) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(['MySoMe:'], __spreadArray([s], rest, true), false));
    },
    log: function (s) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(["MySoMe:"], __spreadArray([s], rest, true), false));
    },
    // info: (s: string, ...rest: any[] ) => {},
    error: function (s) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        console.error.apply(console, __spreadArray(['MySoMe:'], __spreadArray([s], rest, true), false));
    },
    // error: (s: string, ...rest: any[] ) => {},
    verbose: function (s) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(['MySoMe:'], __spreadArray([s], rest, true), false));
    },
    todo: function (s) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        console.log.apply(console, __spreadArray(['TODO:'], __spreadArray([s], rest, true), false));
    },
    // verbose: (s: string, ...rest: any[] ) => {},
};
function utf8_to_b64(str) {
    return window.btoa(unescape(encodeURIComponent(str)));
}
exports.utf8_to_b64 = utf8_to_b64;
function b64_to_utf8(str) {
    return decodeURIComponent(escape(window.atob(str)));
}
exports.b64_to_utf8 = b64_to_utf8;
var isOnLinkedInProfileUrl = function () {
    var ok = window.location.host.indexOf("linkedin.com") >= 0 && window.location.href.indexOf("/in/") >= 0;
    return ok;
};
exports.isOnLinkedInProfileUrl = isOnLinkedInProfileUrl;
var isOnLinkedInFeedUrl = function () {
    var ok = window.location.host.indexOf("linkedin.com") >= 0 && window.location.href.indexOf("/feed/") >= 0;
    return ok;
};
exports.isOnLinkedInFeedUrl = isOnLinkedInFeedUrl;
var getPlatform = function () {
    if (window.location.host.indexOf("linkedin.com") >= 0) {
        return 'li';
    }
    return null;
};
exports.getPlatform = getPlatform;
// TODO: this is linkedin only!!!
// TODO: move this to a utils folder in the linkedin integration!
var getUserIdInUrl = function () {
    if (!(0, exports.isOnLinkedInProfileUrl)()) {
        return null;
    }
    return window.location.pathname.split("/")[2];
};
exports.getUserIdInUrl = getUserIdInUrl;
/*export const base64ToBlob2 = (b64Data: string, contentType='', sliceSize=512) => {
    const byteCharacters = atob(b64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], {type: contentType});
    return blob;
};*/
function base64ToBlob(base64Image) {
    // Split into two parts
    var parts = base64Image.split(';base64,');
    // Hold the content type
    var imageType = parts[0].split(':')[1];
    // Decode Base64 string
    var decodedData = window.atob(parts[1]);
    // Create UNIT8ARRAY of size same as row data length
    var uInt8Array = new Uint8Array(decodedData.length);
    // Insert all character code into uInt8Array
    for (var i = 0; i < decodedData.length; ++i) {
        uInt8Array[i] = decodedData.charCodeAt(i);
    }
    // Return BLOB image after conversion
    return {
        blob: new Blob([uInt8Array], { type: imageType }),
        imageType: imageType
    };
}
exports.base64ToBlob = base64ToBlob;
// TODO: move this to a utils folder in the linkedin integration!
var getUserIdOnPageFeed = function () {
    var _a, _b;
    var loc = window.location.pathname === "/feed/";
    if (!loc) {
        // console.error("Not on feed url");
        return null;
    }
    var a = (_a = document.querySelector(".feed-identity-module")) === null || _a === void 0 ? void 0 : _a.querySelector("a");
    var url = a === null || a === void 0 ? void 0 : a.href;
    // console.error("url tpo get profile name on feed page ", url);
    return (_b = url === null || url === void 0 ? void 0 : url.split("/")[4]) !== null && _b !== void 0 ? _b : null;
};
exports.getUserIdOnPageFeed = getUserIdOnPageFeed;
var $$ = function (s) {
    return Array.prototype.slice.call(document.querySelectorAll(s));
};
exports.$$ = $$;
var $ = function (s) {
    return document.querySelector(s);
};
exports.$ = $;
var $array = function (nodeList) {
    return nodeList ? Array.prototype.slice.call(nodeList) : [];
};
exports.$array = $array;
// TODO: Move to linked in file. ( this is a linkedin only tool )
var getUsersNameOnFeed = function () {
    var _a, _b, _c;
    var loc = window.location.pathname === "/feed/";
    if (!loc) {
        // console.error("Not on feed url");
        return null;
    }
    var name = (_c = (_b = (0, exports.$array)((_a = (0, exports.$)(".feed-identity-module__actor-meta")) === null || _a === void 0 ? void 0 : _a.querySelectorAll('div'))
        .map(function (x) { var _a; return (_a = x === null || x === void 0 ? void 0 : x.innerText) === null || _a === void 0 ? void 0 : _a.trim(); }).filter(function (x) { return !!(x === null || x === void 0 ? void 0 : x.trim()) && (x === null || x === void 0 ? void 0 : x.trim()) !== ''; })) === null || _b === void 0 ? void 0 : _b[0]) !== null && _c !== void 0 ? _c : null;
    // If add a photo is displayed it means that the user hasnt got a photo
    // and the user will be shown as "Welcome, <Username>!" - instead we can use 
    // the alt paramter in the topbar. ( works if the topbar is visible but if the window is small it will not be present. ).
    var AddAPhoto = !!(0, exports.$$)('a > div > span').filter(function (x) { return x.innerText === 'Add a photo'; })[0];
    var avatarGhostButton = (0, exports.$$)('button > img.ghost-person')[0];
    if (AddAPhoto && avatarGhostButton) {
        name = avatarGhostButton.alt;
    }
    if ((name === null || name === void 0 ? void 0 : name.length) > 0) {
        return name;
    }
    // Fallback: We can fall back on the code element if the other methods fails.
    // Needs more testing to see how robust it is; but this may be the best solution of them all
    // however its unclear when the element gets created as the intention is for analytics and not 
    // part of the actual website.
    var codeObject = (0, exports.$$)('code').filter(function (x) { return x.innerText.indexOf('com.linkedin.voyager.common.Me') >= 0; })
        .map(function (x) {
        try {
            return JSON.parse(x.innerText);
        }
        catch (e) {
            return null;
        }
    })[0];
    var firstName = codeObject.included[0].firstName;
    var lastName = codeObject.included[0].lastName;
    name = firstName + ' ' + lastName;
    if ((name === null || name === void 0 ? void 0 : name.length) > 0) {
        return name;
    }
    return null;
};
exports.getUsersNameOnFeed = getUsersNameOnFeed;
// TODO: Move to linkedin.
var getUsersNameOnProfile = function () {
    var _a, _b;
    var nameElement = (document.querySelectorAll("h1")[0]);
    if (!(nameElement === null || nameElement === void 0 ? void 0 : nameElement.parentElement)) {
        return null;
    }
    var name = (_b = (_a = nameElement === null || nameElement === void 0 ? void 0 : nameElement.innerText) === null || _a === void 0 ? void 0 : _a.trim()) !== null && _b !== void 0 ? _b : null;
    return name ? name : null;
};
exports.getUsersNameOnProfile = getUsersNameOnProfile;
var getUrlToCreateProof = function (platform) {
    if (platform === void 0) { platform = 'li'; }
    if (platform === 'li' || platform === 'test') {
        var u = (0, exports.getUserIdInUrl)();
        if (!u) {
            exports.logger.error("Failed to get username from url");
            return;
        }
        var p = (0, exports.detectPlatform)();
        if (!p) {
            exports.logger.error("Failed to detect platform.");
            return;
        }
        (0, exports.verbose)("username to create proof with ", u);
        var data = encodeURIComponent(utf8_to_b64(JSON.stringify({
            u: u,
            p: p,
        })));
        if (platform === 'test') {
            return "http://localhost:3000/create/2?template=".concat(data);
        }
        return "https://app.testnet.mysomeid.dev/create/2?template=".concat(data);
    }
    throw new Error('Invalid platform : ' + platform);
};
exports.getUrlToCreateProof = getUrlToCreateProof;
var blobToBase64 = function (blob) {
    var reader = new FileReader();
    reader.readAsDataURL(blob);
    return new Promise(function (resolve) {
        reader.onloadend = function () {
            resolve(reader.result);
        };
    });
};
exports.blobToBase64 = blobToBase64;
var detectPlatform = function () {
    var host = window.location.host.toLowerCase();
    if (host.indexOf("linkedin") >= 0) {
        return 'li';
    }
    if (host.indexOf("localhost:8082") >= 0) {
        return 'test';
    }
    if (host.indexOf("localhost:3000") >= 0 || host.indexOf("app.mysomeid.dev") >= 0 || host.indexOf("app.mysome.id") >= 0 || host.indexOf("app.testnet.mysome.id") >= 0) {
        return 'mysomeid';
    }
    return null;
};
exports.detectPlatform = detectPlatform;
var objToUrlParms = function (obj) { return Object.keys(obj).map(function (key) { return [key, obj[key]].join('='); }).join('&'); };
exports.objToUrlParms = objToUrlParms;
var onOwnLinkedInProfileOrFeedUrl = function () {
    var onFeed = (0, exports.isOnLinkedInFeedUrl)();
    var onProfilePage = (0, exports.isOnLinkedInProfileUrl)();
    var foundEditIntroElement = !!document.querySelector("button[aria-label=\"Edit intro\"]");
    // document.querySelector('.profile-topcard-background-image-edit__icon')
    var ok = onFeed || (onProfilePage && foundEditIntroElement);
    return ok;
};
exports.onOwnLinkedInProfileOrFeedUrl = onOwnLinkedInProfileOrFeedUrl;
var messageHandler = (0, content_messaging_1.getMessageHandler)();
exports.storage = new (/** @class */ (function () {
    function class_1() {
        this.state = null;
    }
    class_1.prototype.init = function () {
        return __awaiter(this, void 0, void 0, function () {
            var state;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        console.log("Storage: Init");
                        if (this.state !== null) {
                            console.error("Already initialised");
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { type: 'get-state', store: 'state' })];
                    case 1:
                        state = (_a.sent()).state;
                        console.log("Initial storage ", state);
                        this.state = state !== null && state !== void 0 ? state : {};
                        return [2 /*return*/];
                }
            });
        });
    };
    class_1.prototype.set = function (key, value) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        console.log("Storage: set ", { key: key, value: value });
                        if (!(this.state === null)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.init()];
                    case 1:
                        _c.sent();
                        _c.label = 2;
                    case 2: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { type: 'set-state', store: 'state', key: key, value: value })];
                    case 3:
                        _c.sent();
                        this.state = __assign(__assign({}, ((_a = this.state) !== null && _a !== void 0 ? _a : {})), (_b = {}, _b[key] = value, _b));
                        return [2 /*return*/];
                }
            });
        });
    };
    class_1.prototype.get = function (key, sync) {
        if (sync === void 0) { sync = false; }
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(this.state === null || sync)) return [3 /*break*/, 2];
                        if (sync) {
                            console.log("Storage: Refreshing storage state");
                            this.state = null;
                        }
                        return [4 /*yield*/, this.init()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        if (!this.state) {
                            throw new Error("Error no storage state object available");
                        }
                        return [2 /*return*/, this.state[key]];
                }
            });
        });
    };
    return class_1;
}()))();
exports.registrations = new (/** @class */ (function () {
    function class_2() {
    }
    class_2.prototype.fetch = function () {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var regs;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, exports.storage.get("regs", true)];
                    case 1:
                        regs = (_a = (_b.sent())) !== null && _a !== void 0 ? _a : {};
                        root_1.mysome.regs = regs;
                        console.log("Regs", regs);
                        return [2 /*return*/, regs];
                }
            });
        });
    };
    class_2.prototype.select = function (platform, userId) {
        var _a, _b, _c;
        var reg = (_c = (_b = (_a = root_1.mysome.regs) === null || _a === void 0 ? void 0 : _a[platform]) === null || _b === void 0 ? void 0 : _b[userId]) !== null && _c !== void 0 ? _c : null;
        return reg;
    };
    class_2.prototype.setRegStep = function (platform, userId, step) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function () {
            var regs;
            var _d;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0: return [4 /*yield*/, exports.storage.get("regs", true)];
                    case 1:
                        regs = (_a = (_e.sent())) !== null && _a !== void 0 ? _a : {};
                        regs[platform] = (_d = {},
                            _d[userId] = __assign(__assign({}, ((_c = (_b = regs[platform]) === null || _b === void 0 ? void 0 : _b[userId]) !== null && _c !== void 0 ? _c : {})), { step: step }),
                            _d);
                        root_1.mysome.regs = regs; // updated regs
                        console.log("storing new regs", regs);
                        return [4 /*yield*/, exports.storage.set('regs', regs)];
                    case 2:
                        _e.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    return class_2;
}()));
exports.platformRequests = new (/** @class */ (function () {
    function class_3() {
        this.platformRequests = null;
    }
    class_3.prototype.fetch = function () {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var store;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (this.platformRequests !== null) {
                            return [2 /*return*/, this.platformRequests];
                        }
                        console.log("Storage: Init");
                        return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { type: 'get-state', store: 'platform-requests' })];
                    case 1:
                        store = (_b.sent()).store;
                        console.log("Platform requests (loaded when initialised) ", store);
                        this.platformRequests = (_a = store === null || store === void 0 ? void 0 : store.array) !== null && _a !== void 0 ? _a : [];
                        if (this.platformRequests === null) {
                            return [2 /*return*/, []];
                        }
                        return [2 /*return*/, this.platformRequests];
                }
            });
        });
    };
    class_3.prototype.removeRequest = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var key, value;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.platformRequests) {
                            throw new Error('List where not initialised');
                        }
                        this.platformRequests = this.platformRequests.filter(function (x) { return x.id !== id; });
                        key = 'array';
                        value = this.platformRequests;
                        return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { type: 'set-state', store: 'platform-requests', key: key, value: value })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    class_3.prototype.removeRequests = function (platform) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var key, value, store;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!this.platformRequests) {
                            throw new Error('List where not initialised');
                        }
                        this.platformRequests = this.platformRequests.filter(function (x) { return x.platform !== platform; });
                        key = 'array';
                        value = this.platformRequests;
                        return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { type: 'set-state', store: 'platform-requests', key: key, value: value })];
                    case 1:
                        _b.sent();
                        return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "get-state", { type: 'get-state', store: 'platform-requests' })];
                    case 2:
                        store = (_b.sent()).store;
                        console.log("Platform requests (loaded when initialised) ", store);
                        this.platformRequests = (_a = store === null || store === void 0 ? void 0 : store.array) !== null && _a !== void 0 ? _a : [];
                        return [2 /*return*/];
                }
            });
        });
    };
    class_3.prototype.set = function (value) {
        return __awaiter(this, void 0, void 0, function () {
            var key;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        key = 'array';
                        console.log("Platform requests: set ", { key: key, value: value });
                        if (!(this.platformRequests === null)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.fetch()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { type: 'set-state', store: 'platform-requests', key: key, value: value })];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    class_3.prototype.setState = function (value) {
        return __awaiter(this, void 0, void 0, function () {
            var key;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        key = 'array';
                        console.log("Platform requests: set ", { key: key, value: value });
                        if (!(this.platformRequests === null)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.fetch()];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [4 /*yield*/, messageHandler.sendMessageWResponse("background", "set-state", { type: 'set-state', store: 'platform-requests', key: key, value: value })];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    class_3.prototype.select = function (platform, status, requestType) {
        return __awaiter(this, void 0, void 0, function () {
            var array, requests;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.fetch()];
                    case 1:
                        array = _a.sent();
                        requests = array.filter(function (x) { return x.platform === platform &&
                            x.created > new Date().getTime() - 60000 * 30 &&
                            x.status === status &&
                            x.requestType === requestType; });
                        return [2 /*return*/, requests !== null && requests !== void 0 ? requests : null];
                }
            });
        });
    };
    return class_3;
}()))();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src-content/index.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEscUNBQXFDLGNBQWM7Ozs7Ozs7Ozs7QUNBbkQscUNBQXFDLGNBQWM7Ozs7Ozs7Ozs7O0FDQXRDO0FBQ2I7QUFDQSw2Q0FBNkM7QUFDN0M7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsbUJBQW1CO0FBQ25CLHNDQUFzQyxtQkFBTyxDQUFDLG9EQUFpQjtBQUMvRCxpQ0FBaUMsbUJBQU8sQ0FBQywwQ0FBWTtBQUNyRCxhQUFhLG1CQUFPLENBQUMscUNBQVE7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0Esa0ZBQWtGLFlBQVksaUJBQWlCLHFCQUFxQix5QkFBeUIsZUFBZSxpQkFBaUIsMkNBQTJDLGtFQUFrRSxrS0FBa0ssV0FBVyxZQUFZLGNBQWMsYUFBYSxvQkFBb0IsYUFBYTtBQUMvaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7Ozs7Ozs7Ozs7OztBQzNETjtBQUNiO0FBQ0E7QUFDQSxpREFBaUQsT0FBTztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxtQ0FBbUMsR0FBRyx5QkFBeUIsR0FBRyx5QkFBeUI7QUFDM0YsYUFBYSxtQkFBTyxDQUFDLHFDQUFRO0FBQzdCLHlDQUF5QztBQUN6Qyx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBLDBDQUEwQyxtQkFBbUI7QUFDN0Q7QUFDQSx1RUFBdUUsWUFBWTtBQUNuRjtBQUNBLEtBQUs7O0FBRUw7QUFDQTtBQUNBOztBQUVBO0FBQ0EsRUFBRTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtGQUFrRjtBQUNsRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSx1SEFBdUgsdUJBQXVCO0FBQzlJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLEVBQUU7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RUFBdUUsWUFBWTtBQUNuRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDO0FBQ3ZDLEtBQUs7QUFDTDtBQUNBO0FBQ0EsdUNBQXVDLHVFQUF1RSxrREFBa0QsTUFBTSxrQkFBa0I7QUFDeEw7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULG9FQUFvRTtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsYUFBYTtBQUNiLFNBQVMsSUFBSTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsbUNBQW1DOzs7Ozs7Ozs7Ozs7QUN2U3RCO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELHlCQUF5QjtBQUN6QixjQUFjLG1CQUFPLENBQUMsdUNBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLG1CQUFtQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSw0SEFBNEgsUUFBUSxPQUFPLFNBQVMsVUFBVSxjQUFjLHNCQUFzQixjQUFjLG9CQUFvQixzQkFBc0IscUVBQXFFLGlCQUFpQixjQUFjLG1CQUFtQiw4Q0FBOEMsV0FBVyxnQkFBZ0IsYUFBYSxvQkFBb0Isb0dBQW9HO0FBQy9qQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsRUFBRTtBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSx5QkFBeUI7Ozs7Ozs7Ozs7OztBQ2hFWjtBQUNiO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RDtBQUNBO0FBQ0Esa0NBQWtDLG1CQUFPLENBQUMseUVBQTBCO0FBQ3BFLDZCQUE2QixtQkFBTyxDQUFDLCtEQUFxQjtBQUMxRCxtQ0FBbUMsbUJBQU8sQ0FBQywyRUFBMkI7QUFDdEUsY0FBYyxtQkFBTyxDQUFDLHVDQUFTO0FBQy9CLDBCQUEwQixtQkFBTyxDQUFDLCtEQUFxQjtBQUN2RCxhQUFhLG1CQUFPLENBQUMscUNBQVE7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsc0JBQXNCO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCxvRUFBb0U7QUFDMUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELGtCQUFrQjtBQUN4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUssSUFBSTtBQUNUOzs7Ozs7Ozs7Ozs7QUM5SWE7QUFDYjtBQUNBO0FBQ0EsaURBQWlELE9BQU87QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLCtEQUErRCxpQkFBaUI7QUFDNUc7QUFDQSxvQ0FBb0MsTUFBTSwrQkFBK0IsWUFBWTtBQUNyRixtQ0FBbUMsTUFBTSxtQ0FBbUMsWUFBWTtBQUN4RixnQ0FBZ0M7QUFDaEM7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLGNBQWMsNkJBQTZCLDBCQUEwQixjQUFjLHFCQUFxQjtBQUN4RyxpQkFBaUIsb0RBQW9ELHFFQUFxRSxjQUFjO0FBQ3hKLHVCQUF1QixzQkFBc0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDLG1DQUFtQyxTQUFTO0FBQzVDLG1DQUFtQyxXQUFXLFVBQVU7QUFDeEQsMENBQTBDLGNBQWM7QUFDeEQ7QUFDQSw4R0FBOEcsT0FBTztBQUNySCxpRkFBaUYsaUJBQWlCO0FBQ2xHLHlEQUF5RCxnQkFBZ0IsUUFBUTtBQUNqRiwrQ0FBK0MsZ0JBQWdCLGdCQUFnQjtBQUMvRTtBQUNBLGtDQUFrQztBQUNsQztBQUNBO0FBQ0EsVUFBVSxZQUFZLGFBQWEsU0FBUyxVQUFVO0FBQ3RELG9DQUFvQyxTQUFTO0FBQzdDO0FBQ0E7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsY0FBYyxtQkFBTyxDQUFDLHdDQUFVO0FBQ2hDLGVBQWUsbUJBQU8sQ0FBQywwQ0FBVztBQUNsQyxjQUFjLG1CQUFPLENBQUMsd0NBQVU7QUFDaEMsYUFBYSxtQkFBTyxDQUFDLHNDQUFTO0FBQzlCLGFBQWEsbUJBQU8sQ0FBQyxzQ0FBUztBQUM5QixpQkFBaUIsbUJBQU8sQ0FBQyw4Q0FBYTtBQUN0QywwQkFBMEIsbUJBQU8sQ0FBQyxnRUFBc0I7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckMscUNBQXFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QztBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEI7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsWUFBWTtBQUN6QyxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLFlBQVk7QUFDekMsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsb0RBQW9ELDhCQUE4QjtBQUNsRjtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRCxpRkFBaUY7QUFDakY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkZBQTZGO0FBQzdGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlJQUFpSTtBQUNqSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsa0NBQWtDO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUMsSUFBSTtBQUNMO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLHlCQUF5Qiw4QkFBOEI7QUFDdkQsQ0FBQztBQUNEO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekIsQ0FBQztBQUNEO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekIsQ0FBQztBQUNEO0FBQ0E7QUFDQSx5QkFBeUIsc0RBQXNEO0FBQy9FLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0EsQ0FBQztBQUNELG9EQUFvRCxlQUFlO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLHdDQUF3QztBQUN4QztBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTLEVBQUU7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpRUFBaUUsZ0ZBQWdGO0FBQ2pKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdGQUFnRixnRkFBZ0Y7QUFDaEs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixFQUFFO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVCxrQkFBa0Isa0JBQWtCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsR0FBRztBQUNwQjtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCLDJEQUEyRDtBQUMzRCwrREFBK0QsaUNBQWlDO0FBQ2hHLEtBQUssSUFBSTtBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYSxJQUFJO0FBQ2pCLFNBQVM7QUFDVDtBQUNBLHdDQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUUsZ0hBQWdIO0FBQ25MO0FBQ0E7QUFDQSxxR0FBcUcsNENBQTRDLDBMQUEwTCx3Q0FBd0M7QUFDblgsbUZBQW1GLHVEQUF1RDtBQUMxSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyT0FBMk8sZ0NBQWdDO0FBQzNRO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlhQUFpYSxnQ0FBZ0M7QUFDamM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlSQUFpUixRQUFRLDRGQUE0RjtBQUNyWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhFQUE4RTtBQUM5RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhLElBQUk7QUFDakI7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBLHdDQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhLElBQUk7QUFDakIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCwyRUFBMkU7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixvRUFBb0U7QUFDcEUsaUJBQWlCO0FBQ2pCLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLDJFQUEyRTtBQUMzRTtBQUNBLDRCQUE0QjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNGQUFzRjtBQUN0RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0ZBQXNGO0FBQ3RGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUIscUVBQXFFLCtIQUErSDtBQUNwTTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUZBQXFGO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlFQUF5RSxpR0FBaUc7QUFDMUs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELHNCQUFzQjtBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQixFQUFFO0FBQ3ZCLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQSx5QkFBeUI7QUFDekI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0Esd0VBQXdFLEtBQUssNkJBQTZCO0FBQzFHO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSxLQUFLLDZCQUE2QjtBQUN2RztBQUNBO0FBQ0E7QUFDQSxpRUFBaUUsS0FBSyw2QkFBNkI7QUFDbkc7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsY0FBYztBQUMvRCx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMsY0FBYztBQUMzRCxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0EsaURBQWlELGNBQWM7QUFDL0QseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0VBQXNFLHNEQUFzRDtBQUM1SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseURBQXlEO0FBQ3pELGlDQUFpQztBQUNqQztBQUNBO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQixpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RDtBQUN2RDtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDO0FBQ3hDO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRCxrQkFBZTs7Ozs7Ozs7Ozs7O0FDOXdDRjtBQUNiLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFlOzs7Ozs7Ozs7Ozs7QUNsQkY7QUFDYjtBQUNBLDRCQUE0QiwrREFBK0QsaUJBQWlCO0FBQzVHO0FBQ0Esb0NBQW9DLE1BQU0sK0JBQStCLFlBQVk7QUFDckYsbUNBQW1DLE1BQU0sbUNBQW1DLFlBQVk7QUFDeEYsZ0NBQWdDO0FBQ2hDO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLDZCQUE2QiwwQkFBMEIsY0FBYyxxQkFBcUI7QUFDeEcsaUJBQWlCLG9EQUFvRCxxRUFBcUUsY0FBYztBQUN4Six1QkFBdUIsc0JBQXNCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QyxtQ0FBbUMsU0FBUztBQUM1QyxtQ0FBbUMsV0FBVyxVQUFVO0FBQ3hELDBDQUEwQyxjQUFjO0FBQ3hEO0FBQ0EsOEdBQThHLE9BQU87QUFDckgsaUZBQWlGLGlCQUFpQjtBQUNsRyx5REFBeUQsZ0JBQWdCLFFBQVE7QUFDakYsK0NBQStDLGdCQUFnQixnQkFBZ0I7QUFDL0U7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBLFVBQVUsWUFBWSxhQUFhLFNBQVMsVUFBVTtBQUN0RCxvQ0FBb0MsU0FBUztBQUM3QztBQUNBO0FBQ0EsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELGNBQWMsbUJBQU8sQ0FBQyx3Q0FBVTtBQUNoQyxhQUFhLG1CQUFPLENBQUMsc0NBQVM7QUFDOUIsYUFBYSxtQkFBTyxDQUFDLHNDQUFTO0FBQzlCLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0M7QUFDaEMsS0FBSztBQUNMLENBQUM7QUFDRCxrQkFBZTs7Ozs7Ozs7Ozs7O0FDdERGO0FBQ2I7QUFDQTtBQUNBLGlEQUFpRCxPQUFPO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QiwrREFBK0QsaUJBQWlCO0FBQzVHO0FBQ0Esb0NBQW9DLE1BQU0sK0JBQStCLFlBQVk7QUFDckYsbUNBQW1DLE1BQU0sbUNBQW1DLFlBQVk7QUFDeEYsZ0NBQWdDO0FBQ2hDO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxjQUFjLDZCQUE2QiwwQkFBMEIsY0FBYyxxQkFBcUI7QUFDeEcsaUJBQWlCLG9EQUFvRCxxRUFBcUUsY0FBYztBQUN4Six1QkFBdUIsc0JBQXNCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QyxtQ0FBbUMsU0FBUztBQUM1QyxtQ0FBbUMsV0FBVyxVQUFVO0FBQ3hELDBDQUEwQyxjQUFjO0FBQ3hEO0FBQ0EsOEdBQThHLE9BQU87QUFDckgsaUZBQWlGLGlCQUFpQjtBQUNsRyx5REFBeUQsZ0JBQWdCLFFBQVE7QUFDakYsK0NBQStDLGdCQUFnQixnQkFBZ0I7QUFDL0U7QUFDQSxrQ0FBa0M7QUFDbEM7QUFDQTtBQUNBLFVBQVUsWUFBWSxhQUFhLFNBQVMsVUFBVTtBQUN0RCxvQ0FBb0MsU0FBUztBQUM3QztBQUNBO0FBQ0EsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELHdCQUF3QixHQUFHLHdCQUF3QixHQUFHLHlCQUF5QixHQUFHLG1CQUFtQixHQUFHLGdDQUFnQztBQUN4SSwwQkFBMEIsbUJBQU8sQ0FBQywrREFBcUI7QUFDdkQsYUFBYSxtQkFBTyxDQUFDLHFDQUFRO0FBQzdCLGNBQWMsbUJBQU8sQ0FBQyx1Q0FBUztBQUMvQjtBQUNBO0FBQ0E7QUFDQSxpRUFBaUUsZ0JBQWdCO0FBQ2pGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0M7QUFDaEM7QUFDQSw0QkFBNEI7QUFDNUIsZ0NBQWdDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0VBQWtFO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUhBQXFILFFBQVEsT0FBTyxTQUFTLFVBQVUsZ0JBQWdCLGlDQUFpQyxjQUFjLG9CQUFvQix1QkFBdUIsYUFBYSx1RkFBdUYsaUJBQWlCLGNBQWMsbUJBQW1CLDhDQUE4QyxXQUFXLGdCQUFnQixhQUFhLHFCQUFxQixpQkFBaUIsc0hBQXNILGNBQWMsYUFBYTtBQUNwcUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZEO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUssSUFBSTtBQUNUO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBLCtGQUErRiwrQ0FBK0M7QUFDOUk7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0EsOERBQThELCtUQUErVCxvQkFBb0IsaURBQWlELElBQUkscUJBQXFCLHVIQUF1SCxJQUFJO0FBQ3RsQjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSx3QkFBd0I7Ozs7Ozs7Ozs7OztBQ2hNWDtBQUNiLDhDQUE2QyxFQUFFLGFBQWEsRUFBQztBQUM3RCxjQUFjLEdBQUcsd0JBQXdCLEdBQUcscUJBQXFCO0FBQ2pFLGNBQWMsbUJBQU8sQ0FBQyx1Q0FBUztBQUMvQixhQUFhLG1CQUFPLENBQUMscUNBQVE7QUFDN0IsY0FBYyxtQkFBTyxDQUFDLHVDQUFTO0FBQy9CLGNBQWMsbUJBQU8sQ0FBQyx1Q0FBUztBQUMvQixlQUFlLG1CQUFPLENBQUMseUNBQVU7QUFDakM7QUFDQTtBQUNBO0FBQ0EsRUFBRSxlQUFlO0FBQ2pCLGNBQWMsbUJBQU8sQ0FBQyx1Q0FBUztBQUMvQiwwQkFBMEIsbUJBQU8sQ0FBQywrREFBcUI7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsY0FBYztBQUNkLGVBQWU7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDdkVhO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELDBCQUEwQjtBQUMxQixjQUFjLG1CQUFPLENBQUMsdUNBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxFQUFFO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QztBQUM5QywrQ0FBK0M7QUFDL0Msa0RBQWtEO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0ZBQWdGLCtCQUErQix3Q0FBd0MsMENBQTBDLHFEQUFxRCxxREFBcUQsMENBQTBDLHVFQUF1RSxrQ0FBa0MsV0FBVyx1RUFBdUUsMEJBQTBCLGtDQUFrQywrQkFBK0IsbUJBQW1CLFdBQVcsMkNBQTJDLGlEQUFpRCx5Q0FBeUMsMENBQTBDLHFEQUFxRCxxREFBcUQsMENBQTBDLGdFQUFnRSxnQ0FBZ0MsV0FBVywwQ0FBMEMsZ0RBQWdELHlDQUF5QywwQ0FBMEMscURBQXFELHFEQUFxRCwwQ0FBMEMsZ0VBQWdFLGdDQUFnQyxXQUFXLDJDQUEyQyxnQkFBZ0IsdURBQXVELGFBQWEsdUJBQXVCLDJEQUEyRCxhQUFhLFdBQVcsNkRBQTZELCtCQUErQix5QkFBeUIsb0NBQW9DLHdCQUF3Qix5QkFBeUIsK0JBQStCLHlCQUF5QiwrQkFBK0IsK0JBQStCLDBCQUEwQiw0QkFBNEIsNkJBQTZCLCtCQUErQiwwQkFBMEIsZ0NBQWdDLDRCQUE0QixXQUFXLHNFQUFzRSwwQkFBMEIsK0JBQStCLHNCQUFzQixzQkFBc0IsOEJBQThCLDhCQUE4QixzQ0FBc0MsbUVBQW1FLFdBQVcscUVBQXFFLGdDQUFnQyxXQUFXLHlGQUF5RixZQUFZLHVCQUF1QixrRUFBa0UsYUFBYSxnQkFBZ0IsZUFBZSxrREFBa0QsOEJBQThCLHdCQUF3Qiw2Q0FBNkMsK0JBQStCLG1GQUFtRixXQUFXLHlHQUF5RyxZQUFZLGFBQWEsNkJBQTZCLDRCQUE0Qiw2R0FBNkcsWUFBWSxhQUFhLDZCQUE2Qiw0QkFBNEIsNkdBQTZHLGFBQWEsc0JBQXNCO0FBQ2hySDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsMEJBQTBCOzs7Ozs7Ozs7Ozs7QUM1S2I7QUFDYiw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0QsZUFBZSxHQUFHLGtCQUFrQixHQUFHLHdCQUF3QjtBQUMvRCxjQUFjLG1CQUFPLENBQUMsdUNBQVM7QUFDL0IsYUFBYSxtQkFBTyxDQUFDLHFDQUFRO0FBQzdCLGNBQWMsbUJBQU8sQ0FBQyx1Q0FBUztBQUMvQjtBQUNBO0FBQ0EsOENBQThDLGdCQUFnQjtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1JQUFtSSxXQUFXLFVBQVUsaUJBQWlCLGdCQUFnQixzQkFBc0Isb0JBQW9CLDRJQUE0SSxlQUFlLFdBQVcsVUFBVSxnQkFBZ0Isb1JBQW9SLGNBQWMsY0FBYyxjQUFjLGFBQWEsUUFBUSwyWUFBMlksUUFBUSxlQUFlLGVBQWUsb0JBQW9CLGdCQUFnQix1QkFBdUIsRUFBRSwyRUFBMkUsUUFBUSxlQUFlLGVBQWUsb0JBQW9CLHNCQUFzQixxQkFBcUIsdUJBQXVCLEVBQUUsNkVBQTZFLGNBQWMsY0FBYyxjQUFjLHNCQUFzQixtQkFBbUIsY0FBYztBQUMzbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsZ0NBQWdDO0FBQzVFLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBLG1GQUFtRjtBQUNuRjtBQUNBO0FBQ0EsZUFBZTs7Ozs7Ozs7Ozs7O0FDN1BGO0FBQ2IsOENBQTZDLEVBQUUsYUFBYSxFQUFDO0FBQzdELHFCQUFxQixHQUFHLGdCQUFnQjtBQUN4QyxjQUFjLG1CQUFPLENBQUMsdUNBQVM7QUFDL0IsZ0JBQWdCO0FBQ2hCO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQSxtRUFBbUUsa0JBQWtCO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RDtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkdBQTZHLG1CQUFtQjtBQUNoSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLDRCQUE0QjtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7Ozs7Ozs7Ozs7OztBQ3BIYTtBQUNiO0FBQ0E7QUFDQSxpREFBaUQsT0FBTztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsK0RBQStELGlCQUFpQjtBQUM1RztBQUNBLG9DQUFvQyxNQUFNLCtCQUErQixZQUFZO0FBQ3JGLG1DQUFtQyxNQUFNLG1DQUFtQyxZQUFZO0FBQ3hGLGdDQUFnQztBQUNoQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsY0FBYyw2QkFBNkIsMEJBQTBCLGNBQWMscUJBQXFCO0FBQ3hHLGlCQUFpQixvREFBb0QscUVBQXFFLGNBQWM7QUFDeEosdUJBQXVCLHNCQUFzQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEMsbUNBQW1DLFNBQVM7QUFDNUMsbUNBQW1DLFdBQVcsVUFBVTtBQUN4RCwwQ0FBMEMsY0FBYztBQUN4RDtBQUNBLDhHQUE4RyxPQUFPO0FBQ3JILGlGQUFpRixpQkFBaUI7QUFDbEcseURBQXlELGdCQUFnQixRQUFRO0FBQ2pGLCtDQUErQyxnQkFBZ0IsZ0JBQWdCO0FBQy9FO0FBQ0Esa0NBQWtDO0FBQ2xDO0FBQ0E7QUFDQSxVQUFVLFlBQVksYUFBYSxTQUFTLFVBQVU7QUFDdEQsb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTtBQUNBO0FBQ0EsNkVBQTZFLE9BQU87QUFDcEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBNkMsRUFBRSxhQUFhLEVBQUM7QUFDN0Qsd0JBQXdCLEdBQUcscUJBQXFCLEdBQUcsZUFBZSxHQUFHLHFDQUFxQyxHQUFHLHFCQUFxQixHQUFHLHNCQUFzQixHQUFHLG9CQUFvQixHQUFHLDJCQUEyQixHQUFHLDZCQUE2QixHQUFHLDBCQUEwQixHQUFHLGNBQWMsR0FBRyxTQUFTLEdBQUcsVUFBVSxHQUFHLDJCQUEyQixHQUFHLG9CQUFvQixHQUFHLHNCQUFzQixHQUFHLG1CQUFtQixHQUFHLDJCQUEyQixHQUFHLDhCQUE4QixHQUFHLG1CQUFtQixHQUFHLG1CQUFtQixHQUFHLGNBQWMsR0FBRyxlQUFlLEdBQUcsaUNBQWlDLEdBQUcsOEJBQThCO0FBQzltQiwwQkFBMEIsbUJBQU8sQ0FBQywrREFBcUI7QUFDdkQsYUFBYSxtQkFBTyxDQUFDLHFDQUFRO0FBQzdCO0FBQ0EsK0JBQStCO0FBQy9CLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkVBQTJFLHVDQUF1QztBQUNsSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0EsK0JBQStCO0FBQy9CLHNDQUFzQztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkVBQTJFLHVDQUF1QztBQUNsSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0EsaUNBQWlDO0FBQ2pDO0FBQ0E7QUFDQSxxQkFBcUIsdUJBQXVCO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmLGNBQWM7QUFDZDtBQUNBO0FBQ0EseUJBQXlCLHVCQUF1QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHlCQUF5Qix1QkFBdUI7QUFDaEQ7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLCtDQUErQztBQUMvQztBQUNBO0FBQ0EseUJBQXlCLHVCQUF1QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsZ0RBQWdEO0FBQ2hEO0FBQ0E7QUFDQSx5QkFBeUIsdUJBQXVCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EseUJBQXlCLHVCQUF1QjtBQUNoRDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsa0RBQWtEO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhCQUE4QjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QjtBQUNBO0FBQ0E7QUFDQSxvQkFBb0IsMkJBQTJCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QyxrQkFBa0I7QUFDMUQ7QUFDQSxFQUFFO0FBQ0Y7QUFDQTtBQUNBLG9DQUFvQztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix3QkFBd0I7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsaUJBQWlCO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQSxVQUFVO0FBQ1Y7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsUUFBUSxpSEFBaUgsd0JBQXdCLHVIQUF1SDtBQUNwUztBQUNBO0FBQ0E7QUFDQSw4RUFBOEUsdUNBQXVDO0FBQ3JIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtREFBbUQ7QUFDbkQ7QUFDQTtBQUNBLG1FQUFtRSxvRUFBb0U7QUFDdkk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3QjtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEIscUNBQXFDLDZDQUE2QyxtQ0FBbUM7QUFDckgscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQSxlQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhHQUE4RyxtQ0FBbUM7QUFDako7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVELHdCQUF3QjtBQUMvRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0hBQWtILDJEQUEyRDtBQUM3SztBQUNBO0FBQ0EseURBQXlELHdEQUF3RCxZQUFZO0FBQzdIO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQSxDQUFDO0FBQ0QscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQ7QUFDakQsNkRBQTZELG1IQUFtSCxNQUFNLFlBQVk7QUFDbE07QUFDQSxtREFBbUQ7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0EsQ0FBQztBQUNELHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEdBQThHLCtDQUErQztBQUM3SjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEZBQTRGLHFCQUFxQjtBQUNqSDtBQUNBO0FBQ0EsOEdBQThHLHVFQUF1RTtBQUNyTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRGQUE0RixpQ0FBaUM7QUFDN0g7QUFDQTtBQUNBLDhHQUE4Ryx1RUFBdUU7QUFDckw7QUFDQTtBQUNBLDhHQUE4RywrQ0FBK0M7QUFDN0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLHdCQUF3QjtBQUN6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0hBQWtILHVFQUF1RTtBQUN6TDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSx3QkFBd0I7QUFDekY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtIQUFrSCx1RUFBdUU7QUFDekw7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtEQUErRDtBQUMvRDtBQUNBO0FBQ0EsNERBQTREO0FBQzVEO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7O1VDL25CRDtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7O1VFdEJBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXlzb21laWQvLi9zcmMtY29udGVudC9hdHRlbnRpb24uc3ZnIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvbG9nby5zdmciLCJ3ZWJwYWNrOi8vbXlzb21laWQvLi9zcmMtY29udGVudC9iYWRnZS50cyIsIndlYnBhY2s6Ly9teXNvbWVpZC8uL3NyYy1jb250ZW50L2NvbnRlbnQtbWVzc2FnaW5nLnRzIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvZnJhbWUudHMiLCJ3ZWJwYWNrOi8vbXlzb21laWQvLi9zcmMtY29udGVudC9pbmRleC50cyIsIndlYnBhY2s6Ly9teXNvbWVpZC8uL3NyYy1jb250ZW50L2ludGVncmF0aW9ucy9saW5rZWQtaW4udHMiLCJ3ZWJwYWNrOi8vbXlzb21laWQvLi9zcmMtY29udGVudC9pbnRlZ3JhdGlvbnMvbXlzb21lLWFwaS50cyIsIndlYnBhY2s6Ly9teXNvbWVpZC8uL3NyYy1jb250ZW50L2ludGVncmF0aW9ucy90ZXN0LnRzIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvcG9wdXAudHMiLCJ3ZWJwYWNrOi8vbXlzb21laWQvLi9zcmMtY29udGVudC9yb290LnRzIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvc2hpZWxkLnRzIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvdG91ci50cyIsIndlYnBhY2s6Ly9teXNvbWVpZC8uL3NyYy1jb250ZW50L3RyYWNraW5nLnRzIiwid2VicGFjazovL215c29tZWlkLy4vc3JjLWNvbnRlbnQvdXRpbHMudHMiLCJ3ZWJwYWNrOi8vbXlzb21laWQvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vbXlzb21laWQvd2VicGFjay9iZWZvcmUtc3RhcnR1cCIsIndlYnBhY2s6Ly9teXNvbWVpZC93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vbXlzb21laWQvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gXCJkYXRhOmltYWdlL3N2Zyt4bWw7Y2hhcnNldD11dGYtODtiYXNlNjQsUEQ5NGJXd2dkbVZ5YzJsdmJqMGlNUzR3SWlCbGJtTnZaR2x1WnowaVZWUkdMVGdpUHo0S1BITjJaeUIzYVdSMGFEMGlNVGh3ZUNJZ2FHVnBaMmgwUFNJeE9IQjRJaUIyYVdWM1FtOTRQU0l3SURBZ01UZ2dNVGdpSUhabGNuTnBiMjQ5SWpFdU1TSWdlRzFzYm5NOUltaDBkSEE2THk5M2QzY3Vkek11YjNKbkx6SXdNREF2YzNabklpQjRiV3h1Y3pwNGJHbHVhejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TVRrNU9TOTRiR2x1YXlJK0NpQWdJQ0E4SVMwdElFZGxibVZ5WVhSdmNqb2dVMnRsZEdOb0lEVTFMaklnS0RjNE1UZ3hLU0F0SUdoMGRIQnpPaTh2YzJ0bGRHTm9ZWEJ3TG1OdmJTQXRMVDRLSUNBZ0lEeDBhWFJzWlQ1QmRIUmxiblJwYjI0Z1FtRmtaMlU4TDNScGRHeGxQZ29nSUNBZ1BHUmxjMk0rUTNKbFlYUmxaQ0IzYVhSb0lGTnJaWFJqYUM0OEwyUmxjMk0rQ2lBZ0lDQThaeUJwWkQwaVVHRm5aUzB4SWlCemRISnZhMlU5SW01dmJtVWlJSE4wY205clpTMTNhV1IwYUQwaU1TSWdabWxzYkQwaWJtOXVaU0lnWm1sc2JDMXlkV3hsUFNKbGRtVnViMlJrSWo0S0lDQWdJQ0FnSUNBOFp5QnBaRDBpUVhSMFpXNTBhVzl1TFVKaFpHZGxJajRLSUNBZ0lDQWdJQ0FnSUNBZ1BHTnBjbU5zWlNCcFpEMGlUM1poYkNJZ1ptbHNiRDBpSTBSRU5UVTFOU0lnWTNnOUlqa2lJR041UFNJNUlpQnlQU0k1SWo0OEwyTnBjbU5zWlQ0S0lDQWdJQ0FnSUNBZ0lDQWdQSEJoZEdnZ1pEMGlUVGd1TlRRMU5ERXdNVFlzTVRJdU16WXpNamd4TWlCTU55NDVOelF4TWpFd09TdzBMak15TVRJNE9UQTJJRXc1TGpnNU16QTJOalF4TERRdU16SXhNamc1TURZZ1REa3VNekEzTVRJNE9URXNNVEl1TXpZek1qZ3hNaUJNT0M0MU5EVTBNVEF4Tml3eE1pNHpOak15T0RFeUlGb2dUVGd1TVRjeE9EYzFMREUxSUV3NExqRTNNVGczTlN3eE15NDBOamt5TXpneklFdzVMamN3TWpZek5qY3lMREV6TGpRMk9USXpPRE1nVERrdU56QXlOak0yTnpJc01UVWdURGd1TVRjeE9EYzFMREUxSUZvaUlHbGtQU0loSWlCbWFXeHNQU0lqUmtaR1JrWkdJaUJtYVd4c0xYSjFiR1U5SW01dmJucGxjbThpUGp3dmNHRjBhRDRLSUNBZ0lDQWdJQ0E4TDJjK0NpQWdJQ0E4TDJjK0Nqd3ZjM1puUGc9PVwiIiwibW9kdWxlLmV4cG9ydHMgPSBcImRhdGE6aW1hZ2Uvc3ZnK3htbDtjaGFyc2V0PXV0Zi04O2Jhc2U2NCxQRDk0Yld3Z2RtVnljMmx2YmowaU1TNHdJaUJsYm1OdlpHbHVaejBpVlZSR0xUZ2lQejRLUEhOMlp5QjNhV1IwYUQwaU16WXhjSGdpSUdobGFXZG9kRDBpTkRZeGNIZ2lJSFpwWlhkQ2IzZzlJakFnTUNBek5qRWdORFl4SWlCMlpYSnphVzl1UFNJeExqRWlJSGh0Ykc1elBTSm9kSFJ3T2k4dmQzZDNMbmN6TG05eVp5OHlNREF3TDNOMlp5SWdlRzFzYm5NNmVHeHBibXM5SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpFNU9Ua3ZlR3hwYm1zaVBnb2dJQ0FnUENFdExTQkhaVzVsY21GMGIzSTZJRk5yWlhSamFDQTFOUzR5SUNnM09ERTRNU2tnTFNCb2RIUndjem92TDNOclpYUmphR0Z3Y0M1amIyMGdMUzArQ2lBZ0lDQThkR2wwYkdVK2MyaHBaV3hrUEM5MGFYUnNaVDRLSUNBZ0lEeGtaWE5qUGtOeVpXRjBaV1FnZDJsMGFDQlRhMlYwWTJndVBDOWtaWE5qUGdvZ0lDQWdQR1JsWm5NK0NpQWdJQ0FnSUNBZ1BHeHBibVZoY2tkeVlXUnBaVzUwSUhneFBTSTJOaTQzTkRJeU9EYzJKU0lnZVRFOUlqZzNMalF5TVRBME1EZ2xJaUI0TWowaU16SXVPREExTXpreU5TVWlJSGt5UFNJNUxqUTBOVE13TmpBeUpTSWdhV1E5SW14cGJtVmhja2R5WVdScFpXNTBMVEVpUGdvZ0lDQWdJQ0FnSUNBZ0lDQThjM1J2Y0NCemRHOXdMV052Ykc5eVBTSWpOelJDUlVVMElpQnZabVp6WlhROUlqQWxJajQ4TDNOMGIzQStDaUFnSUNBZ0lDQWdJQ0FnSUR4emRHOXdJSE4wYjNBdFkyOXNiM0k5SWlNeU1VRTNSa1lpSUc5bVpuTmxkRDBpTXpBdU1EUTBNVEU1TXlVaVBqd3ZjM1J2Y0Q0S0lDQWdJQ0FnSUNBZ0lDQWdQSE4wYjNBZ2MzUnZjQzFqYjJ4dmNqMGlJekZGUVRWR1JpSWdiMlptYzJWMFBTSTFOQzQzTmpFd016azBKU0krUEM5emRHOXdQZ29nSUNBZ0lDQWdJQ0FnSUNBOGMzUnZjQ0J6ZEc5d0xXTnZiRzl5UFNJak1qRTNSVVpHSWlCdlptWnpaWFE5SWpneExqQXpOalUyTVRjbElqNDhMM04wYjNBK0NpQWdJQ0FnSUNBZ0lDQWdJRHh6ZEc5d0lITjBiM0F0WTI5c2IzSTlJaU15TXpWR1JUY2lJRzltWm5ObGREMGlNVEF3SlNJK1BDOXpkRzl3UGdvZ0lDQWdJQ0FnSUR3dmJHbHVaV0Z5UjNKaFpHbGxiblErQ2lBZ0lDQThMMlJsWm5NK0NpQWdJQ0E4WnlCcFpEMGlVR0ZuWlMweElpQnpkSEp2YTJVOUltNXZibVVpSUhOMGNtOXJaUzEzYVdSMGFEMGlNU0lnWm1sc2JEMGlibTl1WlNJZ1ptbHNiQzF5ZFd4bFBTSmxkbVZ1YjJSa0lqNEtJQ0FnSUNBZ0lDQThaeUJwWkQwaWMyaHBaV3hrSWo0S0lDQWdJQ0FnSUNBZ0lDQWdQSEJoZEdnZ1pEMGlUVE11TURrd09Ua3pOemtzTnpJdU1URXhNelV5TkNCRE9EQXVPRE16TmpNNU5Dd3pPUzQ1TURFME5EVTRJREV6T1M0d01ETTJNRGtzTVRZdU1ETTBNekU0TkNBeE56Y3VOakF3T1RBeUxEQXVOVEE1T1Rjd016STBJRU14TnprdU16UXdOVFEzTEMwd0xqRTRPVGN6T0RBeU5DQXhOemt1TnpBeE1qRTFMQzB3TGpFME9UazFNVEkwTnlBeE9ERXVOVGsyTnpRNUxEQXVOVEE1T1Rjd016STBJRU15TURRdU56VTBNRFl6TERndU5UY3lNRGd5TURNZ01qWXpMakl4TmpZMk1pd3pNaTQwTXpreU1EazBJRE0xTmk0NU9EUTFORGtzTnpJdU1URXhNelV5TkNCRE16WXhMamN5TkRBM05pd3hOell1TnprMU5qRXhJRE0yTVM0M01qUXdOellzTWpNNUxqSXpNRGszTkNBek5UWXVPVGcwTlRRNUxESTFPUzQwTVRjME5ETWdRek0wT1M0NE56VXlOVGdzTWpnNUxqWTVOekUwTnlBek5ERXVOekV3T0Rrc016RTFMakUwTmpVZ016TXdMak0yT1RFMU15d3pNelV1TURneU9EQXhJRU16TURBdU9URTROREl5TERNNE5pNDROVEEzTmpJZ01qVXdMamd3TnprMk1pdzBNamd1TmpjME9ETXhJREU0TUM0d016YzNOekVzTkRZd0xqVTFOVEF3T0NCRE1UQXhMalUwTkRNNU5TdzBNak11T1RZd05qTXpJRFV4TGpVNE1EVTJOQ3d6T0RJdU1UTTJOVFkwSURNd0xqRTBOakkzT1RZc016TTFMakE0TWpnd01TQkRNakF1T1Rjek1EY3hPU3d6TVRRdU9UUTFNalV5SURjdU56RTJNRGc1Tmprc01qazBMalF5T0RZeE15QXpMakE1TURrNU16YzVMREkxT1M0ME1UYzBORE1nUXkweExqQXpNRE16TVRJMkxESXlPQzR5TVRrM016RWdMVEV1TURNd016TXhNallzTVRZMUxqYzRORE0yTnlBekxqQTVNRGs1TXpjNUxEY3lMakV4TVRNMU1qUWdXaUlnYVdROUlsSmxZM1JoYm1kc1pTSWdabWxzYkQwaWRYSnNLQ05zYVc1bFlYSkhjbUZrYVdWdWRDMHhLU0krUEM5d1lYUm9QZ29nSUNBZ0lDQWdJQ0FnSUNBOFp5QnBaRDBpUjNKdmRYQWlJSFJ5WVc1elptOXliVDBpZEhKaGJuTnNZWFJsS0RFd01TNHdNREF3TURBc0lEazVMakF3TURBd01Da2lJSE4wY205clpUMGlJMFpHUmtaR1JpSStDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQThjR0YwYUNCa1BTSk5NVEl5TGpnNE9URXpOU3cxTGpnMU16WTNORGMzSUVNNE9DNHlPRFEyTXpJNExESXVOVGt5TVRjek5DQTJNQzR3TURFME9UQTRMRGd1TmpjMk1qQXlNamtnTXpndU1ETTVOekE1Tml3eU5DNHhNRFUzTmpFMElFTXlNUzQyTXpRNU9URTNMRE0xTGpZek1URXlOek1nTlM0eU56azFPVGMwTWl3Mk1DNDRPREl4TURZeElETXVNREk1TnpFM01EVXNPRGN1TXpRME1qTXdOeUJETFRRdU1Ea3dOREU0T1RJc01UY3hMakE0T0RJd05pQXlOeTQyTnpreE5EUTVMREU0TUM0ME1UUTJPRGdnTXpndU1ETTVOekE1Tml3eE9EUXVPVEl4TlRJMklFTTBPQzQwTURBeU56UXlMREU0T1M0ME1qZ3pOalFnTnpJdU1URTNNelUzTlN3eE9URXVNREl4TWpRMklEa3dMamczTlRBNU5qa3NNVGMyTGpNNU1qSTBOQ0JETVRBNUxqWXpNamd6Tml3eE5qRXVOell6TWpReUlERXdPUzQyTXpJNE16WXNNVFF3TGpVMU16RTJNeUF4TURndU5qQXdNamN5TERFeU1TNDVORGN5TnpJaUlHbGtQU0pNYVc1bElpQnpkSEp2YTJVdGQybGtkR2c5SWpFeUlpQnpkSEp2YTJVdGJHbHVaV05oY0QwaWMzRjFZWEpsSWo0OEwzQmhkR2crQ2lBZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0E4Y0dGMGFDQmtQU0pOTlRVdU5qRTVNVEV4TWl3eE1qa3VNVEEyT0RnNElFTTFOUzQyTVRreE1URXlMRGs1TGpNMk5qQXdPRFlnTlRrdU5UVTNNRFk1TWl3NE5DNHpPVGM0TkRFMklEZ3lMakU0TXpRMU5ERXNOamd1TnprMk1qQTNOeUJET1RRdU16WXhOVEU0Tnl3Mk1DNHpPVGt3TXpNeElERXhOeTQ1TWpFeE9USXNOakF1TmpZMU1qazJPQ0F4TXpNdU5UTXlNekF6TERZNExqYzVOakl3TnpjZ1F6RTJOeTQzT0RneU9Ea3NPRFl1TmpNNE1UTTVNaUF4TmpFdU56YzRPRE0xTERFeU5TNDVNakkyTnpRZ01UWXhMamMzT0Rnek5Td3hOVEF1TlRnME1qRTVJRU14TmpFdU56YzRPRE0xTERFM05TNHlORFUzTmpNZ01UVTBMamN5TmpNMU5Td3lNVEl1TURJNE5USTFJREV5TVM0eE9Ea3lPRFFzTWpNeExqQXdPVEUwTnlCRE9EY3VOalV5TWpFek9Td3lORGt1T1RnNU56WTVJRFkzTGpRd05EQXdOamNzTWpRM0xqUTJPVGMyTkNBME1pNHpOakV5T1RNMUxESTBOUzR4TnpJek1TSWdhV1E5SWt4cGJtVWlJSE4wY205clpTMTNhV1IwYUQwaU1USWlJSE4wY205clpTMXNhVzVsWTJGd1BTSnpjWFZoY21VaVBqd3ZjR0YwYUQ0S0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4d1lYUm9JR1E5SWsweE5UVXVPVEF4TlRnM0xEVXdMakl5TkRrM09URWdRekUwT0M0MU56QXhNemtzTkRFdU9UVTROREUwSURFeU1DNDFNekEyTXpVc016SXVNVGM0TkRZNElEazNMakUyTlRBME5Dd3pOUzR4TXpZeE5qSTFJRU0yT0M0d05qRTJPVFF6TERNNExqZ3lNREUyTVRZZ05URXVOak0xTmpRME9DdzBOaTQ0TURRM056STRJRE01TGpNNU1qWTBPRGdzTmpndU9EUXdNekF3T0NCRE1qZ3VORE13TmpVd01TdzRPQzQxTnpBeU1qZzNJREk0TGpRek1EWTFNREVzTVRFMkxqRTJOelExTXlBeU9TNDNORE0zTVRNekxERXlPQzR6TWpRMk5qUWdRek14TGpRNU1qWXhPRGtzTVRRMExqVXhOekU1TkNBek5TNDBOVGMwTXpReUxERTJNUzQ1TnpRM01qRWdOVGd1TmpNd09EUXpNeXd4TmpFdU9UYzBOekl4SUVNNE1pNDFNVEEzTkRZMUxERTJNUzQ1TnpRM01qRWdPREl1TlRFd056UTJOU3d4TXpndU5qa3hOakVnT0RJdU1UZ3pORFUwTVN3eE1UWXVNVFkzTkRVeklFTTRNUzQ1TWprNU56STNMRGs0TGpjeU1qazBOVFFnT1RRdU5UTXpPRFV6TkN3NE9TNDVOVEkzTURnNElERXdPUzR3TkRRek9EY3NPRGt1T1RVeU56QTRPQ0JETVRJeUxqZzRPVEV6TlN3NE9TNDVOVEkzTURnNElERXpOQzQzT1RRM056UXNNVEF3TGpBME56TTFNeUF4TXpRdU56azBOemMwTERFeE5pNHhOamMwTlRNZ1F6RXpOQzQzT1RRM056UXNNVFF4TGpnNE1UUXpNeUF4TkRFdU1qUTNNamc1TERFNE1TNDNNekV6TlRRZ01UQTJMalExTWpFNU1Td3lNRFF1TmpNME1EVTJJRU0zTVM0Mk5UY3dPVEk0TERJeU55NDFNelkzTlRjZ01qRXVNVEl3TkRZMk55d3lNVFV1TURBd09UY3pJRGt1TVRFNU9UQTJNaXd5TURFdU1EVXhOakEwSWlCcFpEMGlUR2x1WlNJZ2MzUnliMnRsTFhkcFpIUm9QU0l4TWlJZ2MzUnliMnRsTFd4cGJtVmpZWEE5SW5OeGRXRnlaU0krUEM5d1lYUm9QZ29nSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdQR05wY21Oc1pTQnBaRDBpVDNaaGJDSWdabWxzYkQwaUkwWkdSa1pHUmlJZ1kzZzlJak0yTGpVaUlHTjVQU0l5TkRRdU5TSWdjajBpTlM0MUlqNDhMMk5wY21Oc1pUNEtJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ0lEeGphWEpqYkdVZ2FXUTlJazkyWVd3aUlHWnBiR3c5SWlOR1JrWkdSa1lpSUdONFBTSTFMalVpSUdONVBTSXhPVFl1TlNJZ2NqMGlOUzQxSWo0OEwyTnBjbU5zWlQ0S0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnSUR4amFYSmpiR1VnYVdROUlrOTJZV3dpSUdacGJHdzlJaU5HUmtaR1JrWWlJR040UFNJeE1EZ3VNaUlnWTNrOUlqRXhOUzQxSWlCeVBTSTFMalVpUGp3dlkybHlZMnhsUGdvZ0lDQWdJQ0FnSUNBZ0lDQWdJQ0FnUEdOcGNtTnNaU0JwWkQwaVQzWmhiQ0lnWm1sc2JEMGlJMFpHUmtaR1JpSWdZM2c5SWpVMUxqY2lJR041UFNJeE16VXVOU0lnY2owaU5TNDFJajQ4TDJOcGNtTnNaVDRLSUNBZ0lDQWdJQ0FnSUNBZ0lDQWdJRHhqYVhKamJHVWdhV1E5SWs5MllXd2lJR1pwYkd3OUlpTkdSa1pHUmtZaUlHTjRQU0l4TlRrdU5TSWdZM2s5SWpVMExqVWlJSEk5SWpVdU5TSStQQzlqYVhKamJHVStDaUFnSUNBZ0lDQWdJQ0FnSUNBZ0lDQThZMmx5WTJ4bElHbGtQU0pQZG1Gc0lpQm1hV3hzUFNJalJrWkdSa1pHSWlCamVEMGlNVEk0TGpVaUlHTjVQU0kyTGpRaUlISTlJalV1TlNJK1BDOWphWEpqYkdVK0NpQWdJQ0FnSUNBZ0lDQWdJRHd2Wno0S0lDQWdJQ0FnSUNBOEwyYytDaUFnSUNBOEwyYytDand2YzNablBnPT1cIiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9faW1wb3J0RGVmYXVsdCA9ICh0aGlzICYmIHRoaXMuX19pbXBvcnREZWZhdWx0KSB8fCBmdW5jdGlvbiAobW9kKSB7XG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBcImRlZmF1bHRcIjogbW9kIH07XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5jcmVhdGVCYWRnZSA9IHZvaWQgMDtcbnZhciBhdHRlbnRpb25fc3ZnXzEgPSBfX2ltcG9ydERlZmF1bHQocmVxdWlyZShcIi4vYXR0ZW50aW9uLnN2Z1wiKSk7XG52YXIgbG9nb19zdmdfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi9sb2dvLnN2Z1wiKSk7XG52YXIgcm9vdF8xID0gcmVxdWlyZShcIi4vcm9vdFwiKTtcbnZhciBjcmVhdGVCYWRnZSA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBfYiA9IF9hLnNob3dBdHRlbnRpb24sIHNob3dBdHRlbnRpb24gPSBfYiA9PT0gdm9pZCAwID8gZmFsc2UgOiBfYjtcbiAgICB2YXIgaWQgPSBcIm15c29tZS1iYWRnZVwiO1xuICAgIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGUuaWQgPSBpZDtcbiAgICB2YXIgdG9wID0gJyc7IC8vICd0b3A6IGNhbGMoNTAlIC0gMzJweCknO1xuICAgIHZhciBib3R0b20gPSAnYm90dG9tOiAxMnB4JztcbiAgICB2YXIgeiA9ICc5OTk4JztcbiAgICBlLmlubmVySFRNTCA9IFwiXFxuXFx0ICA8ZGl2IGlkPVxcXCJteXNvbWUtYWNjZXNzLWJhZGdlXFxcIiBzdHlsZT1cXFwicG9zaXRpb246IGZpeGVkOyBsZWZ0OiAxNnB4OyBcIi5jb25jYXQodG9wLCBcIjsgXCIpLmNvbmNhdChib3R0b20sIFwiOyB6LWluZGV4OiBcIikuY29uY2F0KHosIFwiOyBkaXNwbGF5OiBmbGV4OyBjdXJzb3I6IHBvaW50ZXI7IGZpbHRlcjogZHJvcC1zaGFkb3coMXB4IDBweCA0cHggIzJiMmIyYjYxKTtcXFwiPlxcblxcdFxcdDxhIGlkPVxcXCJteXNvbWUtYWNjZXNzLWJhZGdlLWxpbmtcXFwiIHN0eWxlPVxcXCJkaXNwbGF5OiBmbGV4O1xcXCI+XFxuXFx0XFx0ICA8aW1nIHNyYz1cXFwiXCIpLmNvbmNhdChsb2dvX3N2Z18xLmRlZmF1bHQsIFwiXFxcIiB3aWR0aD1cXFwiNjBcXFwiIGhlaWdodD1cXFwiNjBcXFwiPlxcblxcdFxcdCAgPHNwYW4gaWQ9XFxcIm15c29tZS1hY2Nlc3MtYmFkZ2UtYXR0ZW50aW9uXFxcIiBzdHlsZT1cXFwicG9zaXRpb246IGFic29sdXRlOyB0b3A6IC0xcHg7IHJpZ2h0OiA1cHg7IGNvbG9yOiB3aGl0ZTsgd2lkdGg6IDE4cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgaGVpZ2h0OiAxOHB4O1xcXCI+XFxuXFx0XFx0XFx0PGltZyBzcmM9XFxcIlwiKS5jb25jYXQoYXR0ZW50aW9uX3N2Z18xLmRlZmF1bHQsIFwiXFxcIiB3aWR0aD1cXFwiMThweFxcXCIgaGVpZ2h0PVxcXCIxOHB4XFxcIj48L2ltZz5cXG5cXHRcXHQgIDwvc3Bhbj5cXG5cXHRcXHQ8L2E+XFxuXFx0ICA8L2Rpdj5cXG5cXHRcIik7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlKTtcbiAgICB2YXIgZXZlbnRIYW5kbGVyID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgKF9iID0gKF9hID0gcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmNsaWNrKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuZm9yRWFjaChmdW5jdGlvbiAoeCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB4KGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHZhciBhbmNob3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1hY2Nlc3MtYmFkZ2UtbGlua1wiKTtcbiAgICBhbmNob3IgPT09IG51bGwgfHwgYW5jaG9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhbmNob3IuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGV2ZW50SGFuZGxlcik7XG4gICAgdmFyIGF0dGVudGlvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibXlzb21lLWFjY2Vzcy1iYWRnZS1hdHRlbnRpb25cIik7XG4gICAgaWYgKGF0dGVudGlvbikge1xuICAgICAgICBhdHRlbnRpb24uc3R5bGUudmlzaWJpbGl0eSA9ICFzaG93QXR0ZW50aW9uID8gJ2hpZGRlbicgOiAnaW5pdGlhbCc7XG4gICAgfVxuICAgIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0gPSB7XG4gICAgICAgIGVsZW1lbnQ6IGUsXG4gICAgICAgIGNsaWNrOiBbXSxcbiAgICAgICAgYWRkQ2xpY2tIYW5kbGVyOiBmdW5jdGlvbiAoZm4pIHtcbiAgICAgICAgICAgIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0uY2xpY2sucHVzaChmbik7XG4gICAgICAgIH0sXG4gICAgICAgIHNob3dBdHRlbnRpb246IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICBpZiAoYXR0ZW50aW9uKSB7XG4gICAgICAgICAgICAgICAgYXR0ZW50aW9uLnN0eWxlLnZpc2liaWxpdHkgPSAhdiA/ICdoaWRkZW4nIDogJ2luaXRpYWwnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBzaG93OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBlLnN0eWxlLmRpc3BsYXkgPSAnaW5pdGlhbCc7XG4gICAgICAgIH0sXG4gICAgICAgIGhpZGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGUuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgfSxcbiAgICB9O1xuICAgIHJldHVybiByb290XzEubXlzb21lLndpZGdldHNbaWRdO1xufTtcbmV4cG9ydHMuY3JlYXRlQmFkZ2UgPSBjcmVhdGVCYWRnZTtcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fYXNzaWduID0gKHRoaXMgJiYgdGhpcy5fX2Fzc2lnbikgfHwgZnVuY3Rpb24gKCkge1xuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbih0KSB7XG4gICAgICAgIGZvciAodmFyIHMsIGkgPSAxLCBuID0gYXJndW1lbnRzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSlcbiAgICAgICAgICAgICAgICB0W3BdID0gc1twXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdDtcbiAgICB9O1xuICAgIHJldHVybiBfX2Fzc2lnbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufTtcbnZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xudmFyIF9fZ2VuZXJhdG9yID0gKHRoaXMgJiYgdGhpcy5fX2dlbmVyYXRvcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIGJvZHkpIHtcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xuICAgICAgICB3aGlsZSAoZyAmJiAoZyA9IDAsIG9wWzBdICYmIChfID0gMCkpLCBfKSB0cnkge1xuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XG4gICAgfVxufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuY3JlYXRlQ29udGVudE1lc3NhZ2VIYW5kbGVyID0gZXhwb3J0cy5nZXRNZXNzYWdlSGFuZGxlciA9IGV4cG9ydHMuaXNNeVNPTUVJRE1lc3NhZ2UgPSB2b2lkIDA7XG52YXIgcm9vdF8xID0gcmVxdWlyZShcIi4vcm9vdFwiKTtcbnZhciBpc015U09NRUlETWVzc2FnZSA9IGZ1bmN0aW9uIChtc2cpIHsgcmV0dXJuIChtc2cgPT09IG51bGwgfHwgbXNnID09PSB2b2lkIDAgPyB2b2lkIDAgOiBtc2cub3JpZ2luKSA9PT0gJ215c29tZScgJiYgISEobXNnID09PSBudWxsIHx8IG1zZyA9PT0gdm9pZCAwID8gdm9pZCAwIDogbXNnLnR5cGUpOyB9O1xuZXhwb3J0cy5pc015U09NRUlETWVzc2FnZSA9IGlzTXlTT01FSURNZXNzYWdlO1xuLy8gZXhwb3J0IGNvbnN0IGlzTXlTT01FSURFdmVudCA9IChtc2c6IGFueSkgPT4gbXNnPy5vcmlnaW4gPT09ICdteXNvbWUnICYmIG1zZz8uaXNFdmVudCA9PT0gdHJ1ZTtcbi8qZXhwb3J0IHR5cGUgTXlTb01lSWRFeHRlbnNpb25SZXNwb25zZSA9IHtcbiAgICBtc2c6IGFueTtcbiAgICByZXNwb25zZTogYW55O1xufTsqL1xuLyogZXhwb3J0IHR5cGUgTWVzc2FnZUhhbmRsZXIgPSB7XG4gICAgc2VuZE1lc3NhZ2U6IChtc2c6IGFueSkgPT4gdm9pZDtcbn07ICovXG4vLyBsZXQgaW5qZWN0ZWRNZXNzYWdlSGFuZGxlcjogTWVzc2FnZUhhbmRsZXIgfCBudWxsO1xuLypleHBvcnQgY29uc3QgZ2V0SW5qZWN0ZWRNZXNzYWdlSGFuZGxlciA9ICgpOiBNZXNzYWdlSGFuZGxlciA9PiB7XG4gICAgaWYgKCAhaW5qZWN0ZWRNZXNzYWdlSGFuZGxlciApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdNWVNPTUVJRC1Db250ZW50OiBObyBtZXNzYWdlIGhhbmRsZXIgY3JlYXRlZCcpO1xuICAgIH1cbiAgICByZXR1cm4gaW5qZWN0ZWRNZXNzYWdlSGFuZGxlcjtcbn07Ki9cbi8qZXhwb3J0IGNvbnN0IGNyZWF0ZUluamVjdGVkTWVzc2FnZUhhbmRsZXIgPSAoKTogTWVzc2FnZUhhbmRsZXIgPT4ge1xuICAgIGlmICggaW5qZWN0ZWRNZXNzYWdlSGFuZGxlciApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdNWVNPTUVJRC1Db250ZW50OiBNZXNzYWdlIGhhbmRsZXIgYWxyZWFkeSBjcmVhdGVkJyk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VuZE1lc3NhZ2UgPSAobXNnOiBhbnkpID0+IHtcbiAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKG1zZywgJ215c29tZWlkLWluamVjdGVkJyk7XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKHsgZGF0YTogbXNnLCBvcmlnaW4gfSkgPT4ge1xuICAgICAgICBpZiAoIG9yaWdpbj8uaW5kZXhPZihcIm15c29tZWlkXCIpID09PSAwICkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJNWVNPTUVJRC1Db250ZW50OiBnb3Qgc29tZSBraW5kIG9mIG1lc3NhZ2VcIiwge21zZywgb3JpZ2lufSk7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIGluamVjdGVkTWVzc2FnZUhhbmRsZXIgPSB7XG4gICAgICAgIHNlbmRNZXNzYWdlXG4gICAgfTtcblxuICAgIHJldHVybiBpbmplY3RlZE1lc3NhZ2VIYW5kbGVyO1xufTsqL1xudmFyIG1lc3NhZ2VIYW5kbGVyO1xudmFyIGdldE1lc3NhZ2VIYW5kbGVyID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiAoMCwgZXhwb3J0cy5jcmVhdGVDb250ZW50TWVzc2FnZUhhbmRsZXIpKCk7XG59O1xuZXhwb3J0cy5nZXRNZXNzYWdlSGFuZGxlciA9IGdldE1lc3NhZ2VIYW5kbGVyO1xudmFyIGNyZWF0ZUNvbnRlbnRNZXNzYWdlSGFuZGxlciA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAobWVzc2FnZUhhbmRsZXIpIHtcbiAgICAgICAgcmV0dXJuIG1lc3NhZ2VIYW5kbGVyO1xuICAgIH1cbiAgICB2YXIgbWVzc2FnZUhhbmRsZXJzID0gW107XG4gICAgdmFyIHJlc29sdmVycyA9IHt9O1xuICAgIC8vIENyZWF0ZSBCcmlkZ2UgYmV0d2VlbiBjb250ZW50IGFuZCBwb3B1cC9iYWNrZW5kLlxuICAgIHZhciBvbk1lc3NhZ2UgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgdmFyIF9iLCBfYywgX2Q7XG4gICAgICAgIHZhciBkYXRhID0gX2EuZGF0YTtcbiAgICAgICAgaWYgKCEoMCwgZXhwb3J0cy5pc015U09NRUlETWVzc2FnZSkoZGF0YSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmxvZyhcIm9uTWVzc2FnZVwiLCBkYXRhKTtcbiAgICAgICAgaWYgKGRhdGEudHlwZSA9PT0gXCJ2YWxpZGF0ZS1wcm9vZi1yZXNwb25zZVwiKSB7XG4gICAgICAgICAgICAvLyBkZWJ1Z2dlcjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgdHlwZSA9IGRhdGEudHlwZSwgdG8gPSBkYXRhLnRvO1xuICAgICAgICBpZiAoIXR5cGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJJZ25vcmVkIG1lc3NhZ2Ugd2l0aCBubyB0eXBlIFwiLCBkYXRhKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZS5pbmRleE9mKCctcmVzcG9uc2UnKSA+IDApIHtcbiAgICAgICAgICAgIHZhciByZXNvbHZlciA9IHJlc29sdmVyc1tkYXRhLnJlc3BvbnNlVG9dO1xuICAgICAgICAgICAgLy8gZGVidWdnZXI7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlcikge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlcihkYXRhLnBheWxvYWQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdObyByZXNwb25zZSBsaXN0ZW5lciBmb3InLCBkYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRvID09PSAnaW5qZWN0ZWQnKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIk1lc3NhZ2UgdG8gaW5qZWN0ZWQgaW5nb3JlZCBieSBjb250ZW50IG1lc3NhZ2UgaGFuZGxlci5cIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coJ01ZU09NRUlELUNvbnRlbnQ6IENvbnRlbnQgc2NyaXB0czogZ2V0IG1lc3NhZ2UgJywgX19hc3NpZ24oe30sIGRhdGEpKTtcbiAgICAgICAgaWYgKHRvID09PSAnYmFja2dyb3VuZCcpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTVlTT01FSUQtQ29udGVudDogQ29udGVudCBzY3JpcHRzOiBmb3J3YXJkaW5nIG1lc3NhZ2UgdG8gZXh0ZW5zaW9uLlwiLCBkYXRhKTtcbiAgICAgICAgICAgIGNocm9tZS5ydW50aW1lXG4gICAgICAgICAgICAgICAgLnNlbmRNZXNzYWdlKGRhdGEpXG4gICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJNWVNPTUVJRC1Db250ZW50OiBDb250ZW50IHNjcmlwdHMuIGdvdCByZXNwb25zZSAoQlJJREdJTkcgSVQpLlwiLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgLy8gZGVidWdnZXI7XG4gICAgICAgICAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKHJlc3BvbnNlLCAnKicpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgICAgICAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yID09PSBudWxsIHx8IGVycm9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICAgICAgICAgIH0sICcqJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0byA9PT0gXCJjb250ZW50XCIgJiYgdHlwZSA9PT0gJ2ZvcndhcmQnKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkZvcndhcmRpbmcgbWVzc2FnZSB0byBcIiArICgoX2IgPSBkYXRhLnBheWxvYWQpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi50byksIHsgbWVzc2FnZTogZGF0YS5wYXlsb2FkIH0pO1xuICAgICAgICAgICAgaWYgKFsncG9wdXAnLCAnYmFja2dyb3VuZCddLmluZGV4T2YoKF9jID0gZGF0YS5wYXlsb2FkKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MudG8pID49IDApIHtcbiAgICAgICAgICAgICAgICAvLyBzZW5kIHRvIGJhY2tncm91bmQhXG4gICAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoZGF0YS5wYXlsb2FkKVxuICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk1ZU09NRUlELUNvbnRlbnQ6IENvbnRlbnQgc2NyaXB0cy4gZ290IHJlc3BvbnNlLlwiLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICgocmVzcG9uc2UgPT09IG51bGwgfHwgcmVzcG9uc2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlc3BvbnNlLmVycm9yKSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk1ZU09NRUlELUNvbnRlbnQ6IFJlc3BvbnNlIGlzIGFuIGVycm9yOiB0aHJvd24gYXMgZXJyb3JcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiBhbiBlcnJvciBpcyB0aHJvd24gaW4gdGhlIGJhY2tncm91bmQgc2NyaXB0LCBwcm9wYWdhdGUgaXQgdG8gaW5qZWN0LlxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKChfYSA9IHJlc3BvbnNlLmVycm9yKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8qY29uc3QgbXNnUmVzcG9uc2U6IE15U29NZUlkRXh0ZW5zaW9uUmVzcG9uc2UgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtc2c6IHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgICAgICAgICAgIH07Ki9cbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJUT0RPOiBzZW5kIHJlc3BvbnNlIGJhY2sgdG8gb3JpZ2luLiBcIiwgcmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICAvL3dpbmRvdy5wb3N0TWVzc2FnZSggICk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHdpbmRvdy5wb3N0TWVzc2FnZShtc2dSZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5rbm93biBmb3J3YXJkaW5nIHRhcmdldCA6IFwiICsgKChfZCA9IGRhdGEucGF5bG9hZCkgPT09IG51bGwgfHwgX2QgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9kLnRvKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gVGhlIG1lc3NhZ2UgaXMgXG4gICAgICAgIGlmICh0byA9PT0gJ2NvbnRlbnQnKSB7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkNvbnRlbnQ6IFRoZSBtZXNzYWdlIGlzIGZvciBtZS5cIik7XG4gICAgICAgICAgICBtZXNzYWdlSGFuZGxlcnMuZm9yRWFjaChmdW5jdGlvbiAoeCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHgoZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLypjaHJvbWUucnVudGltZVxuICAgICAgICAgICAgICAgIC5zZW5kTWVzc2FnZShkYXRhKVxuICAgICAgICAgICAgICAgIC50aGVuKChyZXNwb25zZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTVlTT01FSUQtQ29udGVudDogQ29udGVudCBzY3JpcHRzLiBnb3QgcmVzcG9uc2UuXCIsIHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmVycm9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTVlTT01FSUQtQ29udGVudDogUmVzcG9uc2UgaXMgYW4gZXJyb3I6IHRocm93biBhcyBlcnJvclwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIElmIGFuIGVycm9yIGlzIHRocm93biBpbiB0aGUgYmFja2dyb3VuZCBzY3JpcHQsIHByb3BhZ2F0ZSBpdCB0byBpbmplY3QuXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocmVzcG9uc2UuZXJyb3IgPz8gdW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBtc2dSZXNwb25zZTogTXlTb01lSWRFeHRlbnNpb25SZXNwb25zZSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKG1zZ1Jlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5jYXRjaCgoZXJyb3I6IEVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2UobmV3IEVycm9yKGVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICAgICAgICB9KTsqL1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBvbk1lc3NhZ2UpO1xuICAgIC8vIFByb3BhZ2F0ZSBldmVudHMgZnJvbSBjb250ZW50IHNjcmlwdCBleHRlbnNpb24gLT4gaW5qZWN0XG4gICAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTVlTT01FSUQtQ29udGVudDogR290IG1lc3NhZ2UgZnJvbSBleHRlbnNpb24gXCIsIHsgZGF0YTogZGF0YSB9KTtcbiAgICAgICAgaWYgKCEoMCwgZXhwb3J0cy5pc015U09NRUlETWVzc2FnZSkoZGF0YSkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTVlTT01FSUQtQ29udGVudDogTm90IGEgTVlTT01FSUQgbWVzc2FnZVwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmxvZyhcIk1ZU09NRUlELUNvbnRlbnQ6IEZvcndhcmRpbmcgbWVzc2FnZSB0byBjb250ZW50IG1lc3NhZ2VIYW5kbGVyXCIpO1xuICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2UoZGF0YSwgXCIqXCIpOyAvLyBGb3J3YXJkIG1lc3NhZ2UuXG4gICAgfSk7XG4gICAgdmFyIGNyZWF0ZU1lc3NhZ2UgPSBmdW5jdGlvbiAodG8sIHR5cGUsIHBheWxvYWQsIGV4dHJhKSB7XG4gICAgICAgIHZhciBzZXJpYWwgPSBNYXRoLnJvdW5kKE1hdGgucmFuZG9tKCkgKiA5OTk5OTk5OTk5OTk5OTk5OTkpO1xuICAgICAgICB2YXIgZGF0YSA9IF9fYXNzaWduKF9fYXNzaWduKHsgdG86IHRvLCBmcm9tOiAnY29udGVudCcsIHR5cGU6IHR5cGUsIHBheWxvYWQ6IHBheWxvYWQsIHNlcmlhbDogc2VyaWFsIH0sIChleHRyYSAhPT0gbnVsbCAmJiBleHRyYSAhPT0gdm9pZCAwID8gZXh0cmEgOiB7fSkpLCB7IG9yaWdpbjogJ215c29tZScgfSk7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH07XG4gICAgbWVzc2FnZUhhbmRsZXIgPSB7XG4gICAgICAgIHNlbmRNZXNzYWdlOiBmdW5jdGlvbiAodG8sIHR5cGUsIHBheWxvYWQsIGV4dHJhKSB7XG4gICAgICAgICAgICB2YXIgZGF0YSA9IGNyZWF0ZU1lc3NhZ2UodG8sIHR5cGUsIHBheWxvYWQsIGV4dHJhKTtcbiAgICAgICAgICAgIGlmICh0byA9PT0gJ2JhY2tncm91bmQnKSB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoZGF0YSwgZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdGF0ZSA9IF9hLnN0YXRlO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0byA9PT0gJ2luamVjdGVkLXdpZGdldCcpIHtcbiAgICAgICAgICAgICAgICB2YXIgaWQgPSBkYXRhLnBheWxvYWQuaWQ7XG4gICAgICAgICAgICAgICAgaWYgKCFyb290XzEubXlzb21lLndpZGdldHNbaWRdKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyB3aWRnZXQgd2l0aCBpZCA6IFwiICsgaWQpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhciB3bmQgPSByb290XzEubXlzb21lLndpZGdldHNbaWRdLmlmcmFtZS5jb250ZW50V2luZG93O1xuICAgICAgICAgICAgICAgIGlmICghd25kKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBmcmFtZSBjb250ZW50IHdpbmRvdyBhdmFpbGFibGVcIik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgd25kLnBvc3RNZXNzYWdlKEpTT04uc3RyaW5naWZ5KGRhdGEpLCAnKicpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZShkYXRhLCAnKicpO1xuICAgICAgICB9LFxuICAgICAgICBzZW5kTWVzc2FnZVdSZXNwb25zZTogZnVuY3Rpb24gKHRvLCB0eXBlLCBwYXlsb2FkLCBleHRyYSkgeyByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBkYXRhLCBpZCwgd25kO1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgIGRhdGEgPSBjcmVhdGVNZXNzYWdlKHRvLCB0eXBlLCBwYXlsb2FkLCBleHRyYSk7XG4gICAgICAgICAgICAgICAgaWYgKHRvID09PSAnYmFja2dyb3VuZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoZGF0YSwgZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImJhY2tncm91bmQgcmV0dXJuZWQgcmVzdWx0OiBcIiwgcmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodG8gPT09ICdpbmplY3RlZC13aWRnZXQnKSB7XG4gICAgICAgICAgICAgICAgICAgIGlkID0gZGF0YS5wYXlsb2FkLmlkO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyB3aWRnZXQgd2l0aCBpZCA6IFwiICsgaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHduZCA9IHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0uaWZyYW1lLmNvbnRlbnRXaW5kb3c7XG4gICAgICAgICAgICAgICAgICAgIGlmICghd25kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiTm8gZnJhbWUgY29udGVudCB3aW5kb3cgYXZhaWxhYmxlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHduZC5wb3N0TWVzc2FnZShKU09OLnN0cmluZ2lmeShkYXRhKSwgJyonKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2UoZGF0YSwgJyonKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmVyc1tkYXRhLnNlcmlhbF0gPSByZXNvbHZlO1xuICAgICAgICAgICAgICAgICAgICB9KV07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7IH0sXG4gICAgICAgIGFkZE1lc3NhZ2VIYW5kbGVyOiBmdW5jdGlvbiAoaGFuZGxlcikge1xuICAgICAgICAgICAgbWVzc2FnZUhhbmRsZXJzLnB1c2goaGFuZGxlcik7XG4gICAgICAgIH0sXG4gICAgfTtcbiAgICByZXR1cm4gbWVzc2FnZUhhbmRsZXI7XG59O1xuZXhwb3J0cy5jcmVhdGVDb250ZW50TWVzc2FnZUhhbmRsZXIgPSBjcmVhdGVDb250ZW50TWVzc2FnZUhhbmRsZXI7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuY3JlYXRlRnJhbWVXaWRnZXQgPSB2b2lkIDA7XG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xudmFyIGNyZWF0ZUZyYW1lV2lkZ2V0ID0gZnVuY3Rpb24gKHVybCkge1xuICAgIHZhciBjcmVhdGVkID0gZmFsc2U7XG4gICAgdmFyIHNldHVwID0gZmFsc2U7XG4gICAgdmFyIGlmcmFtZUNvbnRlbnQgPSB1cmw7IC8qIFwiZGF0YTp0ZXh0L2h0bWw7YmFzZTY0LFwiICsgdXRmOF90b19iNjQoYFxuICAgICAgICA8aGVhZD5cbiAgICAgICAgICAgIDxzY3JpcHQgdHlwZT1cInRleHQvamF2YXNjcmlwdFwiPlxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiaWZyYW1lIGNvbnRlbnRcIik7XG4gICAgICAgICAgICA8L3NjcmlwdD5cbiAgICAgICAgPC9oZWFkPlxuICAgICAgICA8Ym9keT5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgc2FkYXNkc2FcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2JvZHk+XG4gICAgYCk7Ki9cbiAgICBpZiAoIWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibXlzb21lLWZyYW1lLXJvb3RcIikpIHtcbiAgICAgICAgdmFyIGVsZW0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgZWxlbS5pZCA9IFwibXlzb21lLWZyYW1lLXJvb3RcIjtcbiAgICAgICAgZWxlbS5pbm5lckhUTUwgPSBcIlxcblxcdFxcdFxcdDxzdHlsZT5cXG5cXHRcXHRcXHQ8L3N0eWxlPlxcblxcdFxcdFxcdDxkaXYgaWQ9XFxcIm15c29tZS1mcmFtZS1jb250YWluZXJcXFwiIHN0eWxlPVxcXCJwb3NpdGlvbjogZml4ZWQ7bGVmdDogMDt0b3A6IDA7cmlnaHQ6IDA7Ym90dG9tOiAwO3otaW5kZXg6IDk5OTk7YmFja2dyb3VuZDogI2M5YzljOTY2O2Rpc3BsYXk6IGZsZXg7YWxpZ24taXRlbXM6IGNlbnRlcjtwbGFjZS1jb250ZW50OiBjZW50ZXI7XFxcIj5cXG5cXHRcXHRcXHRcXHQ8ZGl2IGlkPVxcXCJteXNvbWUtZnJhbWUtdmlld1xcXCIgc3R5bGU9XFxcImJhY2tncm91bmQ6IHdoaXRlO21heC13aWR0aDogMzgwcHg7aGVpZ2h0OiA1MjJweDtib3JkZXItcmFkaXVzOiA0cHg7Ym94LXNoYWRvdzogMHB4IDFweCAzNHB4IDlweCByZ2JhKDAsMCwwLDAuMjcpO3dpZHRoOiA4MCU7cG9zaXRpb246IGZpeGVkO2NvbG9yOiBibGFjaztib3JkZXItcmFkaXVzOiAxMHB4O1xcXCI+XFxuXFx0XFx0XFx0XFx0XFx0PGlmcmFtZSBzcmM9XFxcIlwiLmNvbmNhdChpZnJhbWVDb250ZW50LCBcIlxcXCIgdGl0bGU9XFxcImRlc2NyaXB0aW9uXFxcIiBzdHlsZT1cXFwid2lkdGg6IDEwMCU7IGhlaWdodDogMTAwJVxcXCI+PC9pZnJhbWU+XFxuXFx0XFx0XFx0XFx0PC9kaXY+XFxuXFx0XFx0XFx0PC9kaXY+XFxuXFx0XFx0XFx0XCIpO1xuICAgICAgICBjcmVhdGVkID0gdHJ1ZTtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbGVtKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHV0aWxzXzEubG9nZ2VyLmVycm9yKFwiUm9vdCBlbGVtZW50IGFscmVhZHkgZXhpc3RlZCEgVGhpcyBtYXkgbWFrZSB0aGUgcGx1Z2luIHN0b3Agd29ya2luZy5cIik7XG4gICAgfVxuICAgIHZhciByb290ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtZnJhbWUtcm9vdFwiKTtcbiAgICBpZiAoIXJvb3QpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gd2lkZ2V0IGZvdW5kLlwiKTtcbiAgICB9XG4gICAgaWYgKCFzZXR1cCkge1xuICAgICAgICAvKmxldCBidG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1mcmFtZS1jbG9zZS1idXR0b25cIikgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gICAgICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibXlzb21lLWZyYW1lLXJvb3RcIik7XG4gICAgICAgICAgICBpZiAoIHJvb3QgKSB7XG4gICAgICAgICAgICAgICAgcm9vdC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBidG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1mcmFtZS1jcmVhdGUtYnV0dG9uXCIpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICAgICAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxpbmtVcmwgPSBnZXRVcmxUb0NyZWF0ZVByb29mKCk7XG4gICAgICAgICAgICBpZiAoIGxpbmtVcmwgKSB7XG4gICAgICAgICAgICAgICAgd2luZG93Lm9wZW4obGlua1VybCwgXCJfYmxhbmtcIik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pOyovXG4gICAgICAgIHNldHVwID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZWxlbWVudHM6IHtcbiAgICAgICAgICAgIHJvb3Q6IHJvb3QsXG4gICAgICAgIH0sXG4gICAgICAgIHNldEluaXRpYWxTdGF0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICB9LFxuICAgICAgICBoaWRlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByb290LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgIH0sXG4gICAgICAgIHNob3c6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJvb3Quc3R5bGUuZGlzcGxheSA9ICdpbmxpbmUtYmxvY2snO1xuICAgICAgICB9LFxuICAgIH07XG59O1xuZXhwb3J0cy5jcmVhdGVGcmFtZVdpZGdldCA9IGNyZWF0ZUZyYW1lV2lkZ2V0O1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcbiAgICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICAgIH1cbn07XG52YXIgX19pbXBvcnREZWZhdWx0ID0gKHRoaXMgJiYgdGhpcy5fX2ltcG9ydERlZmF1bHQpIHx8IGZ1bmN0aW9uIChtb2QpIHtcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IFwiZGVmYXVsdFwiOiBtb2QgfTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG4vKiBlc2xpbnQtZGlzYWJsZSAqL1xuY29uc29sZS5sb2coXCJNeVNvTWUgZXh0ZW5zaW9uXCIpO1xudmFyIGxpbmtlZF9pbl8xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCIuL2ludGVncmF0aW9ucy9saW5rZWQtaW5cIikpO1xudmFyIHRlc3RfMSA9IF9faW1wb3J0RGVmYXVsdChyZXF1aXJlKFwiLi9pbnRlZ3JhdGlvbnMvdGVzdFwiKSk7XG52YXIgbXlzb21lX2FwaV8xID0gX19pbXBvcnREZWZhdWx0KHJlcXVpcmUoXCIuL2ludGVncmF0aW9ucy9teXNvbWUtYXBpXCIpKTtcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XG52YXIgY29udGVudF9tZXNzYWdpbmdfMSA9IHJlcXVpcmUoXCIuL2NvbnRlbnQtbWVzc2FnaW5nXCIpO1xudmFyIHJvb3RfMSA9IHJlcXVpcmUoXCIuL3Jvb3RcIik7XG52YXIgcGxhdGZvcm0gPSAoMCwgdXRpbHNfMS5kZXRlY3RQbGF0Zm9ybSkoKTtcbi8vIEV4cG9zZSB0aGUgb2JqZWN0IHRvIHRoZSBjb25zb2xlIHNvIHdlIGNhbiBydW4gY29tbWFuZHMgb24gaXQuXG53aW5kb3cubXlzb21lID0gcm9vdF8xLm15c29tZTtcbmlmIChwbGF0Zm9ybSAhPT0gbnVsbCkge1xuICAgIGNvbnNvbGUubG9nKFwiQ3JlYXRpbmcgbWVzc2FnZSBoYW5kbGVyXCIpO1xuICAgIHZhciBtZXNzYWdlSGFuZGxlciA9ICgwLCBjb250ZW50X21lc3NhZ2luZ18xLmdldE1lc3NhZ2VIYW5kbGVyKSgpO1xuICAgIG1lc3NhZ2VIYW5kbGVyLmFkZE1lc3NhZ2VIYW5kbGVyKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIHZhciB0eXBlID0gZGF0YS50eXBlLCBwYXlsb2FkID0gZGF0YS5wYXlsb2FkO1xuICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ2NyZWF0ZS1iYWRnZSc6XG4gICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS5jcmVhdGVCYWRnZSh7IHNob3dBdHRlbnRpb246IGZhbHNlIH0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnY3JlYXRlLXRvdXInOlxuICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUuY3JlYXRlVG91cignbGkuY2hhbmdlLWJhY2tncm91bmQnKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3JlZGlyZWN0JzpcbiAgICAgICAgICAgICAgICBpZiAocGF5bG9hZCA9PT0gbnVsbCB8fCBwYXlsb2FkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXlsb2FkLnVybCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJlZGlyZWN0aW5nIHVybCBcIiwgeyB1cmw6IHBheWxvYWQgPT09IG51bGwgfHwgcGF5bG9hZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGF5bG9hZC51cmwgfSk7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gcGF5bG9hZC51cmw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdSZWRpcmVjdCByZXF1ZXN0ZWQgLSBidXQgbm8gdXJsIGdpdmVuIDogJywgcGF5bG9hZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnb3Blbi11cmwnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBheWxvYWQgPT09IG51bGwgfHwgcGF5bG9hZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGF5bG9hZC51cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiT3BlbmluZyB1cmwgXCIsIHsgdXJsOiBwYXlsb2FkLnVybCB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKHBheWxvYWQudXJsLCAnX2JsYW5rJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdPcGVuIHVybCByZXF1ZXN0ZWQgLSBidXQgbm8gdXJsIGdpdmVuIDogJywgcGF5bG9hZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICdjbG9zZS13aWRnZXQnOlxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGlkID0gcGF5bG9hZC5pZCwgcmVzdWx0ID0gcGF5bG9hZC5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZpbmRpbmcgd2lkZ2V0IHdpdGggaWQgXCIgKyBpZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLndpZGdldHNbaWRdLm9uUmVzdWx0ICYmXG4gICAgICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLndpZGdldHNbaWRdLm9uUmVzdWx0KHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0uZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3dpZGdldC1jcmVhdGVkJzpcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBpZCA9IHBheWxvYWQuaWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIk5vIHdpZGdldCBleGlzdHMgd2l0aCA6IFwiICsgaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXS5zZXRDcmVhdGVkKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgKDAsIG15c29tZV9hcGlfMS5kZWZhdWx0KSgpO1xuICAgIChmdW5jdGlvbiAoKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZV8xO1xuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICBfYS50cnlzLnB1c2goWzAsIDIsICwgM10pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCB1dGlsc18xLnN0b3JhZ2UuaW5pdCgpXTtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBlXzEgPSBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xuICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEocGxhdGZvcm0gPT09ICdsaScpKSByZXR1cm4gWzMgLypicmVhayovLCA1XTtcbiAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5sb2dnZXIuaW5mbyhcIk15U29NZUlkOiBJbmplY3RpbmcgcGx1Z2luIGludG8gTGlua2VkSW4hXCIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCAoMCwgbGlua2VkX2luXzEuZGVmYXVsdCkoKV07XG4gICAgICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDddO1xuICAgICAgICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEocGxhdGZvcm0gPT09ICd0ZXN0JykpIHJldHVybiBbMyAvKmJyZWFrKi8sIDddO1xuICAgICAgICAgICAgICAgICAgICB1dGlsc18xLmxvZ2dlci5sb2coXCJNeVNvTWVJZDogSW5qZWN0aW5nIHBsdWdpbiBpbnRvIFRlc3QgcGFnZSFcIik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sICgwLCB0ZXN0XzEuZGVmYXVsdCkoKV07XG4gICAgICAgICAgICAgICAgY2FzZSA2OlxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gNztcbiAgICAgICAgICAgICAgICBjYXNlIDc6IHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7IH0pKCkudGhlbigpLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xufVxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19hc3NpZ24gPSAodGhpcyAmJiB0aGlzLl9fYXNzaWduKSB8fCBmdW5jdGlvbiAoKSB7XG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKVxuICAgICAgICAgICAgICAgIHRbcF0gPSBzW3BdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0O1xuICAgIH07XG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59O1xudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgICB9KTtcbn07XG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XG4gICAgICAgIHdoaWxlIChnICYmIChnID0gMCwgb3BbMF0gJiYgKF8gPSAwKSksIF8pIHRyeSB7XG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcbiAgICB9XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi4vdXRpbHNcIik7XG52YXIgc2hpZWxkXzEgPSByZXF1aXJlKFwiLi4vc2hpZWxkXCIpO1xudmFyIHBvcHVwXzEgPSByZXF1aXJlKFwiLi4vcG9wdXBcIik7XG52YXIgcm9vdF8xID0gcmVxdWlyZShcIi4uL3Jvb3RcIik7XG52YXIgdG91cl8xID0gcmVxdWlyZShcIi4uL3RvdXJcIik7XG52YXIgdHJhY2tpbmdfMSA9IHJlcXVpcmUoXCIuLi90cmFja2luZ1wiKTtcbnZhciBjb250ZW50X21lc3NhZ2luZ18xID0gcmVxdWlyZShcIi4uL2NvbnRlbnQtbWVzc2FnaW5nXCIpO1xudmFyIG52aXNpdCA9IDA7XG52YXIgcm9vdCA9IG51bGw7XG52YXIgc3RhdGUgPSB7XG4gICAgcHJvb2ZVcmw6ICcnLFxuICAgIHBhZ2VIYXNCZWVuVmVyaWZpZWQ6IGZhbHNlLFxufTtcbnZhciBURVNUID0gZmFsc2U7XG52YXIgV0VCU0lURV9CQVNFX1VSTCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFRFU1QgPyBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMFwiIDogXCJodHRwczovL2FwcC50ZXN0bmV0Lm15c29tZS5pZFwiOyB9O1xudmFyIFNFUlZJQ0VfQkFTRV9VUkwgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBURVNUID8gJ2h0dHBzOi8vYXBpLnRlc3RuZXQubXlzb21lLmlkL3YxJyA6IFwiaHR0cHM6Ly9hcGkudGVzdG5ldC5teXNvbWUuaWQvdjFcIjsgfTtcbnZhciB3ZWxjb21lU2hvd24gPSBudWxsO1xudmFyIHNoaWVsZCA9IG51bGw7XG52YXIgcHJvZmlsZVN0YXR1cyA9ICgwLCB0cmFja2luZ18xLmNyZWF0ZVRyYWNrZXIpKHtcbiAgICBuYW1lOiAncHJvZmlsZVN0YXR1cycsXG4gICAgY21wOiBmdW5jdGlvbiAoY3VyVmFsdWUsIGNvbXBhcmVXaXRoKSB7XG4gICAgICAgIGlmICghY3VyVmFsdWUgfHwgIWNvbXBhcmVXaXRoKSB7XG4gICAgICAgICAgICByZXR1cm4gY3VyVmFsdWUgIT09IGNvbXBhcmVXaXRoOyAvLyBJZiBib3RoIGFyZSBudWxsIHRoZW4gZmFsc2UgaWYgb25lIG9mIHRoZW0gaXMgYSB2YWxpZCB2YWx1ZSB0aGVuIHRydWUuXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGN1clZhbHVlLnN0YXR1cyAhPT0gY29tcGFyZVdpdGguc3RhdHVzICYmXG4gICAgICAgICAgICBjdXJWYWx1ZS5wYWdlICE9PSBjb21wYXJlV2l0aC5wYWdlICYmXG4gICAgICAgICAgICBjdXJWYWx1ZS50eXBlICE9PSBjb21wYXJlV2l0aC50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7IC8vIE5vIGNoYW5nZS5cbiAgICB9XG59KTtcbmZ1bmN0aW9uIHNldFBhZ2VTdGF0dXMocGFnZSwgdHlwZSkge1xuICAgIHZhciBfYTtcbiAgICB2YXIgcHMgPSAoX2EgPSBwcm9maWxlU3RhdHVzLmdldCgpKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB7XG4gICAgICAgIHN0YXR1czogbnVsbCxcbiAgICAgICAgcGFnZTogcGFnZSxcbiAgICAgICAgdHlwZTogdHlwZSxcbiAgICB9O1xuICAgIHBzLnBhZ2UgPSBwYWdlO1xuICAgIHBzLnR5cGUgPSB0eXBlO1xuICAgIHByb2ZpbGVTdGF0dXMudXBkYXRlKHtcbiAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHBzOyB9LFxuICAgIH0pO1xufVxuZnVuY3Rpb24gc2V0UHJvZmlsZVN0YXR1c1Jlc29sdmVkKHBhZ2UsIHR5cGUsIHN0YXR1cykge1xuICAgIHZhciBfYTtcbiAgICB2YXIgcHMgPSAoX2EgPSBwcm9maWxlU3RhdHVzLmdldCgpKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB7XG4gICAgICAgIHN0YXR1czogc3RhdHVzLFxuICAgICAgICBwYWdlOiBwYWdlLFxuICAgICAgICB0eXBlOiB0eXBlLFxuICAgIH07XG4gICAgcHMucGFnZSA9IHBhZ2U7XG4gICAgcHMudHlwZSA9IHR5cGU7XG4gICAgcHMuc3RhdHVzID0gc3RhdHVzO1xuICAgIHByb2ZpbGVTdGF0dXMudXBkYXRlKHtcbiAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHBzOyB9LFxuICAgIH0pO1xufVxuZnVuY3Rpb24gcXNhKHMpIHtcbiAgICB2YXIgX2E7XG4gICAgcmV0dXJuIEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKChfYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwocykpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IFtdKTtcbn1cbmZ1bmN0aW9uIHFzKHMpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzKTtcbn1cbkhUTUxFbGVtZW50LnByb3RvdHlwZS5xc2EgPSBmdW5jdGlvbiAocykge1xuICAgIHZhciBfYTtcbiAgICByZXR1cm4gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoKF9hID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzKSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW10pO1xufTtcbnZhciBfZCA9IEhUTUxFbGVtZW50LnByb3RvdHlwZS5xcyA9IGZ1bmN0aW9uIChzKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Iocyk7XG59O1xudmFyIGZldGNoUVJGcm9tSW1hZ2UgPSBmdW5jdGlvbiAodXJsKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHZhciBiYXNlLCB2YWxpZGF0ZVVybCwgcXIsIGVfMTtcbiAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgUVIgY29kZSBmcm9tIHVybCA6IFwiICsgdXJsKTtcbiAgICAgICAgICAgICAgICBpZiAoIXVybCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHVybCBwcm92aWRlZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDE7XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgX2EudHJ5cy5wdXNoKFsxLCAzLCAsIDRdKTtcbiAgICAgICAgICAgICAgICBiYXNlID0gU0VSVklDRV9CQVNFX1VSTCgpO1xuICAgICAgICAgICAgICAgIHZhbGlkYXRlVXJsID0gXCJcIi5jb25jYXQoYmFzZSwgXCIvcXIvdmFsaWRhdGU/dXJsPVwiKS5jb25jYXQoZW5jb2RlVVJJQ29tcG9uZW50KHVybCkpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0dGluZyBRUiBjb2RlIGZvciA6IFwiICsgdXJsKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBmZXRjaCh2YWxpZGF0ZVVybClcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSAyMDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgMzAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLnRleHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJObyBRUiBjb2RlIGZvdW5kIFwiICsgcmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlcnJvciA9IG5ldyBFcnJvcihyZXNwb25zZS5zdGF0dXNUZXh0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkgeyByZXR1cm4gSlNPTi5wYXJzZShyZXNwb25zZSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChkYXRhID09PSBudWxsIHx8IGRhdGEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRhdGEuZXJyb3IpID8gbnVsbCA6IChfYSA9IGRhdGEgPT09IG51bGwgfHwgZGF0YSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGF0YS5yZXN1bHQpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIgIT0gbnVsbCAmJiAncmVzcG9uc2UnIGluIGVyciAmJiBlcnIucmVzcG9uc2Uuc3RhdHVzID09PSA0MDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQ29ubmV0aW9uIGVycm9yXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICB9KV07XG4gICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgcXIgPSBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHFyOiBxcixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbm5lY3Rpb25FcnJvcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIH1dO1xuICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgIGVfMSA9IF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVfMSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHFyOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29ubmVjdGlvbkVycm9yOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB9XTtcbiAgICAgICAgICAgIGNhc2UgNDogcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICB9XG4gICAgfSk7XG59KTsgfTtcbnZhciB2ZXJpZnlQcm9maWxlID0gZnVuY3Rpb24gKHByb2ZpbGVVc2VySWQsIGJhY2tncm91bmRVcmwsIHByb2ZpbGVQaWN0dXJlVXJsKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgIHZhciBxclJlc3VsdCwgY29ubmVjdGlvbkVycm9yLCBfYSwgcXIsIGVyciwgcHJvZmlsZUltYWdlVXJsLCBfYiwgcXIsIGVycjtcbiAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9jKSB7XG4gICAgICAgIHN3aXRjaCAoX2MubGFiZWwpIHtcbiAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICBxclJlc3VsdCA9IG51bGw7XG4gICAgICAgICAgICAgICAgY29ubmVjdGlvbkVycm9yID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKGJhY2tncm91bmRVcmwgPT09ICdkZWZhdWx0Jykge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJhY2tncm91bmQgaXMgdGhlIGRlZmF1bHQgYW5kIGNvbnRhaW5zIG5vIFFSLlwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHByb2ZpbGVQaWN0dXJlVXJsID09PSAnZGVmYXVsdCcgfHwgcHJvZmlsZVBpY3R1cmVVcmwgPT09ICdkYXRhOmltYWdlL2dpZjtiYXNlNjQsUjBsR09EbGhBUUFCQUlBQUFBQUFBUC8vL3lINUJBRUFBQUFBTEFBQUFBQUJBQUVBQUFJQlJBQTcnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUHJvZmlsZSBwaWN0dXJlIGlzIHRoZSBkZWZhdWx0IGFuZCBjb250YWlucyBubyBRUi5cIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghKCFxclJlc3VsdCAmJiBiYWNrZ3JvdW5kVXJsICYmIGJhY2tncm91bmRVcmwgIT09ICdkZWZhdWx0JykpIHJldHVybiBbMyAvKmJyZWFrKi8sIDJdO1xuICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGZldGNoUVJGcm9tSW1hZ2UoYmFja2dyb3VuZFVybCldO1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIF9hID0gX2Muc2VudCgpLCBxciA9IF9hLnFyLCBlcnIgPSBfYS5jb25uZWN0aW9uRXJyb3I7XG4gICAgICAgICAgICAgICAgaWYgKHFyKSB7XG4gICAgICAgICAgICAgICAgICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwiUVIgaW4gYmFja2dyb3VuZDogWUVTXCIpO1xuICAgICAgICAgICAgICAgICAgICBxclJlc3VsdCA9IHFyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgKDAsIHV0aWxzXzEudmVyYm9zZSkoXCJRUiBpbiBiYWNrZ3JvdW5kOiBOT1wiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCFxciAmJiBlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29ubmVjdGlvbkVycm9yID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgKDAsIHV0aWxzXzEudmVyYm9zZSkoXCJGZXRjaGluZyBRUiByZXN1bHQgZnJvbSBiYWNrZ3JvdW5kIGltYWdlOiBObyBiYWNrZ3JvdW5kIGltYWdlIGZvdW5kLlwiKTtcbiAgICAgICAgICAgICAgICBfYy5sYWJlbCA9IDM7XG4gICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgaWYgKCEoIXFyUmVzdWx0ICYmIHByb2ZpbGVQaWN0dXJlVXJsICYmIHByb2ZpbGVQaWN0dXJlVXJsICE9PSAnZGVmYXVsdCcgJiYgcHJvZmlsZVBpY3R1cmVVcmwgIT09ICdkYXRhOmltYWdlL2dpZjtiYXNlNjQsUjBsR09EbGhBUUFCQUlBQUFBQUFBUC8vL3lINUJBRUFBQUFBTEFBQUFBQUJBQUVBQUFJQlJBQTcnKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgNV07XG4gICAgICAgICAgICAgICAgKDAsIHV0aWxzXzEudmVyYm9zZSkoXCJGZXRjaGluZyBRUiByZXN1bHQgZnJvbSBwcm9maWxlIGltYWdlXCIpO1xuICAgICAgICAgICAgICAgIHByb2ZpbGVJbWFnZVVybCA9IHByb2ZpbGVQaWN0dXJlVXJsO1xuICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIGZldGNoUVJGcm9tSW1hZ2UocHJvZmlsZUltYWdlVXJsKV07XG4gICAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICAgICAgX2IgPSBfYy5zZW50KCksIHFyID0gX2IucXIsIGVyciA9IF9iLmNvbm5lY3Rpb25FcnJvcjtcbiAgICAgICAgICAgICAgICBpZiAocXIpIHtcbiAgICAgICAgICAgICAgICAgICAgKDAsIHV0aWxzXzEudmVyYm9zZSkoXCJRUiBpbiBiYWNrZ3JvdW5kOiBZRVNcIik7XG4gICAgICAgICAgICAgICAgICAgIHFyUmVzdWx0ID0gcXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAoMCwgdXRpbHNfMS52ZXJib3NlKShcIlFSIGluIGJhY2tncm91bmQ6IE5PXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIXFyICYmIGVycikge1xuICAgICAgICAgICAgICAgICAgICBjb25uZWN0aW9uRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBfYy5sYWJlbCA9IDU7XG4gICAgICAgICAgICBjYXNlIDU6IHJldHVybiBbMiAvKnJldHVybiovLCB7XG4gICAgICAgICAgICAgICAgICAgIHFyUmVzdWx0OiBxclJlc3VsdCxcbiAgICAgICAgICAgICAgICAgICAgY29ubmVjdGlvbkVycm9yOiBjb25uZWN0aW9uRXJyb3IsXG4gICAgICAgICAgICAgICAgICAgIHByb2ZpbGVVc2VySWQ6IHByb2ZpbGVVc2VySWQsXG4gICAgICAgICAgICAgICAgfV07XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9O1xudmFyIGVuc3VyZVdpZGdldCA9IGZ1bmN0aW9uICgpIHtcbiAgICB1dGlsc18xLmxvZ2dlci5pbmZvKFwiQWRkaW5nIG15c29tZS5pZCBXaWRnZXRcIik7XG4gICAgdmFyIG5hbWVFbGVtZW50ID0gKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJoMVwiKVswXSk7XG4gICAgaWYgKCFuYW1lRWxlbWVudCB8fCAhbmFtZUVsZW1lbnQucGFyZW50RWxlbWVudCkge1xuICAgICAgICB1dGlsc18xLmxvZ2dlci5lcnJvcihcIkZhaWxlZCB0byBmaW5kIHByb2ZpbGUgbmFtZSBlbGVtZW50IC0gTm8gV2lkZ2V0IEFuY2hvci5cIik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgd2lkZ2V0ID0gKDAsIHNoaWVsZF8xLmNyZWF0ZVNoaWVsZFdpZGdldCkobmFtZUVsZW1lbnQucGFyZW50RWxlbWVudCwge1xuICAgICAgICBvbkNsaWNrZWQ6IGZ1bmN0aW9uIChzdGF0ZSwgcHJvb2ZVcmwpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdTaGllbGQgY2xpY2tlZCcsIHsgc3RhdGU6IHN0YXRlLCBwcm9vZlVybDogcHJvb2ZVcmwgfSk7XG4gICAgICAgICAgICByb290XzEubXlzb21lLmJhZGdlQ2xpY2tIYW5kbGVyICYmXG4gICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS5iYWRnZUNsaWNrSGFuZGxlcih7XG4gICAgICAgICAgICAgICAgICAgIG9yaWdpbjogJ3NoaWVsZCcsXG4gICAgICAgICAgICAgICAgICAgIHByb2ZpbGU6ICdvdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIHByb29mVXJsOiBwcm9vZlVybFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgIH0pO1xuICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwiV2lkZ2V0IGNyZWF0ZWRcIiwgd2lkZ2V0KTtcbiAgICB3aWRnZXQuc2V0SW5pdGlhbFN0YXRlKCk7XG4gICAgcmV0dXJuIHdpZGdldDtcbn07XG4oZnVuY3Rpb24gKCkgeyByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc3RhZ2luZztcbiAgICB2YXIgX2E7XG4gICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYikge1xuICAgICAgICBzd2l0Y2ggKF9iLmxhYmVsKSB7XG4gICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIHV0aWxzXzEuc3RvcmFnZS5nZXQoXCJzdGFnaW5nXCIsIHRydWUpXTtcbiAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICBzdGFnaW5nID0gKF9hID0gKF9iLnNlbnQoKSkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IGZhbHNlO1xuICAgICAgICAgICAgICAgIFRFU1QgPSAhIXN0YWdpbmc7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJ0ZXN0IFwiLCBURVNUKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9KSgpLnRoZW4oKS5jYXRjaChjb25zb2xlLmVycm9yKTtcbnZhciB0cmFja1Byb29mUVIgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ3Byb29mUVInLFxufSk7XG52YXIgdHJhY2tVcmwgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ3VybCcsXG4gICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbi5ocmVmOyB9LFxufSk7XG52YXIgdHJhY2tPblByb2ZpbGVVcmwgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ29uUHJvZmlsZVVybCcsXG4gICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuICEhKDAsIHV0aWxzXzEuaXNPbkxpbmtlZEluUHJvZmlsZVVybCkoKTsgfVxufSk7XG52YXIgdHJhY2tPbkZlZWRVcmwgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ29uRmVlZFVybCcsXG4gICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuICgwLCB1dGlsc18xLmlzT25MaW5rZWRJbkZlZWRVcmwpKCk7IH1cbn0pO1xudmFyIHRyYWNrT25Pd25Qcm9maWxlT3JGZWVkID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoe1xuICAgIG5hbWU6ICdvbk93blByb2ZpbGVPckZlZWQnLFxuICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7IHJldHVybiAoMCwgdXRpbHNfMS5vbk93bkxpbmtlZEluUHJvZmlsZU9yRmVlZFVybCkoKTsgfSxcbn0pO1xudmFyIHRyYWNrT3duUHJvZmlsZU5hbWUgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ293blByb2ZpbGVOYW1lJ1xufSk7XG52YXIgdHJhY2tQcm9maWxlVXNlcklkID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoe1xuICAgIG5hbWU6ICdwcm9maWxlVXNlcklkJ1xufSk7XG52YXIgdHJhY2tQcm9maWxlTmFtZSA9ICgwLCB0cmFja2luZ18xLmNyZWF0ZVRyYWNrZXIpKHtcbiAgICBuYW1lOiAncHJvZmlsZU5hbWUnXG59KTtcbnZhciB0cmFja093blByb2ZpbGVVc2VySWQgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ293blByb2ZpbGVVc2VySWRPYnNlcnZlZCcsXG4gICAgbW9kZTogJ29ic2VydmVkJyxcbn0pO1xudmFyIHRyYWNrT3RoZXJQcm9maWxlVXNlcklkID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoe1xuICAgIG5hbWU6ICdvdGhlclByb2ZpbGUnLFxuICAgIG1vZGU6ICdvYnNlcnZlZCcsXG59KTtcbnZhciB0cmFja0hlYWRlciA9ICgwLCB0cmFja2luZ18xLmNyZWF0ZVRyYWNrZXIpKHtcbiAgICBuYW1lOiAnaGVhZGVyJyxcbn0pO1xudmFyIHRyYWNrT25Pd25GZWVkID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoe1xuICAgIG5hbWU6ICdvbk93bkZlZWQnLFxufSk7XG52YXIgdHJhY2tPbk93blBhZ2UgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ29uT3duUGFnZScsXG59KTtcbnZhciB0cmFja0JhY2tncm91bmRVcmwgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ2JhY2tncm91bmRVcmwnLFxufSk7XG52YXIgdHJhY2tWZXJpZnlTdGF0dXMgPSAoMCwgdHJhY2tpbmdfMS5jcmVhdGVUcmFja2VyKSh7XG4gICAgbmFtZTogJ3ZlcmlmeVN0YXR1cycsXG59KTtcbnZhciB0cmFja1Byb2ZpbGVQaWN0dXJlVXJsID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoe1xuICAgIG5hbWU6ICdwcm9maWxlUGljdHVyZVVybCcsXG59KTtcbnZhciB0cmFja1BhdGhuYW1lID0gKDAsIHRyYWNraW5nXzEuY3JlYXRlVHJhY2tlcikoeyBuYW1lOiAncm91dGUnIH0pO1xudmFyIGNyZWF0ZUhlYXJ0YmVhdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAvLyBsZXQgdXBkYXRlUGFnZVN0YXR1cyA9IGZhbHNlO1xuICAgIHZhciBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgdGltZVNpbmNlU3RhcnQgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKSAtIHN0YXJ0VGltZTtcbiAgICAgICAgdmFyIHVybCA9IHRyYWNrVXJsLnVwZGF0ZSgpLnZhbHVlO1xuICAgICAgICB2YXIgcGF0aG5hbWUgPSB0cmFja1BhdGhuYW1lLnVwZGF0ZSh7XG4gICAgICAgICAgICBxdWVyeTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKF9hID0gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAnJztcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnZhbHVlO1xuICAgICAgICB2YXIgb25Qcm9maWxlVXJsID0gdHJhY2tPblByb2ZpbGVVcmwudXBkYXRlKHtcbiAgICAgICAgLy8gcHJlcmVxdWlzaXRlczogW3VybENoYW5nZWRdLCAvLyBUT0RPOiBzdXBwb3J0IGlucHV0IGFuZCBwcmVyZXF1aXN0ZXMgdG8gb3B0aW1pc2UuXG4gICAgICAgIH0pLnZhbHVlO1xuICAgICAgICB2YXIgb25GZWVkVXJsID0gdHJhY2tPbkZlZWRVcmwudXBkYXRlKHtcbiAgICAgICAgLy8gcHJlcmVxdWlzaXRlczogW3VybENoYW5nZWRdLFxuICAgICAgICB9KS52YWx1ZTtcbiAgICAgICAgdmFyIF9hID0gdHJhY2tPbk93blByb2ZpbGVPckZlZWQudXBkYXRlKHtcbiAgICAgICAgICAgIHRocm90dGxlOiAxMDAwLFxuICAgICAgICAgICAgLypvbjogKHZhbHVlOiBib29sZWFuKSA9PiB7IC8vIGNhbGxlZCB3aGVuIGNoYW5nZWQuXG4gICAgICAgICAgICAgICAgaWYgKCB2YWx1ZSApIHtcbiAgICAgICAgICAgICAgICAgICAgdmVyYm9zZShcIllvdSBhcmUgb24geW91ciBvd24gcHJvZmlsZS5cIik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdmVyYm9zZShcIllvdSBhcmUgbm90IG9uIHlvdXIgb3duIHBhZ2VcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSovXG4gICAgICAgIH0pLCBvbk93blBhZ2VPckZlZWQgPSBfYS52YWx1ZSwgb25Pd25QYWdlT3JGZWVkQ2hhbmdlZCA9IF9hLmRpcnR5O1xuICAgICAgICB0cmFja093blByb2ZpbGVOYW1lLnVwZGF0ZSh7XG4gICAgICAgICAgICB0aHJvdHRsZTogMjAwMCxcbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIGlmICghb25Qcm9maWxlVXJsICYmICFvbkZlZWRVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJOb3Qgb24gZmVlZCB1cmwgb3IgcHJvZmlsZSB1cmxcIik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAob25Qcm9maWxlVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoMCwgdXRpbHNfMS5nZXRVc2Vyc05hbWVPblByb2ZpbGUpKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoX2EgPSAoMCwgdXRpbHNfMS5nZXRVc2Vyc05hbWVPbkZlZWQpKCkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB2YXIgcHJvZmlsZVVzZXJJZCA9IHRyYWNrUHJvZmlsZVVzZXJJZC51cGRhdGUoe1xuICAgICAgICAgICAgLyogcHJlcmVxdWlzaXRlczogWyAvLyBPbmx5IHJ1biBpZiB3ZSBhcmUgb24gYSBwcm9maWxlIHVybCBvciBvbiB0aGUgZmVlZC5cbiAgICAgICAgICAgICAgICB0cmFja09uUHJvZmlsZVVybC5nZXQoKSB8fCB0cmFja09uRmVlZFVybC5nZXQoKSxcbiAgICAgICAgICAgIF0sKi9cbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFvblByb2ZpbGVVcmwgJiYgIW9uRmVlZFVybCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIk5vdCBvbiBmZWVkIHVybCBvciBwcm9maWxlIHVybFwiKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChvblByb2ZpbGVVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gKDAsIHV0aWxzXzEuZ2V0VXNlcklkSW5VcmwpKCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwicmVzb2x2ZWQgcHJvZmlsZSB1cmwgcHJvZmlsZSBuYW1lIDpcIiAgKyB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAob25GZWVkVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9ICgwLCB1dGlsc18xLmdldFVzZXJJZE9uUGFnZUZlZWQpKCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwicmVzb2x2ZWQgZmVlZCBwcm9maWxlIG5hbWUgOlwiICArIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnZhbHVlO1xuICAgICAgICAvLyBUaGlzIGlzIG9ic2VydmVkIGp1c3Qgb25jZS5cbiAgICAgICAgdHJhY2tPd25Qcm9maWxlVXNlcklkLnVwZGF0ZSh7XG4gICAgICAgICAgICBwcmVyZXF1aXNpdGVzOiBbXG4gICAgICAgICAgICAgICAgISFvbk93blBhZ2VPckZlZWQsXG4gICAgICAgICAgICAgICAgcHJvZmlsZVVzZXJJZCAhPT0gbnVsbCxcbiAgICAgICAgICAgICAgICB0cmFja093blByb2ZpbGVVc2VySWQuZ2V0KCkgPT09IG51bGwsXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnb3duUHJvZmlsZSB2YWx1ZSA6ICcgKyB0cmFja093blByb2ZpbGVVc2VySWQuZ2V0KCkpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdvd25Qcm9maWxlIG5ldyBWYWx1ZSA6ICcgKyBwcm9maWxlVXNlcklkKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJvZmlsZVVzZXJJZDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICAvLyB0aGlzIHRyYWNrcyBpZiB3ZSBsYW5kZWQgb24gdGhlIHVybCBvZiBhbm90aGVyIHVzZXIuXG4gICAgICAgIC8qdHJhY2tPdGhlclByb2ZpbGVVc2VySWQudXBkYXRlKHtcbiAgICAgICAgICAgIHRocm90dGxlOiAxMDAwLFxuICAgICAgICAgICAgcHJlcmVxdWlzaXRlczogW1xuICAgICAgICAgICAgICAgICFvbk93blBhZ2VPckZlZWQsXG4gICAgICAgICAgICAgICAgb25Qcm9maWxlVXJsID09PSB0cnVlLFxuICAgICAgICAgICAgICAgICEhcHJvZmlsZVVzZXJJZCxcbiAgICAgICAgICAgICAgICB0aW1lU2luY2VTdGFydCA+IDMwMDAsXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcXVlcnk6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoICEhZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImJ1dHRvblthcmlhLWxhYmVsPVxcXCJFZGl0IGludHJvXFxcIl1cIikgKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnb3RoZXJQcm9maWxlIG5ldyBWYWx1ZSA6ICcgKyBnZXRVc2VySWRJblVybCgpICk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGdldFVzZXJJZEluVXJsKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTsqL1xuICAgICAgICB2YXIgX2IgPSB0cmFja0hlYWRlci51cGRhdGUoe1xuICAgICAgICAgICAgdGhyb3R0bGU6IDIwMDAsXG4gICAgICAgICAgICAvLyByZXNldFRocm90dGxlOiBwcm9maWxlVXNlcklkQ2hhbmdlZCxcbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJjaGVja2luZyBoZWFkZXIgOiBcIiArIG9uUHJvZmlsZVVybCk7XG4gICAgICAgICAgICAgICAgaWYgKCFvblByb2ZpbGVVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhciBuZXdIZWFkZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiaDFcIik7XG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmVycm9yKFwiaGVhZGVyIDogXCIgKyBuZXdIZWFkZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXdIZWFkZXI7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY21wOiBmdW5jdGlvbiAoaGVhZGVyLCBuZXdIZWFkZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gISEoKCFoZWFkZXIgJiYgbmV3SGVhZGVyKSB8fFxuICAgICAgICAgICAgICAgICAgICAoaGVhZGVyICYmICFuZXdIZWFkZXIpIHx8XG4gICAgICAgICAgICAgICAgICAgIChoZWFkZXIgJiYgIWhlYWRlci5pc0VxdWFsTm9kZShuZXdIZWFkZXIpKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pLCBoZWFkZXIgPSBfYi52YWx1ZSwgaGVhZGVyQ2hhbmdlZCA9IF9iLmRpcnR5O1xuICAgICAgICAvLyB1cGRhdGUgd2hlbiB0aGUgc3RhdHVzIG9mIHRoZSBoZWFkZXIgaGFzIGNoYW5nZWQuXG4gICAgICAgIHRyYWNrUHJvZmlsZU5hbWUudXBkYXRlKHtcbiAgICAgICAgICAgIHByZXJlcXVpc2l0ZXM6IFtcbiAgICAgICAgICAgICAgICBoZWFkZXJDaGFuZ2VkXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgaWYgKCFoZWFkZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoX2EgPSAoMCwgdXRpbHNfMS5nZXRVc2Vyc05hbWVPblByb2ZpbGUpKCkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IG51bGw7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgdmFyIGJhY2tncm91bmRVcmwgPSB0cmFja0JhY2tncm91bmRVcmwudXBkYXRlKHtcbiAgICAgICAgICAgIHRocm90dGxlOiAxMDAwLFxuICAgICAgICAgICAgcmVzZXRUaHJvdHRsZTogaGVhZGVyQ2hhbmdlZCxcbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIGlmICh0cmFja09uRmVlZFVybC5nZXQoKSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZWwgPSBxcyhcImRpdi5mZWVkLWlkZW50aXR5LW1vZHVsZV9fbWVtYmVyLWJnLWltYWdlXCIpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgdXJsXzEgPSBlbCA/IFswXS5yZWR1Y2UoZnVuY3Rpb24gKGFjYykgeyByZXR1cm4gYWNjID09PSBudWxsIHx8IGFjYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYWNjLnNsaWNlKDAsIGFjYy5sZW5ndGggLSAyKTsgfSwgZWwgPT09IG51bGwgfHwgZWwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVsLnN0eWxlLmJhY2tncm91bmRJbWFnZS5yZXBsYWNlKFwidXJsKFxcXCJcIiwgXCJcIikpIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVybF8xO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0cmFja09uUHJvZmlsZVVybC5nZXQoKSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZWwgPSBxcyhcIiNwcm9maWxlLWJhY2tncm91bmQtaW1hZ2UtdGFyZ2V0LWltYWdlXCIpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWVsICYmIHFzKCdkaXYucHJvZmlsZS1iYWNrZ3JvdW5kLWltYWdlLS1kZWZhdWx0JykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnZGVmYXVsdCc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmFyIHVybF8yID0gKF9hID0gZWwgPT09IG51bGwgfHwgZWwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVsLnNyYykgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVybF8yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnZhbHVlO1xuICAgICAgICB2YXIgcHJvZmlsZVBpY3R1cmVVcmwgPSB0cmFja1Byb2ZpbGVQaWN0dXJlVXJsLnVwZGF0ZSh7XG4gICAgICAgICAgICB0aHJvdHRsZTogMTAwMCxcbiAgICAgICAgICAgIHJlc2V0VGhyb3R0bGU6IGhlYWRlckNoYW5nZWQsXG4gICAgICAgICAgICBxdWVyeTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgICAgICAgICAgaWYgKCFvblByb2ZpbGVVcmwgJiYgIW9uRmVlZFVybCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG9uUHJvZmlsZVVybCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgaW1hZ2VzID0gcXNhKFwiaW1nLnB2LXRvcC1jYXJkLXByb2ZpbGUtcGljdHVyZV9faW1hZ2UsIGltZy5wcm9maWxlLXBob3RvLWVkaXRfX3ByZXZpZXdcIik7XG4gICAgICAgICAgICAgICAgICAgIC8vIHZlcmJvc2UoXCJQcm9maWxlIGltYWdlIHVybFwiLCBpbWFnZXMpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW1hZ2VzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcm9maWxlSW1hZ2VVcmwgPSAoX2EgPSBpbWFnZXNbMF0pID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zcmM7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvZmlsZUltYWdlVXJsID09PSAnaHR0cHM6Ly9zdGF0aWMubGljZG4uY29tL3NjL2gvMTNtNGRxOWMzMXMxc2w3cDdoODJnaDF2aCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlKGltYWdlc1swXSkuYmFja2dyb3VuZEltYWdlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1cmxfMyA9IGltYWdlc1swXSA/IFswXS5yZWR1Y2UoZnVuY3Rpb24gKGFjYykgeyByZXR1cm4gYWNjID09PSBudWxsIHx8IGFjYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYWNjLnNsaWNlKDAsIGFjYy5sZW5ndGggLSAyKTsgfSwgZ2V0Q29tcHV0ZWRTdHlsZShpbWFnZXNbMF0pLmJhY2tncm91bmRJbWFnZS5yZXBsYWNlKFwidXJsKFxcXCJcIiwgXCJcIikpIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdXJsXzM7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcHJvZmlsZUltYWdlVXJsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVkaXRQaG90byA9IHFzKCcucHJvZmlsZS1waG90by1lZGl0Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZWRpdFBob3RvKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdkZWZhdWx0JztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG9uRmVlZFVybCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc21hbGxQcm9maWxlSW1hZ2VVcmwgPSBxcyhcImltZy5mZWVkLWlkZW50aXR5LW1vZHVsZV9fbWVtYmVyLXBob3RvXCIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKF9iID0gc21hbGxQcm9maWxlSW1hZ2VVcmwgPT09IG51bGwgfHwgc21hbGxQcm9maWxlSW1hZ2VVcmwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNtYWxsUHJvZmlsZUltYWdlVXJsLnNyYykgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KS52YWx1ZTtcbiAgICAgICAgdHJhY2tPbk93bkZlZWQudXBkYXRlKHtcbiAgICAgICAgICAgIHRocm90dGxlOiAxMDAwLFxuICAgICAgICAgICAgcmVzZXRUaHJvdHRsZTogaGVhZGVyQ2hhbmdlZCxcbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgLypjb25zb2xlLmxvZyh7XG4gICAgICAgICAgICAgICAgICAgIG9uT3duUGFnZU9yRmVlZCxcbiAgICAgICAgICAgICAgICAgICAgdHJhY2tPbkZlZWRVcmw6IHRyYWNrT25GZWVkVXJsLmdldCgpLFxuICAgICAgICAgICAgICAgICAgICBlbDogcXMoXCJkaXYuZmVlZC1pZGVudGl0eS1tb2R1bGVfX21lbWJlci1iZy1pbWFnZVwiKSxcbiAgICAgICAgICAgICAgICB9KTsqL1xuICAgICAgICAgICAgICAgIGlmICghb25Pd25QYWdlT3JGZWVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCF0cmFja09uRmVlZFVybC5nZXQoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChxcyhcImRpdi5mZWVkLWlkZW50aXR5LW1vZHVsZV9fbWVtYmVyLWJnLWltYWdlXCIpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgLyogY29uc3Qge3ZhbHVlOiBvbk93blBhZ2V9ID0gKi8gdHJhY2tPbk93blBhZ2UudXBkYXRlKHtcbiAgICAgICAgICAgIHRocm90dGxlOiAxMDAwLFxuICAgICAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW9uT3duUGFnZU9yRmVlZCB8fCAhb25Qcm9maWxlVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFyIGVsID0gcXMoXCIjcHJvZmlsZS1iYWNrZ3JvdW5kLWltYWdlLXRhcmdldC1pbWFnZVwiKTtcbiAgICAgICAgICAgICAgICB2YXIgYmFja2dyb3VuZEltZyA9IG9uUHJvZmlsZVVybCA/IGVsIDogcXMoJ2Rpdi5wcm9maWxlLWJhY2tncm91bmQtaW1hZ2UtLWRlZmF1bHQnKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb25Qcm9maWxlVXJsICYmICEhYmFja2dyb3VuZEltZztcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBTZXQgdGhlIHN0YXR1cyB3ZWF0aGVyIHdlIHNob3VsZCBiZSB1cGRhdGluZyB2ZXJpZmljYXRpb24uIFRoaXMgY2FuIGJlIHVzZWQgdG8gdHJpZ2dlciBhIHZlcmlmaWNhdGlvblxuICAgICAgICB0cmFja1ZlcmlmeVN0YXR1cy51cGRhdGUoe1xuICAgICAgICAgICAgLy8gdGhyb3R0bGU6IDI1MCxcbiAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RyYWNrVmVyaWZ5U3RhdHVzIDogJyArIGJhY2tncm91bmRVcmwpO1xuICAgICAgICAgICAgICAgIHZhciByZXQgPSAob25Qcm9maWxlVXJsIHx8IG9uRmVlZFVybCkgJiZcbiAgICAgICAgICAgICAgICAgICAgKChvblByb2ZpbGVVcmwgJiYgISFoZWFkZXIpIHx8IG9uRmVlZFVybCkgJiZcbiAgICAgICAgICAgICAgICAgICAgKChvblByb2ZpbGVVcmwgJiYgISFzaGllbGQpIHx8IG9uRmVlZFVybCkgJiZcbiAgICAgICAgICAgICAgICAgICAgISFiYWNrZ3JvdW5kVXJsICYmXG4gICAgICAgICAgICAgICAgICAgICEhcHJvZmlsZVBpY3R1cmVVcmwgJiZcbiAgICAgICAgICAgICAgICAgICAgISFwcm9maWxlVXNlcklkID9cbiAgICAgICAgICAgICAgICAgICAgdXJsICsgYmFja2dyb3VuZFVybCArIHByb2ZpbGVQaWN0dXJlVXJsICsgcHJvZmlsZVVzZXJJZCA6IG51bGw7XG4gICAgICAgICAgICAgICAgLyogY29uc29sZS5sb2coJ3RyYWNrVmVyaWZ5U3RhdHVzIDogJywge1xuICAgICAgICAgICAgICAgICAgICBcIihvblByb2ZpbGVVcmwgfHwgb25GZWVkVXJsKVwiOiAob25Qcm9maWxlVXJsIHx8IG9uRmVlZFVybCksXG4gICAgICAgICAgICAgICAgICAgICcoKG9uUHJvZmlsZVVybCAmJiAhIWhlYWRlcikgfHwgb25GZWVkVXJsKSc6ICgob25Qcm9maWxlVXJsICYmICEhaGVhZGVyKSB8fCBvbkZlZWRVcmwpLFxuICAgICAgICAgICAgICAgICAgICAnKChvblByb2ZpbGVVcmwgJiYgISFzaGllbGQpIHx8IG9uRmVlZFVybCknOigob25Qcm9maWxlVXJsICYmICEhc2hpZWxkKSB8fCBvbkZlZWRVcmwpLFxuICAgICAgICAgICAgICAgICAgICBcIiEhYmFja2dyb3VuZFVybFwiOiBiYWNrZ3JvdW5kVXJsLFxuICAgICAgICAgICAgICAgICAgICBcIiEhcHJvZmlsZVBpY3R1cmVVcmxcIjogcHJvZmlsZVBpY3R1cmVVcmwsXG4gICAgICAgICAgICAgICAgICAgIFwiISFwcm9maWxlVXNlcklkXCI6IHByb2ZpbGVVc2VySWQsXG4gICAgICAgICAgICAgICAgICAgIHJldFxuICAgICAgICAgICAgICAgIH0pO1x0Ki9cbiAgICAgICAgICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfTtcbn07XG52YXIgc2xlZXAgPSBmdW5jdGlvbiAoZHQpIHtcbiAgICBpZiAoZHQgPT09IHZvaWQgMCkgeyBkdCA9IDEwMDA7IH1cbiAgICByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmV0dXJuIHNldFRpbWVvdXQocmVzb2x2ZSwgZHQpOyB9KV07XG4gICAgfSk7IH0pO1xufTtcbnZhciBjaGFuZ2VCYWNrZ3JvdW5kVG91ciA9IHtcbiAgICBvblRvdXJTdGFydDogZnVuY3Rpb24gKHRvdXIpIHtcbiAgICAgICAgdG91ci5iYWNrZ3JvdW5kID0gKDAsIHRvdXJfMS5jcmVhdGVUb3VyV2lkZ2V0KSgpO1xuICAgICAgICB0b3VyLmJhY2tncm91bmQuc2hvdygpO1xuICAgIH0sXG4gICAgb25Ub3VyRG9uZTogZnVuY3Rpb24gKHRvdXIpIHtcbiAgICAgICAgdG91ci5iYWNrZ3JvdW5kLmhpZGUoKTtcbiAgICB9LFxuICAgIG9uVG91ckVycm9yOiBmdW5jdGlvbiAodG91cikge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIChfYSA9IHRvdXIgPT09IG51bGwgfHwgdG91ciA9PT0gdm9pZCAwID8gdm9pZCAwIDogdG91ci5sb2FkaW5nUG9wdXApID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5kZXN0cm95KCk7XG4gICAgfSxcbiAgICBvblRvdXJDYW5jZWw6IGZ1bmN0aW9uICh0b3VyKSB7XG4gICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgIHZhciB1ID0gKF9iID0gKF9hID0gKDAsIHV0aWxzXzEuZ2V0VXNlcklkSW5VcmwpKCkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICgwLCB1dGlsc18xLmdldFVzZXJJZE9uUGFnZUZlZWQpKCkpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICcnO1xuICAgICAgICBpZiAodSkge1xuICAgICAgICAgICAgdXRpbHNfMS5yZWdpc3RyYXRpb25zLnNldFJlZ1N0ZXAocm9vdF8xLm15c29tZS5wbGF0Zm9ybSwgdSwgNikudGhlbigpLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignTm8gdXNlciBpZCB3aGlsZSBjYW5jZWxsaW5nIHRvdXIgLSBjb3VsZCBub3QgY2hhbmdlIHRoZSBzdGF0dXMgb2YgdGhlIHJlZ2lzdHJhdGlvbi4nKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgc3RlcHM6IFtcbiAgICAgICAge1xuICAgICAgICAgICAgYWN0aXZhdGU6IGZ1bmN0aW9uICh0b3VyKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBjb250ZXh0O1xuICAgICAgICAgICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYykge1xuICAgICAgICAgICAgICAgICAgICBjb250ZXh0ID0gKDAsIHBvcHVwXzEuc2hvd0ZpbmFsaXplUG9wdXApKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHU6IChfYiA9IChfYSA9ICgwLCB1dGlsc18xLmdldFVzZXJJZEluVXJsKSgpKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAoMCwgdXRpbHNfMS5nZXRVc2VySWRPblBhZ2VGZWVkKSgpKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHA6IHJvb3RfMS5teXNvbWUucGxhdGZvcm0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBjb250ZXh0Lm9uUmVzdWx0ID0gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2ID09PSAnY2FuY2VsJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdXIuY2FuY2VsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh2ID09PSAnY29udGludWUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG91ci5sb2FkaW5nUG9wdXAgPSAoMCwgcG9wdXBfMS5zaG93TG9hZGluZ1BvcHVwKSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdDaGFuZ2luZyB5b3VyIGJhY2tncm91bmQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiZ0NvbG9yOiAnIzAwMDAwMEZGJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdXIubmV4dFN0ZXAoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7IH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIGFjdGl2YXRlOiBmdW5jdGlvbiAodG91cikgeyByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICB2YXIgdXNlcklkLCBsb2MsIG9uUHJvZmlsZSwgb25GZWVkLCBtYXhfMSwgYSwgbWF4LCByZWcsIGVkaXRCZ0J1dHRvbiwgX2EsIGJsb2IsIGltYWdlVHlwZSwgZmlsZSwgY29udGFpbmVyLCBjaGFuZ2VCYWNrZ3JvdW5kRm91bmQsIGFkZEJhY2tncm91bmRWaWV3Rm91bmQsIGVkaXRQcm9maWxlQmFja2dyb3VuZEJ1dHRvbiwgbWF4LCBpbnB1dCwgbWF4LCBpbnB1dCwgbm90Rm5kLCBhcHBseUJ1dHRvbiwgY250O1xuICAgICAgICAgICAgICAgIHZhciBfYiwgX2MsIF9lLCBfZiwgX2csIF9oLCBfaiwgX2ssIF9sLCBfbSwgX28sIF9wLCBfcSwgX3IsIF9zO1xuICAgICAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX3QpIHtcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChfdC5sYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJZCA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcklkID0gKDAsIHV0aWxzXzEuZ2V0VXNlcklkSW5VcmwpKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jID0gd2luZG93LmxvY2F0aW9uLmhyZWYudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblByb2ZpbGUgPSBsb2MuaW5kZXhPZignL2luLycgKyB1c2VySWQgKyAnLycpID49IDAgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXMoJy5wcm9maWxlLXRvcGNhcmQtYmFja2dyb3VuZC1pbWFnZS1lZGl0X19pY29uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEhb25Qcm9maWxlKSByZXR1cm4gWzMgLypicmVhayovLCA3XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyAyYScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRmVlZCA9IGxvYy5pbmRleE9mKCcvZmVlZC8nKSA+PSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghIW9uRmVlZCkgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKF9iID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImEuYXBwLWF3YXJlLWxpbmtcIikpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jbGljaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heF8xID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdC5sYWJlbCA9IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEhZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5mZWVkLWlkZW50aXR5LW1vZHVsZVwiKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1heF8xKysgPiA0ICogNjApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdUaW1lZCBvdXQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc2xlZXAoMjUwKV07XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Quc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDJiJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYSA9IChfYyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZmVlZC1pZGVudGl0eS1tb2R1bGVcIikpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5xdWVyeVNlbGVjdG9yKCdhJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYSA9PT0gbnVsbCB8fCBhID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhLmNsaWNrKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJyMgMmMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRmVlZCBwcm9maWxlIGxpbmsgbm90IGZvdW5kLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDJkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3QubGFiZWwgPSA0O1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucHJvZmlsZS10b3BjYXJkLWJhY2tncm91bmQtaW1hZ2UtZWRpdFwiKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgNl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1heCsrID4gNCAqIDYwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGltZWQgb3V0Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNsZWVwKDI1MCldO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA1OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90LnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCA0XTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyAyZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90LmxhYmVsID0gNztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyAyZicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJJZCA9ICgwLCB1dGlsc18xLmdldFVzZXJJZEluVXJsKSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdXNlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDJnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdXIuZW5kV2l0aEVycm9yKCdGYWlsZWQgY2hhbmdpbmcgYmFja2dyb3VuZCAoMSknLCAnUGxlYXNlIHRyeSBhZ2FpbiBsYXRlciBvciBjaGFuZ2UgdGhlIGJhY2tncm91bmQgbWFudWFsbHkuJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVnID0gdXRpbHNfMS5yZWdpc3RyYXRpb25zLnNlbGVjdChyb290XzEubXlzb21lLnBsYXRmb3JtLCB1c2VySWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDJnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZWcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG91ci5lbmRXaXRoRXJyb3IoJ0ZhaWxlZCBjaGFuZ2luZyBiYWNrZ3JvdW5kICgyKScsICdQbGVhc2UgdHJ5IGFnYWluIGxhdGVyIG9yIGNoYW5nZSB0aGUgYmFja2dyb3VuZCBtYW51YWxseS4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyAzJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdEJnQnV0dG9uID0gKF9lID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5wcm9maWxlLXRvcGNhcmQtYmFja2dyb3VuZC1pbWFnZS1lZGl0XCIpKSA9PT0gbnVsbCB8fCBfZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2UucXVlcnlTZWxlY3RvcihcImJ1dHRvblwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcIi5wcm9maWxlLXRvcGNhcmQtYmFja2dyb3VuZC1pbWFnZS1lZGl0XCIpPy5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcImJ1dHRvblwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWVkaXRCZ0J1dHRvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3VyLmVuZFdpdGhFcnJvcignRmFpbGVkIGNoYW5naW5nIGJhY2tncm91bmQgKDMpJywgJ1BsZWFzZSB0cnkgYWdhaW4gbGF0ZXIgb3IgY2hhbmdlIHRoZSBiYWNrZ3JvdW5kIG1hbnVhbGx5LicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRCZ0J1dHRvbiA9PT0gbnVsbCB8fCBlZGl0QmdCdXR0b24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVkaXRCZ0J1dHRvbi5jbGljaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEdpdmUgaXQgc29tZSB0aW1lIHRvIHJlbmRlci5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBzbGVlcCgyNTApXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgODpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBHaXZlIGl0IHNvbWUgdGltZSB0byByZW5kZXIuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Quc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDQgLSBmZXRjaGluZyBzdG9yZWQgYmFja2dyb3VuZCBpbWFnZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9hID0gKDAsIHV0aWxzXzEuYmFzZTY0VG9CbG9iKShyZWcuaW1hZ2UpLCBibG9iID0gX2EuYmxvYiwgaW1hZ2VUeXBlID0gX2EuaW1hZ2VUeXBlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGUgPSBuZXcgRmlsZShbYmxvYl0sICdpbWFnZS5wbmcnLCB7IHR5cGU6IGltYWdlVHlwZSAhPT0gbnVsbCAmJiBpbWFnZVR5cGUgIT09IHZvaWQgMCA/IGltYWdlVHlwZSA6ICdpbWFnZS9wbmcnLCBsYXN0TW9kaWZpZWQ6IG5ldyBEYXRlKCkuZ2V0VGltZSgpIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lciA9IG5ldyBEYXRhVHJhbnNmZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXIuaXRlbXMuYWRkKGZpbGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYW5nZUJhY2tncm91bmRGb3VuZCA9IChfaCA9IChfZyA9IChfZiA9IHFzYShcImRpdlwiKS5maW5kKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4LmlubmVyVGV4dCA9PT0gJ0JhY2tncm91bmQgcGhvdG8nOyB9KSkgPT09IG51bGwgfHwgX2YgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9mLnBhcmVudEVsZW1lbnQpID09PSBudWxsIHx8IF9nID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZy5wYXJlbnRFbGVtZW50KSA9PT0gbnVsbCB8fCBfaCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2gucXNhKFwibGFiZWxcIikuZmluZChmdW5jdGlvbiAoeCkgeyByZXR1cm4geC5pbm5lclRleHQgPT09IFwiQ2hhbmdlIHBob3RvXCI7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZEJhY2tncm91bmRWaWV3Rm91bmQgPSBxc2EoXCJoMlwiKS5maW5kKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4LmlubmVyVGV4dC50cmltKCkgPT09ICdBZGQgYmFja2dyb3VuZCBwaG90byc7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRQcm9maWxlQmFja2dyb3VuZEJ1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1thcmlhLWxhYmVsPVwiRWRpdCBwcm9maWxlIGJhY2tncm91bmRcIl0nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYW5nZUJhY2tncm91bmRGb3VuZDogY2hhbmdlQmFja2dyb3VuZEZvdW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRCYWNrZ3JvdW5kVmlld0ZvdW5kOiBhZGRCYWNrZ3JvdW5kVmlld0ZvdW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0UHJvZmlsZUJhY2tncm91bmRCdXR0b246IGVkaXRQcm9maWxlQmFja2dyb3VuZEJ1dHRvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoISghY2hhbmdlQmFja2dyb3VuZEZvdW5kICYmIGFkZEJhY2tncm91bmRWaWV3Rm91bmQgJiYgZWRpdFByb2ZpbGVCYWNrZ3JvdW5kQnV0dG9uKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMTNdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDVhIC0gV2UgaGF2ZSBub3QgcHJldmlvdXNseSBhZGRlZCBhIGJhY2tncm91bmQgcGljdHVyZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc2xlZXAoMTAwMCldO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSA5OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90LnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwcm9maWxlLXRvcGNhcmQtYmFja2dyb3VuZC1pbWFnZV9maWxlLXVwbG9hZC1pbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDZhIC0gTG9jYXRpbmcgaW5wdXQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dCA9IChfayA9IChfaiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W2FyaWEtbGFiZWw9XCJFZGl0IHByb2ZpbGUgYmFja2dyb3VuZFwiXScpKSAhPT0gbnVsbCAmJiBfaiAhPT0gdm9pZCAwID8gX2ogOiBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaW5wdXRcIikpLmZpbmQoZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHguYWNjZXB0ID09PSAnaW1hZ2UvKic7IH0pKSAhPT0gbnVsbCAmJiBfayAhPT0gdm9pZCAwID8gX2sgOiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbnB1dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyA2YSAtIGRpc3BhdGNoaW5nIGNoYW5nZSBldmVudC4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXQuZmlsZXMgPSBjb250YWluZXIuZmlsZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KCdjaGFuZ2UnKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gbG9jYXRlIGVsZW1lbnQgdG8gYWRkIHRoZSBpbWFnZSB0by4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3QubGFiZWwgPSAxMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEhZG9jdW1lbnQucXVlcnlTZWxlY3RvcignZm9vdGVyLmltYWdlLWVkaXQtdG9vbC1mb290ZXInKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMTJdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDdhJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgc2xlZXAoMTAwMCldO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxMTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdC5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1heCsrID4gMzApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG91ci5lbmRXaXRoRXJyb3IoJ0ZhaWxlZCBjaGFuZ2luZyBiYWNrZ3JvdW5kICg0KScsICdQbGVhc2UgdHJ5IGFnYWluIGxhdGVyIG9yIGNoYW5nZSB0aGUgYmFja2dyb3VuZCBtYW51YWxseS4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCAxMF07XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDEyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDhhJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMTddO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxMzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyA1YiAtIFdlIGhhdmUgcHJldmlvdXNseSBzZXQgYSBiYWNrZ3JvdW5kIGltYWdlLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3QubGFiZWwgPSAxNDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEhZG9jdW1lbnQucXVlcnlTZWxlY3RvcignZm9vdGVyLmltYWdlLWVkaXQtdG9vbC1mb290ZXInKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMTZdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtYXgrKyA+IDQgKiA2MCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3VyLmVuZFdpdGhFcnJvcignRmFpbGVkIGNoYW5naW5nIGJhY2tncm91bmQgKDQpJywgJ1BsZWFzZSB0cnkgYWdhaW4gbGF0ZXIgb3IgY2hhbmdlIHRoZSBiYWNrZ3JvdW5kIG1hbnVhbGx5LicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNsZWVwKDI1MCldO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxNTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdC5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMTRdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAxNjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnIyA2YiAtIGZpbmQgdGhlIGlucHV0IGZpZWxkLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0ID0gKF9wID0gKF9vID0gKF9tID0gKF9sID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmFydGRlY28tbW9kYWwnKSkgPT09IG51bGwgfHwgX2wgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9sLnF1ZXJ5U2VsZWN0b3IoJ2lucHV0LnZpc3VhbGx5LWhpZGRlbicpKSAhPT0gbnVsbCAmJiBfbSAhPT0gdm9pZCAwID8gX20gOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiaW5wdXQjYmFja2dyb3VuZC1pbWFnZS1jcm9wcGVyX19maWxlLXVwbG9hZC1pbnB1dC5oaWRkZW5cIikpICE9PSBudWxsICYmIF9vICE9PSB2b2lkIDAgPyBfbyA6IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2lucHV0JykpLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4geC5hY2NlcHQgPT09ICdpbWFnZS8qJzsgfSlbMF0pICE9PSBudWxsICYmIF9wICE9PSB2b2lkIDAgPyBfcCA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCIjIDZiIC0gQmFja2dyb3VuZCBwaWN0dXJlIGlucHV0XCIsIGlucHV0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlucHV0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdXIuZW5kV2l0aEVycm9yKCdGYWlsZWQgY2hhbmdpbmcgYmFja2dyb3VuZCAoNSknLCAnUGxlYXNlIHRyeSBhZ2FpbiBsYXRlciBvciBjaGFuZ2UgdGhlIGJhY2tncm91bmQgbWFudWFsbHkuJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJyMgN2InKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dC5maWxlcyA9IGNvbnRhaW5lci5maWxlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudCgnY2hhbmdlJykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQmFja2dyb3VuZCBpbWFnZSBjaGFuZ2VkXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90LmxhYmVsID0gMTc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDE3OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcjIDggLSBBcHBseScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNsZWVwKDEyNTApXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTg6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Quc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZuZCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3QubGFiZWwgPSAxOTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTk6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdmb290ZXIuaW1hZ2UtZWRpdC10b29sLWZvb3RlcicpKSByZXR1cm4gWzMgLypicmVhayovLCAyNl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0dldHRpbmcgQXBwbHkgQnV0dG9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwbHlCdXR0b24gPSAoX3MgPSAoX3IgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbCgoX3EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdmb290ZXIuaW1hZ2UtZWRpdC10b29sLWZvb3RlcicpKSA9PT0gbnVsbCB8fCBfcSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3EucXVlcnlTZWxlY3RvckFsbCgnc3BhbicpKSkgPT09IG51bGwgfHwgX3IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9yLmZpbHRlcihmdW5jdGlvbiAoeCkgeyB2YXIgX2E7IHJldHVybiAoKF9hID0geC5pbm5lclRleHQpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbmRleE9mKCdBcHBseScpKSA+PSAwOyB9KVswXSkgPT09IG51bGwgfHwgX3MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9zLnBhcmVudEVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0FwcGx5IEJ1dHRvbiByZXNvbHZlZCA6ICcgKyAoISFhcHBseUJ1dHRvbiA/ICdZZXMnIDogJ05vJykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghIWFwcGx5QnV0dG9uKSByZXR1cm4gWzMgLypicmVhayovLCAyMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkFwcGx5IGJ1dHRvbiBub3QgZm91bmQuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNsZWVwKDEwMDApXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Quc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChub3RGbmQrKyA+IDEwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmluZCBBcHBseSBidXR0b25cIik7IC8vIFRPRE86IFNob3cgZXJyb3IgbWVzc2FnZSB0byB1c2VyLlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3VyLmVuZFdpdGhFcnJvcignRmFpbGVkIHRvIGNoYW5nZSBiYWNrZ3JvdW5kJywgJ1BsZWFzZSB0cnkgc2V0dGluZyB0aGUgYmFja2dyb3VuZCBtYW51YWxseScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJldHJ5aW5nIGZpbmRpbmcgQXBwbHkgQnV0dG9uXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzMgLypicmVhayovLCAxOV07XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDIxOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghYXBwbHlCdXR0b24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIC0gY2Fubm90IGZpbmQgYXBwbHkgYnV0dG9uLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDbGlja2luZyBBcHBseSBidXR0b25cIiwgYXBwbHlCdXR0b24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGx5QnV0dG9uID09PSBudWxsIHx8IGFwcGx5QnV0dG9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhcHBseUJ1dHRvbi5jbGljaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2xpY2tlZCB0aGUgYXBwbHkgYnV0dG9uXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90LmxhYmVsID0gMjI7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDIyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3QubGFiZWwgPSAyMztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjM6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignZm9vdGVyLmltYWdlLWVkaXQtdG9vbC1mb290ZXInKSAmJiBjbnQrKyA8IDMwKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMjVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiV2FpdGluZyBmb3IgYXBwbHkgdG8gZGlzYXBwZWFyXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHNsZWVwKDEwMDApXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3Quc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDIzXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjU6IHJldHVybiBbMyAvKmJyZWFrKi8sIDE5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMjY6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJyMgMTAnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3VyID09PSBudWxsIHx8IHRvdXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRvdXIubmV4dFN0ZXAoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pOyB9LFxuICAgICAgICAgICAgb25BY3RpdmF0ZUV4Y2VwdGlvbjogZnVuY3Rpb24gKHRvdXIpIHtcbiAgICAgICAgICAgICAgICB0b3VyID09PSBudWxsIHx8IHRvdXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRvdXIuZW5kV2l0aEVycm9yKCdGYWlsZWQgdG8gY2hhbmdlIGJhY2tncm91bmQnLCAnUGxlYXNlIHRyeSBzZXR0aW5nIHRoZSBiYWNrZ3JvdW5kIG1hbnVhbGx5Jyk7XG4gICAgICAgICAgICAgICAgdG91ciA9PT0gbnVsbCB8fCB0b3VyID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0b3VyLm5leHRTdGVwKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBhY3RpdmF0ZTogZnVuY3Rpb24gKHRvdXIpIHsgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIHUsIGFyZ3MsIGNvbnRleHQ7XG4gICAgICAgICAgICAgICAgdmFyIF9hLCBfYiwgX2M7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfZSkge1xuICAgICAgICAgICAgICAgICAgICB1ID0gKF9iID0gKF9hID0gKDAsIHV0aWxzXzEuZ2V0VXNlcklkSW5VcmwpKCkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICgwLCB1dGlsc18xLmdldFVzZXJJZE9uUGFnZUZlZWQpKCkpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICcnO1xuICAgICAgICAgICAgICAgICAgICBhcmdzID0gKDAsIHV0aWxzXzEub2JqVG9VcmxQYXJtcykoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdTogdSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHA6IHJvb3RfMS5teXNvbWUucGxhdGZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogZW5jb2RlVVJJQ29tcG9uZW50KCdSZWdpc3RyYXRpb24gRG9uZScpLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZW5jb2RlVVJJQ29tcG9uZW50KCdZb3VyIHByb2ZpbGUgaXMgdmVyaWZpZWQuJyksXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5OiAnT0snLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2Vjb25kYXJ5OiAnJyxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIChfYyA9IHRvdXIgPT09IG51bGwgfHwgdG91ciA9PT0gdm9pZCAwID8gdm9pZCAwIDogdG91ci5sb2FkaW5nUG9wdXApID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYy5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQgPSByb290XzEubXlzb21lLmNyZWF0ZVBvcHVwKFwid2lkZ2V0L2luZGV4Lmh0bWxcIiwgXCIjL21lc3NhZ2U/XCIuY29uY2F0KGFyZ3MpLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbG9zZU9uQmdDbGljazogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBiZ0NvbG9yOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dC5vblJlc3VsdCA9IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTdG9yZSB0aGUgbmV4dCBzdGVwLlxuICAgICAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5yZWdpc3RyYXRpb25zLnNldFJlZ1N0ZXAocm9vdF8xLm15c29tZS5wbGF0Zm9ybSwgdSwgNikudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG91ci5kb25lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KS5jYXRjaChmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdXIuZW5kV2l0aEVycm9yKCdGYWlsZWQgdXBkYXRpbmcgcmVnaXN0cmF0aW9uJywgJ1BsZWFzZSByZXRyeSB1cGxvYWRpbmcgYmFja2dyb3VuZC4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTsgfSxcbiAgICAgICAgfSxcbiAgICBdXG59O1xuZnVuY3Rpb24gc2hvd05vdFZlcmlmaWVkUG9wdXAoKSB7XG4gICAgKDAsIHBvcHVwXzEuc2hvd01lc3NhZ2VQb3B1cCkoe1xuICAgICAgICB0aXRsZTogJ1lvdXIgTGlua2VkSW4gcHJvZmlsZSBpcyBub3QgdmVyaWZpZWQnLFxuICAgICAgICBtZXNzYWdlOiAnU2VjdXJlIHlvdXIgYWNjb3VudCBub3cgYnkgc2VsZi1pc3N1aW5nIGEgY2VydGlmaWNhdGUgdG8gcHJvdmUgeW91ciBhY2NvdW50IG93bmVyc2hpcC48YnIvPjxici8+VGhlIGNlcnRpZmljYXRlIGNvbnRhaW5zIGEgY3J5cHRvZ3JhcGhpYyBwcm9vZiB1c2VkIHRvIGxldCBvdGhlciBrbm93IHRoYXQgeW91IGFyZSB3aG8geW91IGNsYWltIHRvIGJlIHRvIHByZXZlbnQgcmlza3Mgb2YgaWRlbnRpdHkgdGhlZnQgYW5kIGZyYXVkLicsXG4gICAgICAgIHByaW1hcnk6ICdTRUNVUkUgUFJPRklMRScsXG4gICAgICAgIHNlY29uZGFyeTogJ0NBTkNFTCcsXG4gICAgICAgIHByaW1hcnlfbGluazogZ2V0Q3JlYXRlTGluaygpLFxuICAgIH0pO1xuICAgIHV0aWxzXzEuc3RvcmFnZS5zZXQoXCJjb250ZW50LXdlbGNvbWUtc2hvd25cIiwgdHJ1ZSkudGhlbihmdW5jdGlvbiAoKSB7IH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xufVxudmFyIHZhbGlkYXRlUHJvb2ZXaXRoUHJvZmlsZSA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBmaXJzdE5hbWUgPSBfYS5maXJzdE5hbWUsIGxhc3ROYW1lID0gX2EubGFzdE5hbWUsIHByb29mVXJsID0gX2EucHJvb2ZVcmwsIHVzZXJEYXRhID0gX2EudXNlckRhdGEsIHBsYXRmb3JtID0gX2EucGxhdGZvcm07XG4gICAgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBiYXNlLCB1cmw7XG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcbiAgICAgICAgICAgIGJhc2UgPSBTRVJWSUNFX0JBU0VfVVJMKCk7XG4gICAgICAgICAgICBwcm9vZlVybCA9IGVuY29kZVVSSUNvbXBvbmVudChwcm9vZlVybCk7XG4gICAgICAgICAgICBmaXJzdE5hbWUgPSBlbmNvZGVVUklDb21wb25lbnQoZmlyc3ROYW1lKTtcbiAgICAgICAgICAgIGxhc3ROYW1lID0gZW5jb2RlVVJJQ29tcG9uZW50KGxhc3ROYW1lKTtcbiAgICAgICAgICAgIHVzZXJEYXRhID0gZW5jb2RlVVJJQ29tcG9uZW50KHVzZXJEYXRhKTtcbiAgICAgICAgICAgIHVybCA9IFwiXCIuY29uY2F0KGJhc2UsIFwiL3Byb29mL3ZhbGlkYXRlLXByb29mLXVybD91cmw9XCIpLmNvbmNhdChwcm9vZlVybCwgXCImZmlyc3ROYW1lPVwiKS5jb25jYXQoZmlyc3ROYW1lLCBcIiZsYXN0TmFtZT1cIikuY29uY2F0KGxhc3ROYW1lLCBcIiZwbGF0Zm9ybT1cIikuY29uY2F0KHBsYXRmb3JtLCBcIiZ1c2VyRGF0YT1cIikuY29uY2F0KHVzZXJEYXRhKTtcbiAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCBmZXRjaCh1cmwpLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzLmpzb24oKTtcbiAgICAgICAgICAgICAgICB9KS50aGVuKGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iaiAhPT0gbnVsbCAmJiBvYmogIT09IHZvaWQgMCA/IG9iaiA6IHsgc3RhdHVzOiBudWxsIH07XG4gICAgICAgICAgICAgICAgfSldO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG52YXIgZ2V0Q3JlYXRlTGluayA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdGVtcGxhdGUgPSAndGVtcGxhdGU9JyArIGVuY29kZVVSSUNvbXBvbmVudCgoMCwgdXRpbHNfMS51dGY4X3RvX2I2NCkoSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB1c2VySWQ6IHRyYWNrT3duUHJvZmlsZVVzZXJJZC5nZXQoKSxcbiAgICAgICAgcGxhdGZvcm06IHJvb3RfMS5teXNvbWUucGxhdGZvcm0sXG4gICAgICAgIG5hbWU6IHRyYWNrT3duUHJvZmlsZU5hbWUuZ2V0KCksXG4gICAgICAgIHByb2ZpbGVQaWNVcmw6IHRyYWNrUHJvZmlsZVBpY3R1cmVVcmwuZ2V0KCksXG4gICAgICAgIGJhY2tncm91bmRQaWNVcmw6IHRyYWNrQmFja2dyb3VuZFVybC5nZXQoKSxcbiAgICB9KSkpO1xuICAgIHZhciBiYXNlID0gV0VCU0lURV9CQVNFX1VSTCgpO1xuICAgIHJldHVybiBcIlwiLmNvbmNhdChiYXNlLCBcIi9jcmVhdGUvMj9cIikuY29uY2F0KHRlbXBsYXRlKTtcbn07XG5mdW5jdGlvbiBzaG93V2VsY29tZVBvcHVwKCkge1xuICAgICgwLCBwb3B1cF8xLnNob3dNZXNzYWdlUG9wdXApKHtcbiAgICAgICAgdGl0bGU6ICdUaGFuayB5b3UgZm9yIGluc3RhbGxpbmcgbXlzb21lLmlkJyxcbiAgICAgICAgbWVzc2FnZTogJ1RvIGdldCBzdGFydGVkIHlvdSBtdXN0IGxpbmsgYSBwcm9vZiBvZiBhY2NvdW50IG93bmVyc2hpcCB0byB5b3VyIHByb2ZpbGU8YnIvPjxici8+VGlwOiBJZiB5b3UgbmVlZCBhZGRpdGlvbmFsIGFzc2lzdGFuY2UsIHlvdSBjYW4gYWx3YXlzIGNsaWNrIG9uIHRoZSBteXNvbWUuaWQgc2hpZWxkIG9yIGJhZGdlJyxcbiAgICAgICAgY2xhc3NOYW1lOiAnYmFkZ2UtcG9wdXAnLFxuICAgICAgICBwcmltYXJ5OiAnQ3JlYXRlIFByb29mJyxcbiAgICAgICAgc2Vjb25kYXJ5OiAnQ0FOQ0VMJyxcbiAgICAgICAgcHJpbWFyeV9saW5rOiBnZXRDcmVhdGVMaW5rKCksXG4gICAgfSk7XG4gICAgdXRpbHNfMS5zdG9yYWdlLnNldChcImNvbnRlbnQtd2VsY29tZS1zaG93blwiLCB0cnVlKS50aGVuKGZ1bmN0aW9uICgpIHsgfSkuY2F0Y2goY29uc29sZS5lcnJvcik7XG59XG52YXIgaW5zdGFsbCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIF9fYXdhaXRlcih2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHJlcXVlc3RUb0ZldGNoUHJvZmlsZSwgcmVncywgYmFkZ2VDbGlja0hhbmRsZXIsIGJhZGdlLCBjaGVjaztcbiAgICB2YXIgX2EsIF9iO1xuICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2MpIHtcbiAgICAgICAgc3dpdGNoIChfYy5sYWJlbCkge1xuICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgIHV0aWxzXzEubG9nZ2VyLmluZm8oXCJJbnN0YWxsIGxpbmtlZEluIEhvb2tzXCIpO1xuICAgICAgICAgICAgICAgICgwLCBjb250ZW50X21lc3NhZ2luZ18xLmdldE1lc3NhZ2VIYW5kbGVyKSgpLmFkZE1lc3NhZ2VIYW5kbGVyKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0eXBlID0gZGF0YS50eXBlO1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ3Nob3ctY29udGVudC13aWRnZXQnOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUgPT09IG51bGwgfHwgcm9vdF8xLm15c29tZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcm9vdF8xLm15c29tZS5iYWRnZUNsaWNrSGFuZGxlcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcm9vdCA9ICgwLCByb290XzEuY3JlYXRlUm9vdFdpZGdldCkoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCB1dGlsc18xLnN0b3JhZ2UuZ2V0KFwibGkubnZpc2l0XCIpXTtcbiAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAvLyBIb3cgbWFueSB0aW1lcyB3ZSBoYXZlIHZpc2l0ZWQgdGhlIHdlYnNpdGUuXG4gICAgICAgICAgICAgICAgbnZpc2l0ID0gKF9hID0gKF9jLnNlbnQoKSkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdXRpbHNfMS5zdG9yYWdlLnNldChcImxpLm52aXNpdFwiLCBudmlzaXQgKyAxKV07XG4gICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgX2Muc2VudCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHV0aWxzXzEuc3RvcmFnZS5nZXQoXCJjb250ZW50LXdlbGNvbWUtc2hvd25cIildO1xuICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgIHdlbGNvbWVTaG93biA9IF9jLnNlbnQoKTtcbiAgICAgICAgICAgICAgICB1dGlsc18xLmxvZ2dlci5pbmZvKFwid2VsY29tZVNob3duIFwiLCB3ZWxjb21lU2hvd24pO1xuICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUuaW5mbyA9IHtcbiAgICAgICAgICAgICAgICAgICAgd2VsY29tZVNob3duOiB3ZWxjb21lU2hvd24sXG4gICAgICAgICAgICAgICAgICAgICdsaS5udmlzaXQnOiBudmlzaXQgKyAxLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdXRpbHNfMS5wbGF0Zm9ybVJlcXVlc3RzLnNlbGVjdCgnbGknLCAnY3JlYXRlZCcsICdmZXRjaC1wcm9maWxlJyldO1xuICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgIHJlcXVlc3RUb0ZldGNoUHJvZmlsZSA9IChfYiA9IChfYy5zZW50KCkpKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiBudWxsO1xuICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUucmVxdWVzdHMgPSByZXF1ZXN0VG9GZXRjaFByb2ZpbGUgIT09IG51bGwgJiYgcmVxdWVzdFRvRmV0Y2hQcm9maWxlICE9PSB2b2lkIDAgPyByZXF1ZXN0VG9GZXRjaFByb2ZpbGUgOiBbXTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlcXVlc3RzXCIsIHJvb3RfMS5teXNvbWUucmVxdWVzdHMpO1xuICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIHV0aWxzXzEucmVnaXN0cmF0aW9ucy5mZXRjaCgpXTtcbiAgICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgICAgICByZWdzID0gX2Muc2VudCgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwicmVnaXN0cmF0aW9uc1wiLCByZWdzKTtcbiAgICAgICAgICAgICAgICAvLyBcbiAgICAgICAgICAgICAgICByb290XzEubXlzb21lLnRvdXJzID0ge1xuICAgICAgICAgICAgICAgICAgICAnbGkuZmluYWxpemUnOiBjaGFuZ2VCYWNrZ3JvdW5kVG91cixcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHRyYWNraW5nXzEudHJhY2tpbmcub24oJ293blByb2ZpbGVVc2VySWRPYnNlcnZlZCcsIGZ1bmN0aW9uICh1c2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJPd24gcHJvZmlsZSBuYW1lIG9ic2V2ZWQgXCIsIHVzZXJJZCk7XG4gICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUub25QbGF0Zm9ybU9ic2VydmVkKHJvb3RfMS5teXNvbWUucGxhdGZvcm0sIHVzZXJJZCk7IC8vIHdoZW4gYSB1c2VyIGhhcyBiZWVuIGxvZ2dpbmcgaW50byB0aGUgcGxhdGZvcm0uXG4gICAgICAgICAgICAgICAgICAgIHZhciByZXFzID0gcm9vdF8xLm15c29tZS5yZXF1ZXN0cztcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlcXMgJiYgcmVxcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlcXVlc3RzXCIsIHJlcXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHJlcXNbMF07XG4gICAgICAgICAgICAgICAgICAgICAgICB1dGlsc18xLnBsYXRmb3JtUmVxdWVzdHMucmVtb3ZlUmVxdWVzdHMoJ2xpJykudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKDAsIHBvcHVwXzEuc2hvd01lc3NhZ2VQb3B1cCkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0dldCBQcm9maWxlIEluZm8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnRG8geW91IHdhbnQgdG8gc2VjdXJlIHlvdXIgcHJvZmlsZT8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWNvbmRhcnk6ICdDQU5DRUwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5OiAnQ29udGludWUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5X2xpbms6IGdldENyZWF0ZUxpbmsoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZhciByZWcgPSB1dGlsc18xLnJlZ2lzdHJhdGlvbnMuc2VsZWN0KCdsaScsIHVzZXJJZCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiT3duIFByb2ZpbGUgcmVnaXN0cmF0aW9uOiBcIiwgcmVnKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlZyAmJiByZWcuc3RlcCA9PT0gNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS5jcmVhdGVUb3VyKCdsaS5maW5hbGl6ZScpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdHJhY2tpbmdfMS50cmFja2luZy5vbignb3RoZXJQcm9maWxlT2JzZXJ2ZWQnLCBmdW5jdGlvbiAodXNlcklkKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZWcgPSB1dGlsc18xLnJlZ2lzdHJhdGlvbnMuc2VsZWN0KCdsaScsIHVzZXJJZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZWcgJiYgcmVnLnN0ZXAgPT09IDUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJPdGhlciBwcm9maWxlIG9ic2VydmVkIGJ1dCB0aGVyZSBpcyBhIHJlZ2lzdHJhdGlvbiEgKHRoaXMgaXMgbm90IHN1cHBvc2VkIHRvIGhhcHBlbilcIiwgcmVnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICgwLCBwb3B1cF8xLnNob3dNZXNzYWdlUG9wdXApKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1dhcm5pbmcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiWW91IGhhdmUgdHJpZWQgdG8gY3JlYXRlIGEgcHJvb2YgZm9yIGEgcHJvZmlsZSB3aGljaCB5b3UgZG9udCBoYXZlIGFjY2VzcyB0by48YnIvPjxici8+TG9nIGluIHRvIHRoZSBwcm9maWxlIHRvIGZpbmFsaXNlIHRoZSByZWdpc3RyYXRpb24uXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWFyeTogXCJPa2F5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGJhZGdlQ2xpY2tIYW5kbGVyID0gcm9vdF8xLm15c29tZS5iYWRnZUNsaWNrSGFuZGxlciA9IGZ1bmN0aW9uIChwYXJhbXMpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIF9hLCBfYiwgX2MsIF9lLCBfZiwgX2csIF9oLCBfaiwgX2ssIF9sO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2hpZWxkICYmIChzaGllbGQgPT09IG51bGwgfHwgc2hpZWxkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzaGllbGQuaXNMb2FkaW5nKCkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmFyIHBvcHVwcyA9ICgwLCBwb3B1cF8xLmNvdW50UG9wdXBzV2l0aENsYXNzTmFtZSkoJ2JhZGdlLXBvcHVwJyk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdwb3B1cHMgJywgcG9wdXBzKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvcHVwcyA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiaWdub3JlZCBzaG93aW5nIHBvcHVwIGFzIG9uZSBvdGhlciBwb3B1cCBpcyBhbHJlYWR5IHNob3duLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBSZXNvbHZlIHRoZSBwYXJhbXMgdGhhdCB3ZSB3YW50IHRvIG9wZW4gdGhlIHBvcHVwXG4gICAgICAgICAgICAgICAgICAgIHZhciB1ID0gKF9iID0gKF9hID0gKDAsIHV0aWxzXzEuZ2V0VXNlcklkSW5VcmwpKCkpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICgwLCB1dGlsc18xLmdldFVzZXJJZE9uUGFnZUZlZWQpKCkpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICcnO1xuICAgICAgICAgICAgICAgICAgICB2YXIgcHJvb2ZVcmwgPSAocGFyYW1zICE9PSBudWxsICYmIHBhcmFtcyAhPT0gdm9pZCAwID8gcGFyYW1zIDoge30pLnByb29mVXJsO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXByb29mVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9vZlVybCA9IHN0YXRlLnByb29mVXJsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9vZklkID0gKF9lID0gKF9jID0gcHJvb2ZVcmwgPT09IG51bGwgfHwgcHJvb2ZVcmwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb29mVXJsLnNwbGl0KCcvJykpID09PSBudWxsIHx8IF9jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfY1s0XSkgIT09IG51bGwgJiYgX2UgIT09IHZvaWQgMCA/IF9lIDogJyc7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9vZktleSA9IChfZyA9IChfZiA9IHByb29mVXJsID09PSBudWxsIHx8IHByb29mVXJsID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwcm9vZlVybC5zcGxpdCgnLycpKSA9PT0gbnVsbCB8fCBfZiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2ZbNV0pICE9PSBudWxsICYmIF9nICE9PSB2b2lkIDAgPyBfZyA6ICcnO1xuICAgICAgICAgICAgICAgICAgICBwcm9vZlVybCA9IHByb29mSWQgJiYgcHJvb2ZLZXkgPyBbJ2h0dHBzOi8vYXBwLnRlc3RuZXQubXlzb21lLmlkJywgdHJhY2tPbk93blByb2ZpbGVPckZlZWQuZ2V0KCkgPyAnbXktcHJvb2YnIDogJ3YnLCBwcm9vZklkLCBwcm9vZktleV0uam9pbignLycpIDogcHJvb2ZVcmw7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvblByb2ZpbGVQYWdlID0gdHJhY2tPblByb2ZpbGVVcmwuZ2V0KCk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvbk93blByb2ZpbGVPckZlZWQgPSB0cmFja09uT3duUHJvZmlsZU9yRmVlZC5nZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG93blVzZXJJZCA9IHRyYWNrT3duUHJvZmlsZVVzZXJJZC5nZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJCYWRnZSBjbGlja2VkXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG93blByb2ZpbGVVc2VySWRic2VydmVkOiBvd25Vc2VySWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IHByb2ZpbGVTdGF0dXMuZ2V0KCksXG4gICAgICAgICAgICAgICAgICAgICAgICB1OiB1LFxuICAgICAgICAgICAgICAgICAgICAgICAgb25Qcm9maWxlUGFnZTogb25Qcm9maWxlUGFnZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uT3duUHJvZmlsZU9yRmVlZDogb25Pd25Qcm9maWxlT3JGZWVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvb2ZVcmw6IHByb29mVXJsLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgLy8gb24gYW5vdGhlciB1c2VycyBwcm9maWxlIHBhZ2UuXG4gICAgICAgICAgICAgICAgICAgIGlmIChvblByb2ZpbGVQYWdlICYmICFvbk93blByb2ZpbGVPckZlZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9maWxlU3RhdHVzLmdldCgpICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0YXR1c18xID0gKF9qID0gKF9oID0gcHJvZmlsZVN0YXR1cyA9PT0gbnVsbCB8fCBwcm9maWxlU3RhdHVzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwcm9maWxlU3RhdHVzLmdldCgpKSA9PT0gbnVsbCB8fCBfaCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2guc3RhdHVzKSAhPT0gbnVsbCAmJiBfaiAhPT0gdm9pZCAwID8gX2ogOiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzdGF0dXNNZXNzYWdlID0gc3RhdHVzXzEgPT09ICduby1jb25uZWN0aW9uJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdObyBjb25uZWN0aW9uIHRvIHRoZSBteXNvbWUuaWQgc2VydmljZScgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNfMSA9PT0gJ25vdC1yZWdpc3RlcmVkJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnVGhpcyBwZXJzb25zIHByb2ZpbGUgaXMgbm90IHlldCB2ZXJpZmllZC48YnIvPjxici8+SWYgeW91IGtub3cgdGhlbSB5b3UgY2FuIHJlYWNoIG91dCB0byB0aGVtIGFuZCB0ZWxsIHRoZW0gaG93IHRvIHNlY3VyZSB0aGVpciBwcm9maWxlIHVzaW5nIG15c29tZS5pZC4nIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c18xID09PSAncmVnaXN0ZXJlZCcgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdUaGlzIHBlcnNvbnMgcHJvZmlsZSBpcyB2ZXJpZmllZCBieSBteXNvbWUuaWQnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNfMSA9PT0gJ3N1c3BlY2lvdXMnID9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1RoaXMgcGVyc29ucyBwcm9maWxlIGlzIG5vdCB2ZXJpZmllZCBvciBzdXNwZWNpb3VzJyA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdUaGlzIHByb2ZpbGUgc3RhdHVzIGlzIHVua25vd24nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBnb3RvID0gc3RhdHVzXzEgPT09ICdyZWdpc3RlcmVkJyA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ290b19idXR0b246ICdWaWV3IFByb29mJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ290b19saW5rOiBwcm9vZlVybCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vjb25kYXJ5OiAnQmFjaycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSA6IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICgwLCBwb3B1cF8xLnNob3dNZXNzYWdlUG9wdXApKF9fYXNzaWduKHsgdGl0bGU6ICdQcm9maWxlIFN0YXR1cycsIG1lc3NhZ2U6IHN0YXR1c01lc3NhZ2UsIGNsYXNzTmFtZTogJ2JhZGdlLXBvcHVwJywgcHJpbWFyeTogKHN0YXR1c18xICE9PSAncmVnaXN0ZXJlZCcgPyAnT2theScgOiAnJykgfSwgZ290bykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG9uT3duUHJvZmlsZU9yRmVlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG93blVzZXJJZCAhPT0gbnVsbCAmJiBwcm9maWxlU3RhdHVzICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRtcCA9IHByb2ZpbGVTdGF0dXMuZ2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0YXR1c18yID0gKF9sID0gKF9rID0gcHJvZmlsZVN0YXR1cy5nZXQoKSkgPT09IG51bGwgfHwgX2sgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9rLnN0YXR1cykgIT09IG51bGwgJiYgX2wgIT09IHZvaWQgMCA/IF9sIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdHVzXzIgPT09ICdub3QtcmVnaXN0ZXJlZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlZyA9IHV0aWxzXzEucmVnaXN0cmF0aW9ucy5zZWxlY3Qocm9vdF8xLm15c29tZS5wbGF0Zm9ybSwgb3duVXNlcklkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0ZXAgPSAocmVnICE9PSBudWxsICYmIHJlZyAhPT0gdm9pZCAwID8gcmVnIDoge30pLnN0ZXA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdGVwID09PSA1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBDb250aW51ZSB0aGUgaW5zdGFsbGF0aW9uIHByb2Nlc3MuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNvbnRpbnVlIHRoZSBpbnN0YWxsYXRpb24gcHJvY2VzcyBmb3IgTGlua2VkSW46IFwiICsgb3duVXNlcklkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUuY3JlYXRlVG91cignbGkuZmluYWxpemUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGVwID4gNSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNyZWF0ZUxpbmsgPSBnZXRDcmVhdGVMaW5rKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoMCwgcG9wdXBfMS5zaG93TWVzc2FnZVBvcHVwKSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdZb3VyIFByb2ZpbGUgU3RhdHVzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkl0IHNlZW1zIHRoYXQgeW91ciBwcm9maWxlIGlzIG5vIGxvbmdlciB2ZXJpZmllZC48YnIvPjxici8+VG8gcmVzb2x2ZSB0aGlzLCB5b3UgbmVlZCB0byBwcm92aWRlIGEgbmV3IHZlcmlmaWNhdGlvbiBwcm9vZiBhbmQgYXR0YWNoIGl0IHRvIHlvdXIgTGlua2VkSW4gcHJvZmlsZS5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU6ICdiYWRnZS1wb3B1cCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWFyeTogJ0NyZWF0ZSBQcm9vZicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vjb25kYXJ5OiAnQ0FOQ0VMJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5X2xpbms6IGNyZWF0ZUxpbmssXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghcmVnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93Tm90VmVyaWZpZWRQb3B1cCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBnb3RvID0gc3RhdHVzXzIgPT09ICdyZWdpc3RlcmVkJyA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ290b19idXR0b246ICdWaWV3IFByb29mJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ290b19saW5rOiBwcm9vZlVybCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vjb25kYXJ5OiAnQmFjaycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW1hcnk6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gOiB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RhdHVzTWVzc2FnZSA9IHN0YXR1c18yID09PSAnbm8tY29ubmVjdGlvbicgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnTm8gY29ubmVjdGlvbiB0byB0aGUgbXlzb21lLmlkIHNlcnZpY2UnIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzXzIgPT09ICdub3QtcmVnaXN0ZXJlZCcgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1lvdXIgcHJvZmlsZSBpcyBub3QgeWV0IHZlcmlmaWVkLicgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzXzIgPT09ICdyZWdpc3RlcmVkJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1lvdXIgcHJvZmlsZSBpcyB2ZXJpZmllZCcgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c18yID09PSAnc3VzcGVjaW91cycgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnWW91ciBwcm9maWxlIGlzIGludmFsaWQuPGJyLz48YnIvPllvdSB3aWxsIGFwcGVhciBzdXNwZWNpb3VzIHRvIG90aGVyIHVzZXJzIG9uIExpbmtlZEluIHVzaW5nIG15c29tZS5pZC48YnIvPlRvIGZpeCB0aGlzIHlvdSBuZWVkIHRvIG1ha2Ugc3VyZSB5b3VyIGZpcnN0IG5hbWUgYW5kIGxhc3QgbmFtZSBtYXRjaGVzIHRoZSBwcm9vZi4nIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1lvdXIgcHJvZmlsZSBzdGF0dXMgaXMgdW5rbm93bic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF3ZWxjb21lU2hvd24gJiYgc3RhdHVzXzIgPT09ICdub3QtcmVnaXN0ZXJlZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1dlbGNvbWVQb3B1cCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1Nob3cgc3RhdHVzIHdpdGggaW5mbyAnLCBnb3RvKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKDAsIHBvcHVwXzEuc2hvd01lc3NhZ2VQb3B1cCkoX19hc3NpZ24oeyB0aXRsZTogJ1lvdXIgUHJvZmlsZSBTdGF0dXMnLCBtZXNzYWdlOiBzdGF0dXNNZXNzYWdlLCBjbGFzc05hbWU6ICdiYWRnZS1wb3B1cCcsIHByaW1hcnk6ICdPa2F5JyB9LCBnb3RvKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIXdlbGNvbWVTaG93bikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dXZWxjb21lUG9wdXAoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgYmFkZ2UgPSByb290XzEubXlzb21lLmNyZWF0ZUJhZGdlKHsgc2hvd0F0dGVudGlvbjogZmFsc2UgfSk7XG4gICAgICAgICAgICAgICAgYmFkZ2UuYWRkQ2xpY2tIYW5kbGVyKGJhZGdlQ2xpY2tIYW5kbGVyKTtcbiAgICAgICAgICAgICAgICAvLyBUaGVyZSBpcyBhIGJhY2tncm91bmQgdXJsLlxuICAgICAgICAgICAgICAgIHRyYWNraW5nXzEudHJhY2tpbmcub24oJ2JhY2tncm91bmRVcmxDaGFuZ2VkJywgZnVuY3Rpb24gKHVybCkge1xuICAgICAgICAgICAgICAgICAgICAvKmlmICggb25Pd25QYWdlT3JGZWVkICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgX3MgPSBlbnN1cmVXaWRnZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICggX3MgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmVyaWZ5UHJvZmlsZShfcywgb25Pd25QYWdlT3JGZWVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSovXG4gICAgICAgICAgICAgICAgICAgIC8qc2V0UHJvZmlsZVN0YXR1c0JhY2tncm91bmRVcmwoe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJvZmlsZVN0YXR1c09iaixcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybFxuICAgICAgICAgICAgICAgICAgICB9KTsqL1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRyYWNraW5nXzEudHJhY2tpbmcub24odHJhY2tQcm9vZlFSLmNoYW5nZUV2ZW50TmFtZSwgZnVuY3Rpb24gKHByb29mKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBfYSwgX2IsIF9jO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnUHJvb2YgY2hhbmdlZCA6ICcgKyBwcm9vZik7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvbk93blBhZ2VPckZlZWQgPSAhIXRyYWNraW5nXzEudHJhY2tpbmcub25Pd25Qcm9maWxlT3JGZWVkO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvb2YgJiYgcHJvb2YgIT09ICduby1jb25uZWN0aW9uJyAmJiBwcm9vZiAhPT0gJ25vLXByb29mJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1Byb29mIG9ic2VydmVkJywgcHJvb2YpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUucHJvb2ZVcmwgPSBwcm9vZjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB1c2VySWQgPSB0cmFja1Byb2ZpbGVVc2VySWQuZ2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbmFtZV8xID0gdHJhY2tQcm9maWxlTmFtZS5nZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb21wb25lbnRzID0gKF9hID0gbmFtZV8xID09PSBudWxsIHx8IG5hbWVfMSA9PT0gdm9pZCAwID8gdm9pZCAwIDogbmFtZV8xLnNwbGl0KCcgJykpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGZpcnN0TmFtZSA9IChfYiA9IGNvbXBvbmVudHNbMF0pICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGxhc3ROYW1lID0gKF9jID0gY29tcG9uZW50c1tjb21wb25lbnRzLmxlbmd0aCAtIDFdKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlUHJvb2ZXaXRoUHJvZmlsZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlyc3ROYW1lOiBmaXJzdE5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdE5hbWU6IGxhc3ROYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb29mVXJsOiBzdGF0ZS5wcm9vZlVybCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyRGF0YTogdXNlcklkICE9PSBudWxsICYmIHVzZXJJZCAhPT0gdm9pZCAwID8gdXNlcklkIDogJycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhdGZvcm06ICdsaScsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KS50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWRVJJRlkgUmVzdWx0IFwiLCByZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN0YXR1cyA9PT0gJ3ZhbGlkJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaGllbGQgPT09IG51bGwgfHwgc2hpZWxkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzaGllbGQuc2V0VmVyaWZpZWQocHJvb2YsIG9uT3duUGFnZU9yRmVlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlLnNob3dBdHRlbnRpb24oZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQcm9maWxlU3RhdHVzUmVzb2x2ZWQoJ3Byb2ZpbGUnLCBvbk93blBhZ2VPckZlZWQgPyAnb3duJyA6ICdvdGhlcicsICdyZWdpc3RlcmVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0YXR1cyA9PT0gJ2ludmFsaWQnIHx8IHN0YXR1cyA9PT0gJ3N1c3BlY2lvdXMnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNoaWVsZCA9PT0gbnVsbCB8fCBzaGllbGQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNoaWVsZC5zZXRTdXNwZWNpb3VzUHJvZmlsZShwcm9vZik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlLnNob3dBdHRlbnRpb24odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFByb2ZpbGVTdGF0dXNSZXNvbHZlZCgncHJvZmlsZScsIG9uT3duUGFnZU9yRmVlZCA/ICdvd24nIDogJ290aGVyJywgJ3N1c3BlY2lvdXMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZXZhbHVhdGUgdGhlIHN0YXR1cyBvZiB0aGUgcHJvb2YuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChwcm9vZiA9PT0gJ25vLWNvbm5lY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1dGlsc18xLmxvZ2dlci5pbmZvKFwiTm8gUVIgY29kZSBkZXRlY3RlZCAtIG5vIGNvbm5lY3Rpb24gdG8gQVBJXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hpZWxkID09PSBudWxsIHx8IHNoaWVsZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2hpZWxkLnNldE5vQ29ubmVjdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2Uuc2hvd0F0dGVudGlvbih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFByb2ZpbGVTdGF0dXNSZXNvbHZlZCgncHJvZmlsZScsIG9uT3duUGFnZU9yRmVlZCA/ICdvd24nIDogJ290aGVyJywgJ25vLWNvbm5lY3Rpb24nKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChwcm9vZiA9PT0gJ25vLXByb29mJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5sb2dnZXIuaW5mbyhcIk5vIFFSIGNvZGUgZGV0ZWN0ZWQgLSBQcm9maWxlIG5vdCBkZXRlY3RlZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uT3duUGFnZU9yRmVlZCAmJiAoc2hpZWxkID09PSBudWxsIHx8IHNoaWVsZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2hpZWxkLnNldE93blByb2ZpbGVOb3RWZXJpZmllZCgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICFvbk93blBhZ2VPckZlZWQgJiYgKHNoaWVsZCA9PT0gbnVsbCB8fCBzaGllbGQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNoaWVsZC5zZXRPdGhlclByb2ZpbGVOb3RWZXJpZmllZCgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhZGdlLnNob3dBdHRlbnRpb24odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQcm9maWxlU3RhdHVzUmVzb2x2ZWQoJ3Byb2ZpbGUnLCBvbk93blBhZ2VPckZlZWQgPyAnb3duJyA6ICdvdGhlcicsICdub3QtcmVnaXN0ZXJlZCcpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5sb2dnZXIuaW5mbyhcIk5vIFFSIGNvZGUgZGV0ZWN0ZWQgLSBQcm9maWxlIGlzIG5vdCB2ZXJpZmllZC5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBvbk93blBhZ2VPckZlZWQgJiYgKHNoaWVsZCA9PT0gbnVsbCB8fCBzaGllbGQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNoaWVsZC5zZXRPd25Qcm9maWxlTm90VmVyaWZpZWQoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAhb25Pd25QYWdlT3JGZWVkICYmIChzaGllbGQgPT09IG51bGwgfHwgc2hpZWxkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzaGllbGQuc2V0T3RoZXJQcm9maWxlTm90VmVyaWZpZWQoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZS5zaG93QXR0ZW50aW9uKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFByb2ZpbGVTdGF0dXNSZXNvbHZlZCgncHJvZmlsZScsIG9uT3duUGFnZU9yRmVlZCA/ICdvd24nIDogJ290aGVyJywgJ25vdC1yZWdpc3RlcmVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0cmFja2luZ18xLnRyYWNraW5nLm9uKHRyYWNrVXJsLmNoYW5nZUV2ZW50TmFtZSwgZnVuY3Rpb24gKHVybCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk5ldyB1cmwgOiBcIiwgdXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVybC5pbmRleE9mKCcvaW4vJykgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWRnZS5zaG93KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAodXJsLmluZGV4T2YoJy9mZWVkLycpID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2Uuc2hvdygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFkZ2UuaGlkZSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdHJhY2tpbmdfMS50cmFja2luZy5vbih0cmFja1BhdGhuYW1lLmNoYW5nZUV2ZW50TmFtZSwgZnVuY3Rpb24gKHBhdGhOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIElmIHdlIGFyZSBvbiB0aGUgaG9tZXNjcmVlbiB3aXRoIHRoZSBsb2dpbiBmb3JtIHZpc2liaWxlIHRoZW5cbiAgICAgICAgICAgICAgICAgICAgLy8gd2UgZmluZCBhbiBvcGVuIHJlZ2lzdHJhdGlvbiBjcmVhdGVkIGxlc3MgdGhhbiAzMCBzZWNvbmRzIGFnb1xuICAgICAgICAgICAgICAgICAgICAvLyBhbmQgc2hvdyBhIG1lc3NhZ2UgdG8gdGVsbCB0aGUgdXNlciB0byBsb2dpbiB0byBjb250aW51ZSB0aGVpclxuICAgICAgICAgICAgICAgICAgICAvLyByZWdpc3RyYXRpb24uXG4gICAgICAgICAgICAgICAgICAgIGlmICgocGF0aE5hbWUgPT09ICcvaG9tZScgfHwgcGF0aE5hbWUgPT09ICcvJykgJiYgISFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdmb3JtW2RhdGEtaWQ9XCJzaWduLWluLWZvcm1cIl0nKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXRpbHNfMS5wbGF0Zm9ybVJlcXVlc3RzLmZldGNoKCkudGhlbihmdW5jdGlvbiAocmVxdWVzdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInJlcXVlc3RzXCIsIHJlcXVlc3RzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZm91bmRSZXEgPSByZXF1ZXN0cy5maW5kKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkZWx0YVRpbWUgPSAoKG5ldyBEYXRlKCkuZ2V0VGltZSgpIC0geC5jcmVhdGVkKSAvIDEwMDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geC5wbGF0Zm9ybSA9PT0gJ2xpJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeC5zdGF0dXMgPT09ICdjcmVhdGVkJyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsdGFUaW1lIDwgMzA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGZvdW5kUmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgwLCBwb3B1cF8xLnNob3dNZXNzYWdlUG9wdXApKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnU2VjdXJlIFlvdXIgUHJvZmlsZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnTG9nIGluIHRvIHNlY3VyZSB5b3VyIHByb2ZpbGUgd2l0aCBteXNvbWUuaWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWFyeTogJ09rYXknXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdHJhY2tpbmdfMS50cmFja2luZy5vbih0cmFja0hlYWRlci5jaGFuZ2VFdmVudE5hbWUsIGZ1bmN0aW9uIChoZWFkZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgKDAsIHV0aWxzXzEudmVyYm9zZSkoXCJIZWFkZXI6IHVwZGF0ZWRcIik7XG4gICAgICAgICAgICAgICAgICAgIGlmIChoZWFkZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwiSGVhZGVyOiBBcXVpcmVkIGhlYWRlclwiKTsgLy8sIHtwcmVIZWFkZXIsIG5ld0hlYWRlcjogaGVhZGVyfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaGllbGQgPSBlbnN1cmVXaWRnZXQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghaGVhZGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAoMCwgdXRpbHNfMS52ZXJib3NlKShcIkhlYWRlcjogTG9zdCBoZWFkZXJcIik7IC8vLCB7cHJlSGVhZGVyLCBuZXdIZWFkZXI6IGhlYWRlcn0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hpZWxkID09PSBudWxsIHx8IHNoaWVsZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2hpZWxkLmhpZGUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwiSGVhZGVyOiBjaGFuZ2VkXCIpOyAvLywge3ByZUhlYWRlciwgbmV3SGVhZGVyOiBoZWFkZXJ9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRyYWNraW5nXzEudHJhY2tpbmcub24odHJhY2tQcm9maWxlVXNlcklkLmNoYW5nZUV2ZW50TmFtZSwgZnVuY3Rpb24gKHByb2ZpbGVVc2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJQcm9maWxlIHVzZXIgaWQgY2hhbmdlZCA6IFwiLCBwcm9maWxlVXNlcklkKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0cmFja2luZ18xLnRyYWNraW5nLm9uKHRyYWNrVmVyaWZ5U3RhdHVzLmNoYW5nZUV2ZW50TmFtZSwgZnVuY3Rpb24gKHZlcmlmeVN0YXR1cykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXZlcmlmeVN0YXR1cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhY2tQcm9vZlFSLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnk6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIG51bGw7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBSZXNldCBwcm9vZiB0byBudWxsIGlmIG5lZWRlZC5cbiAgICAgICAgICAgICAgICAgICAgdHJhY2tQcm9vZlFSLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVyeTogZnVuY3Rpb24gKCkgeyByZXR1cm4gbnVsbDsgfSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9maWxlVXNlcklkID0gdHJhY2tQcm9maWxlVXNlcklkLmdldCgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXByb2ZpbGVVc2VySWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYWNrUHJvb2ZRUi51cGRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7IHJldHVybiBudWxsOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzaGllbGQgJiYgdHJhY2tPblByb2ZpbGVVcmwuZ2V0KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignU2hpZWxkIGlzIHN1cHBvc2VkIHRvIGJlIGluaXRpYWxpc2VkLicpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZhciBiYWNrZ3JvdW5kSW1hZ2VVcmwgPSB0cmFja0JhY2tncm91bmRVcmwuZ2V0KCk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9maWxlUGljdHVyZVVybCA9IHRyYWNrUHJvZmlsZVBpY3R1cmVVcmwuZ2V0KCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnN0IG9uT3duUGFnZU9yRmVlZCA9ICEhdHJhY2tpbmcub25Pd25Qcm9maWxlT3JGZWVkO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc2hpZWxkICYmIHRyYWNrT25Qcm9maWxlVXJsLmdldCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaGllbGQuc2V0SW5pdGlhbFN0YXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdmVyaWZ5UHJvZmlsZShwcm9maWxlVXNlcklkLCBiYWNrZ3JvdW5kSW1hZ2VVcmwsIHByb2ZpbGVQaWN0dXJlVXJsKS50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByb2ZpbGVVc2VySWQgPSBfYS5wcm9maWxlVXNlcklkLCBxclJlc3VsdCA9IF9hLnFyUmVzdWx0LCBjb25uZWN0aW9uRXJyb3IgPSBfYS5jb25uZWN0aW9uRXJyb3I7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnUHJvZmlsZSB2ZXJpZmljYXRpb24gcmVzdWx0ICcsIHsgcXJSZXN1bHQ6IHFyUmVzdWx0LCBjb25uZWN0aW9uRXJyb3I6IGNvbm5lY3Rpb25FcnJvciB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwicXJSZXN1bHRcIiwgcXJSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRyYWNrUHJvZmlsZVVzZXJJZC5nZXQoKSA9PT0gcHJvZmlsZVVzZXJJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChxclJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25uZWN0aW9uRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhY2tQcm9vZlFSLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWVyeTogZnVuY3Rpb24gKCkgeyByZXR1cm4gcXJSZXN1bHQ7IH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFja1Byb29mUVIudXBkYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBmdW5jdGlvbiAoKSB7IHJldHVybiAhY29ubmVjdGlvbkVycm9yID8gJ25vLXByb29mJyA6ICduby1jb25uZWN0aW9uJzsgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Byb2ZpbGUgaGFzIGNoYW5nZWQgZHVyaW5nIHZlcmlmaWNhdGlvbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmVyaWZpY2F0aW9uU3RhdHVzXG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRyYWNraW5nXzEudHJhY2tpbmcub24ocHJvZmlsZVN0YXR1cy5jaGFuZ2VFdmVudE5hbWUsIGZ1bmN0aW9uIChwcykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcGFnZSA9IHBzLnBhZ2UsIHN0YXR1cyA9IHBzLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1Byb2ZpbGUgc3RhdHVzIGNoYW5nZWQgJywgcHMpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdHVzID09PSAnbm8tY29ubmVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdTdGF0dXMgJywgc3RhdHVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJhZGdlLnNob3dBdHRlbnRpb24oZmFsc2UpOyAvLyBNYWtlIHN1cmUgdGhhdCBiYWRnZSBpcyBub3Qgc2hvd24uXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gYmFkZ2Uuc2hvd0F0dGVudGlvbihwYWdlICE9PSAnb3RoZXInICYmIChzdGF0dXMgPT09ICdub3QtcmVnaXN0ZXJlZCcgfHwgc3RhdHVzID09PSAnc3VzcGVjaW91cycpKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBjaGVjayA9IGNyZWF0ZUhlYXJ0YmVhdCgpO1xuICAgICAgICAgICAgICAgIGNoZWNrKCk7XG4gICAgICAgICAgICAgICAgd2luZG93LnNldEludGVydmFsKGNoZWNrLCAyNTApO1xuICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCB7fV07XG4gICAgICAgIH1cbiAgICB9KTtcbn0pOyB9O1xuZXhwb3J0cy5kZWZhdWx0ID0gaW5zdGFsbDtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIGFwaUNyZWF0ZWQgPSBmYWxzZTtcbnZhciBmbmMgPSBmdW5jdGlvbiAoKSB7XG4gICAgY29uc29sZS5sb2coXCJJbmplY3RpbmcgTXlTb01lIEFQSVwiKTtcbiAgICBpZiAoYXBpQ3JlYXRlZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FQSSBhbHJlYWR5IGNyZWF0ZWQnKTtcbiAgICB9XG4gICAgdmFyIHNjcmlwdEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuICAgIHNjcmlwdEVsZW1lbnQuaWQgPSBcIm15c29tZWlkLWluamVjdGVkLXNjcmlwdFwiO1xuICAgIHNjcmlwdEVsZW1lbnQudHlwZSA9IFwidGV4dC9qYXZhc2NyaXB0XCI7XG4gICAgc2NyaXB0RWxlbWVudC5zcmMgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbmplY3RlZC9pbmRleC5qc1wiKTtcbiAgICBzY3JpcHRFbGVtZW50Lm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy8gc2NyaXB0RWxlbWVudC5yZW1vdmUoKTtcbiAgICB9O1xuICAgIChkb2N1bWVudC5oZWFkIHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuYXBwZW5kQ2hpbGQoc2NyaXB0RWxlbWVudCk7XG4gICAgYXBpQ3JlYXRlZCA9IHRydWU7XG59O1xuZXhwb3J0cy5kZWZhdWx0ID0gZm5jO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcbiAgICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICAgIH1cbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuLi91dGlsc1wiKTtcbnZhciByb290XzEgPSByZXF1aXJlKFwiLi4vcm9vdFwiKTtcbnZhciB0b3VyXzEgPSByZXF1aXJlKFwiLi4vdG91clwiKTtcbnZhciBpbmplY3RDb2RlID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gX19hd2FpdGVyKHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdG91ciwgZWw7XG4gICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICB1dGlsc18xLmxvZ2dlci5pbmZvKFwiSW5zdGFsbCB0ZXN0IHBhZ2UgaG9va3NcIik7XG4gICAgICAgICgwLCByb290XzEuY3JlYXRlUm9vdFdpZGdldCkoKTtcbiAgICAgICAgdG91ciA9ICgwLCB0b3VyXzEuY3JlYXRlVG91cldpZGdldCkoKTtcbiAgICAgICAgZWwgPSB3aW5kb3cuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0ZXN0LWRpdlwiKTtcbiAgICAgICAgaWYgKGVsKSB7XG4gICAgICAgICAgICB0b3VyLnNob3coZWwpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCB7fV07XG4gICAgfSk7XG59KTsgfTtcbmV4cG9ydHMuZGVmYXVsdCA9IGluamVjdENvZGU7XG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2Fzc2lnbiA9ICh0aGlzICYmIHRoaXMuX19hc3NpZ24pIHx8IGZ1bmN0aW9uICgpIHtcbiAgICBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24odCkge1xuICAgICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpXG4gICAgICAgICAgICAgICAgdFtwXSA9IHNbcF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHQ7XG4gICAgfTtcbiAgICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn07XG52YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgICBmdW5jdGlvbiBhZG9wdCh2YWx1ZSkgeyByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBQID8gdmFsdWUgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHZhbHVlKTsgfSk7IH1cbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBhZG9wdChyZXN1bHQudmFsdWUpLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICAgIH0pO1xufTtcbnZhciBfX2dlbmVyYXRvciA9ICh0aGlzICYmIHRoaXMuX19nZW5lcmF0b3IpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBib2R5KSB7XG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcbiAgICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICAgIH1cbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLnNob3dMb2FkaW5nUG9wdXAgPSBleHBvcnRzLnNob3dNZXNzYWdlUG9wdXAgPSBleHBvcnRzLnNob3dGaW5hbGl6ZVBvcHVwID0gZXhwb3J0cy5jcmVhdGVQb3B1cCA9IGV4cG9ydHMuY291bnRQb3B1cHNXaXRoQ2xhc3NOYW1lID0gdm9pZCAwO1xudmFyIGNvbnRlbnRfbWVzc2FnaW5nXzEgPSByZXF1aXJlKFwiLi9jb250ZW50LW1lc3NhZ2luZ1wiKTtcbnZhciByb290XzEgPSByZXF1aXJlKFwiLi9yb290XCIpO1xudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcbnZhciBudW1Qb3B1cHMgPSAwO1xudmFyIGNvdW50UG9wdXBzV2l0aENsYXNzTmFtZSA9IGZ1bmN0aW9uIChjbGFzc05hbWUpIHtcbiAgICB2YXIgY250ID0gMDtcbiAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0gT2JqZWN0LmVudHJpZXMocm9vdF8xLm15c29tZS53aWRnZXRzKTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgdmFyIHdpZGdldCA9IF9hW19pXTtcbiAgICAgICAgY250ICs9IHdpZGdldFsxXS5jbGFzc05hbWUgPT09IGNsYXNzTmFtZSA/IDEgOiAwO1xuICAgIH1cbiAgICByZXR1cm4gY250O1xufTtcbmV4cG9ydHMuY291bnRQb3B1cHNXaXRoQ2xhc3NOYW1lID0gY291bnRQb3B1cHNXaXRoQ2xhc3NOYW1lO1xudmFyIGNyZWF0ZVBvcHVwID0gZnVuY3Rpb24gKHNyYywgcm91dGUsIG9wdGlvbnMsIGNsYXNzTmFtZSkge1xuICAgIGlmIChyb3V0ZSA9PT0gdm9pZCAwKSB7IHJvdXRlID0gJyMvaG9tZSc7IH1cbiAgICBpZiAoY2xhc3NOYW1lID09PSB2b2lkIDApIHsgY2xhc3NOYW1lID0gJyc7IH1cbiAgICBpZiAobnVtUG9wdXBzID4gMCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiU2hvd2luZyBtb3JlIHRoYW4gb25lIHBvcHVwLlwiKTtcbiAgICB9XG4gICAgbnVtUG9wdXBzKys7XG4gICAgdmFyIF9hID0gb3B0aW9ucyAhPT0gbnVsbCAmJiBvcHRpb25zICE9PSB2b2lkIDAgPyBvcHRpb25zIDoge30sIF9iID0gX2EuY2xvc2VPbkJnQ2xpY2ssIGNsb3NlT25CZ0NsaWNrID0gX2IgPT09IHZvaWQgMCA/IHRydWUgOiBfYiwgX2MgPSBfYS5iZ0NvbG9yLCBiZ0NvbG9yID0gX2MgPT09IHZvaWQgMCA/ICcjYzljOWM5NjYnIDogX2M7XG4gICAgdmFyIGlkID0gTWF0aC5yb3VuZChNYXRoLnJhbmRvbSgpICogOTk5OTk5OTk5OTk5OSk7XG4gICAgcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXSA9IHtcbiAgICAgICAgaWQ6IGlkLFxuICAgICAgICBzcmM6IHNyYyxcbiAgICAgICAgcm91dGU6IHJvdXRlLFxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSxcbiAgICAgICAgY3JlYXRlZDogZmFsc2UsXG4gICAgICAgIGNyZWF0aW5nOiB0cnVlLFxuICAgICAgICBvblJlc3VsdDogbnVsbCxcbiAgICB9O1xuICAgIChmdW5jdGlvbiAoKSB7IHJldHVybiBfX2F3YWl0ZXIodm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgbWVzc2FnZUhhbmRsZXIsIHJlc3BvbnNlLCB1cmwsIGUsIGNyZWF0ZWQsIGZyYW1lVmlldywgb3ZlcmxheSwgaWZyYW1lLCBvdmVybGF5Q2xpY2tlZCwgY250LCBpbnRlcnZhbDtcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzcmMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYyA9ICd3aWRnZXQvaW5kZXguaHRtbCc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZUhhbmRsZXIgPSAoMCwgY29udGVudF9tZXNzYWdpbmdfMS5nZXRNZXNzYWdlSGFuZGxlcikoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoJ2JhY2tncm91bmQnLCAnZ2V0LXVybCcsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxlOiBzcmMsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KV07XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gcmVzcG9uc2UucGF5bG9hZC51cmwgKyByb3V0ZTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cmwgXCIsIHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICBlLmlkID0gXCJteXNvbWUtZnJhbWUtXCIuY29uY2F0KGlkKTtcbiAgICAgICAgICAgICAgICAgICAgZS5pbm5lckhUTUwgPSBcIlxcblxcdFxcdFxcdDxkaXYgaWQ9XFxcIm15c29tZS1mcmFtZS1jb250YWluZXItXCIuY29uY2F0KGlkLCBcIlxcXCIgc3R5bGU9XFxcInBvc2l0aW9uOiBmaXhlZDtsZWZ0OiAwO3RvcDogMDtyaWdodDogMDtib3R0b206IDA7ei1pbmRleDogOTk5OTk5O2JhY2tncm91bmQ6IFwiKS5jb25jYXQoYmdDb2xvciwgXCI7ZGlzcGxheTogZmxleDthbGlnbi1pdGVtczogY2VudGVyO3BsYWNlLWNvbnRlbnQ6IGNlbnRlcjsgYm9yZGVyOiBub25lO1xcXCI+XFxuXFx0XFx0XFx0ICBcXHQ8ZGl2IGlkPVxcXCJteXNvbWUtZnJhbWUtdmlldy1cIikuY29uY2F0KGlkLCBcIlxcXCIgc3R5bGU9XFxcImJhY2tncm91bmQ6IHdoaXRlO21heC13aWR0aDogMzgwcHg7aGVpZ2h0OiA1NTZweDtib3JkZXItcmFkaXVzOiA0cHg7Ym94LXNoYWRvdzogMHB4IDFweCAzNHB4IDlweCByZ2JhKDAsMCwwLDAuMjcpO3dpZHRoOiA4MCU7cG9zaXRpb246IGZpeGVkO2NvbG9yOiBibGFjaztib3JkZXItcmFkaXVzOiAxMHB4OyBvdmVyZmxvdzogaGlkZGVuO1xcXCI+XFxuXFx0XFx0XFx0XFx0XFx0PGlmcmFtZSBpZD1cXFwibXlzb21lLWZyYW1lLWlmcmFtZS1cIikuY29uY2F0KGlkLCBcIlxcXCIgYWxsb3cgc3JjPVxcXCJcIikuY29uY2F0KHVybCwgXCJcXFwiIHN0eWxlPVxcXCJ3aWR0aDogMTAwJTsgaGVpZ2h0OiAxMDAlOyBib3JkZXI6IG5vbmU7XFxcIj5cXG5cXHRcXHRcXHRcXHRcXHQ8L2lmcmFtZT5cXG5cXHRcXHQgIFxcdFxcdDwvZGl2PlxcblxcdFxcdFxcdDwvZGl2PlxcblxcdCAgXFx0XCIpO1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGUpO1xuICAgICAgICAgICAgICAgICAgICBmcmFtZVZpZXcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1mcmFtZS12aWV3LVwiLmNvbmNhdChpZCkpO1xuICAgICAgICAgICAgICAgICAgICBvdmVybGF5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtZnJhbWUtY29udGFpbmVyLVwiLmNvbmNhdChpZCkpO1xuICAgICAgICAgICAgICAgICAgICBpZnJhbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS1mcmFtZS1pZnJhbWUtXCIuY29uY2F0KGlkKSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZnJhbWVWaWV3KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGZyYW1lIHZpZXcnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBvdmVybGF5Q2xpY2tlZCA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNsb3NlT25CZ0NsaWNrKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiT3ZlcmxheSBjbGlja2VkXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXS5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIG92ZXJsYXkgPT09IG51bGwgfHwgb3ZlcmxheSA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3ZlcmxheS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb3ZlcmxheUNsaWNrZWQpO1xuICAgICAgICAgICAgICAgICAgICBmcmFtZVZpZXcuc3R5bGUub3BhY2l0eSA9ICcwJztcbiAgICAgICAgICAgICAgICAgICAgY250ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY250KysgPiAzMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1RpbWVkIG91dCBvcGVuaW5nIHdpbmRvdyAtIHRoaXMgaGFwcGVucyBpZiB5b3UgY2xvc2UgdGhlIHBvcHVwIGJlZm9yZSBpdHMgZnVsbHkgc2hvd24uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNyZWF0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZShcImluamVjdGVkLXdpZGdldFwiLCBcIndpZGdldC1jcmVhdGVcIiwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9LCAxMDApO1xuICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLndpZGdldHNbaWRdLmUgPSBlO1xuICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLndpZGdldHNbaWRdLmlmcmFtZSA9IGlmcmFtZTtcbiAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXS51cmwgPSB1cmw7XG4gICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0uZGVzdHJveSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG51bVBvcHVwcy0tO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBhcmVudCA9IGUucGFyZW50RWxlbWVudDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcGFyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIm5vIHBhcmVudCBlbGVtZW50IG9mIHdpZGdldC5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBvdmVybGF5ID09PSBudWxsIHx8IG92ZXJsYXkgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG92ZXJsYXkucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIG92ZXJsYXlDbGlja2VkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmVudCA9PT0gbnVsbCB8fCBwYXJlbnQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHBhcmVudC5yZW1vdmVDaGlsZChlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyb290XzEubXlzb21lLndpZGdldHNbaWRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJvb3RfMS5teXNvbWUud2lkZ2V0c1tpZF0uc2V0Q3JlYXRlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwid2lkZ2V0IG5vdyBjcmVhdGVkXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLndpZGdldHNbaWRdLmNyZWF0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS53aWRnZXRzW2lkXS5jcmVhdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZnJhbWVWaWV3LnN0eWxlLm9wYWNpdHkgPSAnaW5pdGlhbCc7IC8vIHNob3cgdGhlIGNvbnRhaW5lci5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pOyB9KSgpO1xuICAgIHJldHVybiByb290XzEubXlzb21lLndpZGdldHNbaWRdO1xufTtcbmV4cG9ydHMuY3JlYXRlUG9wdXAgPSBjcmVhdGVQb3B1cDtcbmZ1bmN0aW9uIHNob3dGaW5hbGl6ZVBvcHVwKHBvcHVwSW5mbykge1xuICAgIHZhciBhcmdzID0gKDAsIHV0aWxzXzEub2JqVG9VcmxQYXJtcykocG9wdXBJbmZvKTtcbiAgICB2YXIgY29udGV4dCA9IHJvb3RfMS5teXNvbWUuY3JlYXRlUG9wdXAoXCJ3aWRnZXQvaW5kZXguaHRtbFwiLCBcIiMvZmluYWxpemU/XCIuY29uY2F0KGFyZ3MpLCB7IGNsb3NlT25CZ0NsaWNrOiBmYWxzZSwgYmdDb2xvcjogJ3RyYW5zcGFyZW50JyB9KTtcbiAgICByZXR1cm4gY29udGV4dDtcbn1cbmV4cG9ydHMuc2hvd0ZpbmFsaXplUG9wdXAgPSBzaG93RmluYWxpemVQb3B1cDtcbmZ1bmN0aW9uIHNob3dNZXNzYWdlUG9wdXAoX2EpIHtcbiAgICB2YXIgcGxhdGZvcm0gPSBfYS5wbGF0Zm9ybSwgdGl0bGUgPSBfYS50aXRsZSwgbWVzc2FnZSA9IF9hLm1lc3NhZ2UsIGNsYXNzTmFtZSA9IF9hLmNsYXNzTmFtZSwgcHJpbWFyeSA9IF9hLnByaW1hcnksIHNlY29uZGFyeSA9IF9hLnNlY29uZGFyeSwgcHJpbWFyeV9saW5rID0gX2EucHJpbWFyeV9saW5rLCBnb3RvX2J1dHRvbiA9IF9hLmdvdG9fYnV0dG9uLCBnb3RvX2xpbmsgPSBfYS5nb3RvX2xpbms7XG4gICAgdmFyIGFyZ3MgPSAoMCwgdXRpbHNfMS5vYmpUb1VybFBhcm1zKShfX2Fzc2lnbihfX2Fzc2lnbih7IHU6ICcxJywgcDogcGxhdGZvcm0gIT09IG51bGwgJiYgcGxhdGZvcm0gIT09IHZvaWQgMCA/IHBsYXRmb3JtIDogJ2xpJywgdGl0bGU6IGVuY29kZVVSSUNvbXBvbmVudCh0aXRsZSksIG1lc3NhZ2U6IGVuY29kZVVSSUNvbXBvbmVudChtZXNzYWdlKSwgcHJpbWFyeTogZW5jb2RlVVJJQ29tcG9uZW50KHByaW1hcnkgIT09IG51bGwgJiYgcHJpbWFyeSAhPT0gdm9pZCAwID8gcHJpbWFyeSA6ICcnKSwgc2Vjb25kYXJ5OiBlbmNvZGVVUklDb21wb25lbnQoc2Vjb25kYXJ5ICE9PSBudWxsICYmIHNlY29uZGFyeSAhPT0gdm9pZCAwID8gc2Vjb25kYXJ5IDogJycpIH0sIChwcmltYXJ5X2xpbmsgPyB7IHByaW1hcnlfbGluazogZW5jb2RlVVJJQ29tcG9uZW50KHByaW1hcnlfbGluaykgfSA6IHt9KSksIChnb3RvX2J1dHRvbiA/IHsgZ290b19idXR0b246IGdvdG9fYnV0dG9uLCBnb3RvX2xpbms6IGVuY29kZVVSSUNvbXBvbmVudChnb3RvX2xpbmsgIT09IG51bGwgJiYgZ290b19saW5rICE9PSB2b2lkIDAgPyBnb3RvX2xpbmsgOiAnJykgfSA6IHt9KSkpO1xuICAgIHZhciBwb3B1cFdpZGdldCA9IHJvb3RfMS5teXNvbWUuY3JlYXRlUG9wdXAoXCJ3aWRnZXQvaW5kZXguaHRtbFwiLCBcIiMvbWVzc2FnZT9cIi5jb25jYXQoYXJncyksIHtcbiAgICAgICAgY2xvc2VPbkJnQ2xpY2s6IHRydWUsXG4gICAgICAgIC8vIGJnQ29sb3I6ICd0cmFuc3BhcmVudCcsXG4gICAgfSwgY2xhc3NOYW1lICE9PSBudWxsICYmIGNsYXNzTmFtZSAhPT0gdm9pZCAwID8gY2xhc3NOYW1lIDogJ3BvcHVwJyk7XG4gICAgcmV0dXJuIHBvcHVwV2lkZ2V0O1xufVxuZXhwb3J0cy5zaG93TWVzc2FnZVBvcHVwID0gc2hvd01lc3NhZ2VQb3B1cDtcbmZ1bmN0aW9uIHNob3dMb2FkaW5nUG9wdXAocGFyYW1zKSB7XG4gICAgdmFyIF9hID0gcGFyYW1zLnRpdGxlLCB0aXRsZSA9IF9hID09PSB2b2lkIDAgPyAnTG9hZGluZycgOiBfYSwgX2IgPSBwYXJhbXMubWVzc2FnZSwgbWVzc2FnZSA9IF9iID09PSB2b2lkIDAgPyAnQ2hhbmdpbmcgeW91ciBiYWNrZ3JvdW5kJyA6IF9iLCBfYyA9IHBhcmFtcy5iZ0NvbG9yLCBiZ0NvbG9yID0gX2MgPT09IHZvaWQgMCA/ICd0cmFuc3BhcmVudCcgOiBfYztcbiAgICB2YXIgYXJncyA9ICgwLCB1dGlsc18xLm9ialRvVXJsUGFybXMpKHtcbiAgICAgICAgdTogJzEnLFxuICAgICAgICBwOiAnbGknLFxuICAgICAgICB0aXRsZTogdGl0bGUsXG4gICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXG4gICAgICAgIHByaW1hcnk6IG51bGwsXG4gICAgICAgIGxvYWRpbmc6ICcxJyxcbiAgICAgICAgc2Vjb25kYXJ5OiBudWxsLFxuICAgIH0pO1xuICAgIHJldHVybiByb290XzEubXlzb21lLmNyZWF0ZVBvcHVwKFwid2lkZ2V0L2luZGV4Lmh0bWxcIiwgXCIjL21lc3NhZ2U/XCIuY29uY2F0KGFyZ3MpLCB7XG4gICAgICAgIGNsb3NlT25CZ0NsaWNrOiBmYWxzZSxcbiAgICAgICAgYmdDb2xvcjogYmdDb2xvclxuICAgIH0pO1xufVxuZXhwb3J0cy5zaG93TG9hZGluZ1BvcHVwID0gc2hvd0xvYWRpbmdQb3B1cDtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5teXNvbWUgPSBleHBvcnRzLmNyZWF0ZVJvb3RXaWRnZXQgPSBleHBvcnRzLmdldFJvb3RXaWRnZXQgPSB2b2lkIDA7XG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xudmFyIHRvdXJfMSA9IHJlcXVpcmUoXCIuL3RvdXJcIik7XG52YXIgZnJhbWVfMSA9IHJlcXVpcmUoXCIuL2ZyYW1lXCIpO1xudmFyIHBvcHVwXzEgPSByZXF1aXJlKFwiLi9wb3B1cFwiKTtcbnZhciBzaGllbGRfMSA9IHJlcXVpcmUoXCIuL3NoaWVsZFwiKTtcbi8qaW1wb3J0IHtcbiAgICAvLyBQb3B1cFdpZGdldCxcbiAgICBwb3B1cFdpZGdldCBhcyBjcmVhdGVQb3B1cFdpZGdldCxcbn0gZnJvbSAnLi9wb3B1cCc7KiovXG52YXIgYmFkZ2VfMSA9IHJlcXVpcmUoXCIuL2JhZGdlXCIpO1xudmFyIGNvbnRlbnRfbWVzc2FnaW5nXzEgPSByZXF1aXJlKFwiLi9jb250ZW50LW1lc3NhZ2luZ1wiKTtcbnZhciBpbnN0YW5jZSA9IG51bGw7XG52YXIgZ2V0Um9vdFdpZGdldCA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIWluc3RhbmNlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHJvb3RcIik7XG4gICAgfVxuICAgIHJldHVybiBpbnN0YW5jZTtcbn07XG5leHBvcnRzLmdldFJvb3RXaWRnZXQgPSBnZXRSb290V2lkZ2V0O1xudmFyIGNyZWF0ZVJvb3RXaWRnZXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgY29uc29sZS5sb2coXCJjcmVhdGluZyByb290XCIpO1xuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG4gICAgfVxuICAgIHZhciByb290ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtcm9vdFwiKTtcbiAgICBpZiAoIXJvb3QpIHtcbiAgICAgICAgcm9vdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICByb290LmlkID0gXCJteXNvbWUtcm9vdFwiO1xuICAgICAgICByb290LmlubmVySFRNTCA9IFwiXFxuXFx0XFx0XFx0PHN0eWxlPlxcblxcdFxcdFxcdDwvc3R5bGU+XFxuXFx0XFx0XFx0PGRpdiBpZD1cXFwibXlzb21lLWR1bW15XFxcIj48L2Rpdj5cXG5cXHRcXHRcIjtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChyb290KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHV0aWxzXzEubG9nZ2VyLmVycm9yKFwiUm9vdCBlbGVtZW50IGFscmVhZHkgZXhpc3RlZCEgVGhpcyBtYXkgbWFrZSB0aGUgcGx1Z2luIHN0b3Agd29ya2luZy5cIik7XG4gICAgfVxuICAgIGluc3RhbmNlID0ge1xuICAgICAgICBlbGVtZW50czoge1xuICAgICAgICAgICAgcm9vdDogcm9vdCxcbiAgICAgICAgfSxcbiAgICAgICAgbWV0aG9kczoge1xuICAgICAgICAgICAgY3JlYXRlVG91cldpZGdldDogdG91cl8xLmNyZWF0ZVRvdXJXaWRnZXQsXG4gICAgICAgICAgICBjcmVhdGVGcmFtZVdpZGdldDogZnJhbWVfMS5jcmVhdGVGcmFtZVdpZGdldCxcbiAgICAgICAgICAgIGNyZWF0ZVBvcHVwV2lkZ2V0OiBwb3B1cF8xLmNyZWF0ZVBvcHVwLFxuICAgICAgICAgICAgY3JlYXRlU2hpZWxkV2lkZ2V0OiBzaGllbGRfMS5jcmVhdGVTaGllbGRXaWRnZXQsXG4gICAgICAgIH0sXG4gICAgfTtcbiAgICB3aW5kb3cubXlzb21laWQgPSBpbnN0YW5jZTtcbiAgICBjb25zb2xlLmxvZyhcIkNyZWF0ZWQgcm9vdFwiKTtcbiAgICByZXR1cm4gaW5zdGFuY2U7XG59O1xuZXhwb3J0cy5jcmVhdGVSb290V2lkZ2V0ID0gY3JlYXRlUm9vdFdpZGdldDtcbnZhciBvblBsYXRmb3JtT2JzZXJ2ZWQgPSBmdW5jdGlvbiAocGxhdGZvcm0sIHVzZXJOYW1lKSB7XG4gICAgdmFyIG1lc3NhZ2VIYW5kbGVyID0gKDAsIGNvbnRlbnRfbWVzc2FnaW5nXzEuZ2V0TWVzc2FnZUhhbmRsZXIpKCk7XG4gICAgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoJ2JhY2tncm91bmQnLCAnc2V0LXBsYXRmb3JtLW9ic2VydmVkJywge1xuICAgICAgICBwbGF0Zm9ybTogcGxhdGZvcm0sXG4gICAgICAgIHVzZXJJZDogdXNlck5hbWUsXG4gICAgfSkudGhlbigpLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xufTtcbmV4cG9ydHMubXlzb21lID0ge1xuICAgIHdpZGdldHM6IHt9LFxuICAgIGNyZWF0ZVRvdXI6IHRvdXJfMS5jcmVhdGVUb3VyLFxuICAgIGVuZFRvdXI6IHRvdXJfMS5lbmRUb3VyLFxuICAgIGNyZWF0ZVBvcHVwOiBwb3B1cF8xLmNyZWF0ZVBvcHVwLFxuICAgIGNyZWF0ZVNoaWVsZDogc2hpZWxkXzEuY3JlYXRlU2hpZWxkV2lkZ2V0LFxuICAgIGNyZWF0ZUJhZGdlOiBiYWRnZV8xLmNyZWF0ZUJhZGdlLFxuICAgIHRvdXI6IG51bGwsXG4gICAgcmVnczogbnVsbCxcbiAgICBvblBsYXRmb3JtT2JzZXJ2ZWQ6IG9uUGxhdGZvcm1PYnNlcnZlZCxcbiAgICBwbGF0Zm9ybTogJ2xpJyxcbn07XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuY3JlYXRlU2hpZWxkV2lkZ2V0ID0gdm9pZCAwO1xudmFyIHV0aWxzXzEgPSByZXF1aXJlKFwiLi91dGlsc1wiKTtcbnZhciBjcmVhdGVTaGllbGRXaWRnZXQgPSBmdW5jdGlvbiAobmFtZUVsZW1lbnQsIF9hKSB7XG4gICAgdmFyIG9uQ2xpY2tlZCA9IF9hLm9uQ2xpY2tlZDtcbiAgICB2YXIgcmVzb2x2ZVJvb3RDaGlsZHJlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteXNvbWUtc2hpZWxkLWNvbnRhaW5lcicpO1xuICAgICAgICB2YXIgc2hpZWxkID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ215c29tZS1zaGllbGQtd2lkZ2V0Jyk7XG4gICAgICAgIHZhciBkb3RzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ215c29tZS1zaGllbGQtZG90cycpO1xuICAgICAgICB2YXIgY2hlY2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlzb21lLXNoaWVsZC1jaGVjaycpO1xuICAgICAgICB2YXIgdG9vbHRpcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteXNvbWUtc2hpZWxkLXRvb2x0aXAnKTtcbiAgICAgICAgdmFyIGV4Y2xhaW0gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlzb21lLXNoaWVsZC1leGNsYWltJyk7XG4gICAgICAgIC8qY29uc29sZS5sb2coe1xuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgc2hpZWxkLFxuICAgICAgICAgICAgZG90cyxcbiAgICAgICAgICAgIGNoZWNrLFxuICAgICAgICAgICAgdG9vbHRpcCxcbiAgICAgICAgfSk7Ki9cbiAgICAgICAgaWYgKCFjb250YWluZXIgfHwgIWRvdHMgfHwgIXNoaWVsZCB8fCAhY2hlY2sgfHwgIXRvb2x0aXAgfHwgIWV4Y2xhaW0pIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignbXlzb21laWQ6IEZhaWxlZCB0byBpbmplY3QgdGhlIG15c29tZS5pZCBleHRlbnNpb24gdG8gcHJvZmlsZSBwYWdlJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbnRhaW5lcjogY29udGFpbmVyLFxuICAgICAgICAgICAgc2hpZWxkOiBzaGllbGQsXG4gICAgICAgICAgICBkb3RzOiBkb3RzLFxuICAgICAgICAgICAgY2hlY2s6IGNoZWNrLFxuICAgICAgICAgICAgdG9vbHRpcDogdG9vbHRpcCxcbiAgICAgICAgICAgIGV4Y2xhaW06IGV4Y2xhaW0sXG4gICAgICAgIH07XG4gICAgfTtcbiAgICB2YXIgc2hpZWxkQ29sb3JMb2FkaW5nID0gJyNiOWI5YjknO1xuICAgIHZhciBzaGllbGRDb2xvclZlcmlmaWVkID0gJyM0ZGEzZjgnO1xuICAgIC8vIGNvbnN0IHNoaWVsZENvbG9yTm90VmVyaWZpZWQgPSAnI2Y4YjI0ZCc7XG4gICAgdmFyIHNoaWVsZENvbG9yWWVsbG93ID0gJ3JnYigxNzEgMTI3IDApJztcbiAgICB2YXIgc2hpZWxkQ29sb3JSZWQgPSAnI0Q1NjQ1RCc7XG4gICAgdmFyIGRvdHNMZWZ0T2Zmc2V0ID0gNjtcbiAgICB2YXIgZG90c1dIID0gNDtcbiAgICB2YXIgZG90c1JhZGl1cyA9IDI7XG4gICAgdmFyIGRvdHNDb2xvciA9ICcjMDAwMDAwJztcbiAgICB2YXIgZG90c0FuaW1Db2xvciA9ICdyZ2JhKDAsIDAsIDAsIDAuMiknO1xuICAgIHZhciB0b29sdGlwVGV4dFZlcmlmaWVkID0gJ215c29tZS5pZDo8L2JyPjwvYnI+UHJvZmlsZSBWZXJpZmllZCc7XG4gICAgdmFyIHRvb2x0aXBUZXh0T3duUHJvZmlsZVZlcmlmaWVkID0gJ215c29tZS5pZDwvYnI+PC9icj5Zb3VyIHByb2ZpbGUgaXMgc2VjdXJlJztcbiAgICB2YXIgdG9vbHRpcFRleHROb3RWZXJpZmllZCA9ICdteXNvbWUuaWQ8L2JyPjwvYnI+UHJvZmlsZSBOT1QgdmVyaWZpZWQnO1xuICAgIHZhciB0b29sdGlwVGV4dE93blByb2ZpbGVOb3RWZXJpZmllZCA9ICdteXNvbWUuaWQ8L2JyPjwvYnI+WW91IGFyZSBub3Qgc2VjdXJlZDwvYnI+PC9icj5DbGljayB0byBnZXQgc3RhcnRlZCc7XG4gICAgdmFyIHRvb2x0aXBUZXh0T3RoZXJQcm9maWxlTm90VmVyaWZpZWQgPSAnbXlzb21lLmlkPC9icj48L2JyPlRoaXMgcHJvZmlsZSBpcyBub3QgdmVyaWZpZWQuPC9icj4nO1xuICAgIHZhciB0b29sdGlwVGV4dE5vQ29ubmVjdGlvbiA9ICdteXNvbWUuaWQ8L2JyPjwvYnI+Tm8gQ29ubmVjdGlvbjwvYnI+JztcbiAgICB2YXIgc3RhdGU7XG4gICAgdmFyIGNyZWF0ZWQgPSBmYWxzZTtcbiAgICB2YXIgcHJvb2ZVcmwgPSAnJztcbiAgICBpZiAoIWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteXNvbWUtc2hpZWxkLXJvb3QnKSkge1xuICAgICAgICB2YXIgc2hpZWxkU2hhcGUgPSAnZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQRDk0Yld3Z2RtVnljMmx2YmowaU1TNHdJaUJsYm1OdlpHbHVaejBpVlZSR0xUZ2lQejRLUEhOMlp5QjNhV1IwYUQwaU1qTndlQ0lnYUdWcFoyaDBQU0l5TTNCNElpQjJhV1YzUW05NFBTSXdJREFnTWpNZ01qTWlJSFpsY25OcGIyNDlJakV1TVNJZ2VHMXNibk05SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpJd01EQXZjM1puSWlCNGJXeHVjenA0YkdsdWF6MGlhSFIwY0RvdkwzZDNkeTUzTXk1dmNtY3ZNVGs1T1M5NGJHbHVheUkrQ2lBZ0lDQThaeUJwWkQwaVUzbHRZbTlzY3lJZ2MzUnliMnRsUFNKdWIyNWxJaUJ6ZEhKdmEyVXRkMmxrZEdnOUlqRWlJR1pwYkd3OUltNXZibVVpSUdacGJHd3RjblZzWlQwaVpYWmxibTlrWkNJK0NpQWdJQ0FnSUNBZ1BHY2dhV1E5SW5Ob2FXVnNaQ0lnZEhKaGJuTm1iM0p0UFNKMGNtRnVjMnhoZEdVb0xURXVNREF3TURBd0xDQXRNUzR3TURBd01EQXBJaUJtYVd4c1BTSWpSRGhFT0VRNElqNEtJQ0FnSUNBZ0lDQWdJQ0FnUEdjZ2FXUTlJazkyWVd3aVBnb2dJQ0FnSUNBZ0lDQWdJQ0FnSUNBZ1BHVnNiR2x3YzJVZ1kzZzlJakV5TGpVaUlHTjVQU0l4TWk0MUlpQnllRDBpTVRFdU5TSWdjbms5SWpFeElqNDhMMlZzYkdsd2MyVStDaUFnSUNBZ0lDQWdJQ0FnSUR3dlp6NEtJQ0FnSUNBZ0lDQThMMmMrQ2lBZ0lDQThMMmMrQ2p3dmMzWm5QZz09JztcbiAgICAgICAgdmFyIGNoZWNrbWFya1N2ZyA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQRDk0Yld3Z2RtVnljMmx2YmowaU1TNHdJaUJsYm1OdlpHbHVaejBpVlZSR0xUZ2lQejRLUEhOMlp5QjNhV1IwYUQwaU1UTndlQ0lnYUdWcFoyaDBQU0l4TVhCNElpQjJhV1YzUW05NFBTSXdJREFnTVRNZ01URWlJSFpsY25OcGIyNDlJakV1TVNJZ2VHMXNibk05SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpJd01EQXZjM1puSWlCNGJXeHVjenA0YkdsdWF6MGlhSFIwY0RvdkwzZDNkeTUzTXk1dmNtY3ZNVGs1T1M5NGJHbHVheUkrQ2lBZ0lDQThJUzB0SUVkbGJtVnlZWFJ2Y2pvZ1UydGxkR05vSURVMUxqSWdLRGM0TVRneEtTQXRJR2gwZEhCek9pOHZjMnRsZEdOb1lYQndMbU52YlNBdExUNEtJQ0FnSUR4MGFYUnNaVDUyWlhKcFptbGxaQzExYzJWeUxYTm9hV1ZzWkMxamFHVmpheUJqYjNCNUlESThMM1JwZEd4bFBnb2dJQ0FnUEdSbGMyTStRM0psWVhSbFpDQjNhWFJvSUZOclpYUmphQzQ4TDJSbGMyTStDaUFnSUNBOFp5QnBaRDBpVUdGblpTMHhJaUJ6ZEhKdmEyVTlJbTV2Ym1VaUlITjBjbTlyWlMxM2FXUjBhRDBpTVNJZ1ptbHNiRDBpYm05dVpTSWdabWxzYkMxeWRXeGxQU0psZG1WdWIyUmtJajRLSUNBZ0lDQWdJQ0E4WnlCcFpEMGlkbVZ5YVdacFpXUXRkWE5sY2kxemFHbGxiR1F0WTJobFkyc3RZMjl3ZVMweUlpQjBjbUZ1YzJadmNtMDlJblJ5WVc1emJHRjBaU2d0Tmk0d01EQXdNREFzSUMwM0xqQXdNREF3TUNraVBnb2dJQ0FnSUNBZ0lDQWdJQ0E4Y0c5c2VXZHZiaUJwWkQwaVVHRjBhQ0lnY0c5cGJuUnpQU0l3SURBZ01qVWdNQ0F5TlNBeU5TQXdJREkxSWo0OEwzQnZiSGxuYjI0K0NpQWdJQ0FnSUNBZ0lDQWdJRHh3YjJ4NVoyOXVJR2xrUFNKVGFHRndaU0lnWm1sc2JEMGlJekpFTWtReVJDSWdabWxzYkMxeWRXeGxQU0p1YjI1NlpYSnZJaUJ3YjJsdWRITTlJakV3TGpReE5qWTJOamNnTVRjdU56QTRNek16TXlBMkxqSTFJREV6TGpVME1UWTJOamNnTnk0M01UZzNOU0F4TWk0d056STVNVFkzSURFd0xqUXhOalkyTmpjZ01UUXVOell3TkRFMk55QXhOeTR5T0RFeU5TQTNMamc1TlRnek16TXpJREU0TGpjMUlEa3VNemMxSWo0OEwzQnZiSGxuYjI0K0NpQWdJQ0FnSUNBZ1BDOW5QZ29nSUNBZ1BDOW5QZ284TDNOMlp6ND1cIjtcbiAgICAgICAgdmFyIGV4Y2xhaW1hdGlvblN2ZyA9ICdkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LFBEOTRiV3dnZG1WeWMybHZiajBpTVM0d0lpQmxibU52WkdsdVp6MGlWVlJHTFRnaVB6NEtQSE4yWnlCM2FXUjBhRDBpTTNCNElpQm9aV2xuYUhROUlqRTBjSGdpSUhacFpYZENiM2c5SWpBZ01DQXpJREUwSWlCMlpYSnphVzl1UFNJeExqRWlJSGh0Ykc1elBTSm9kSFJ3T2k4dmQzZDNMbmN6TG05eVp5OHlNREF3TDNOMlp5SWdlRzFzYm5NNmVHeHBibXM5SW1oMGRIQTZMeTkzZDNjdWR6TXViM0puTHpFNU9Ua3ZlR3hwYm1zaVBnb2dJQ0FnUENFdExTQkhaVzVsY21GMGIzSTZJRk5yWlhSamFDQTFOUzR5SUNnM09ERTRNU2tnTFNCb2RIUndjem92TDNOclpYUmphR0Z3Y0M1amIyMGdMUzArQ2lBZ0lDQThkR2wwYkdVK1pYaGpiR0ZwYldGMGFXOXVQQzkwYVhSc1pUNEtJQ0FnSUR4a1pYTmpQa055WldGMFpXUWdkMmwwYUNCVGEyVjBZMmd1UEM5a1pYTmpQZ29nSUNBZ1BHY2dhV1E5SWxCaFoyVXRNU0lnYzNSeWIydGxQU0p1YjI1bElpQnpkSEp2YTJVdGQybGtkR2c5SWpFaUlHWnBiR3c5SW01dmJtVWlJR1pwYkd3dGNuVnNaVDBpWlhabGJtOWtaQ0krQ2lBZ0lDQWdJQ0FnUEdjZ2FXUTlJbVY0WTJ4aGFXMWhkR2x2YmlJZ2RISmhibk5tYjNKdFBTSjBjbUZ1YzJ4aGRHVW9MVEV4TGpBd01EQXdNQ3dnTFRZdU1EQXdNREF3S1NJK0NpQWdJQ0FnSUNBZ0lDQWdJRHh3YjJ4NVoyOXVJR2xrUFNKUVlYUm9JaUJtYVd4c1BTSWpSa1pHUmtaR0lpQnZjR0ZqYVhSNVBTSXdJaUJ3YjJsdWRITTlJakFnTUNBeU5TQXdJREkxSURJMUlEQWdNalVpUGp3dmNHOXNlV2R2Ymo0S0lDQWdJQ0FnSUNBZ0lDQWdQSEJ2YkhsbmIyNGdhV1E5SWxOb1lYQmxJaUJtYVd4c1BTSWpSRGhFT0VRNElpQm1hV3hzTFhKMWJHVTlJbTV2Ym5wbGNtOGlJSFJ5WVc1elptOXliVDBpZEhKaGJuTnNZWFJsS0RFeUxqUTVNall5Tml3Z01UQXVPVE16TURjM0tTQnliM1JoZEdVb0xUUTFMakF3TURBd01Da2dkSEpoYm5Oc1lYUmxLQzB4TWk0ME9USTJNallzSUMweE1DNDVNek13TnpjcElDSWdjRzlwYm5SelBTSTVMalV4T0RRM016UWdNVFV1TVRreU1URTBNaUE0TGpFM09EYzJNekUwSURFekxqZzFNalF3TXprZ01UUXVOekk1TlRZMk5TQTJMalkzTkRBME1EVTRJREUyTGpnd05qUTRPU0E0TGpjMU1EazJNekE1SWo0OEwzQnZiSGxuYjI0K0NpQWdJQ0FnSUNBZ0lDQWdJRHhqYVhKamJHVWdhV1E5SWs5MllXd2lJR1pwYkd3OUlpTkVPRVE0UkRnaUlHTjRQU0l4TWk0MUlpQmplVDBpTVRndU5TSWdjajBpTVM0MUlqNDhMMk5wY21Oc1pUNEtJQ0FnSUNBZ0lDQThMMmMrQ2lBZ0lDQThMMmMrQ2p3dmMzWm5QZz09JztcbiAgICAgICAgdmFyIHZlcmlmaWVkRWxlbSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICB2ZXJpZmllZEVsZW0uc3R5bGUubWFyZ2luTGVmdCA9ICcxMHB4JztcbiAgICAgICAgdmVyaWZpZWRFbGVtLnN0eWxlLmRpc3BsYXkgPSAnaW5saW5lJztcbiAgICAgICAgdmVyaWZpZWRFbGVtLmlkID0gJ215c29tZS1zaGllbGQtcm9vdCc7XG4gICAgICAgIHZlcmlmaWVkRWxlbS5pbm5lckhUTUwgPSBcIlxcblxcdFxcdFxcdDxzdHlsZT5cXG5cXHRcXHRcXHRcXHQjbXlzb21lLXNoaWVsZC1kb3RzIHtcXG5cXHRcXHRcXHRcXHRcXHRwb3NpdGlvbjogcmVsYXRpdmU7XFxuXFx0XFx0XFx0XFx0XFx0d2lkdGg6IFwiLmNvbmNhdChkb3RzV0gsIFwicHg7XFxuXFx0XFx0XFx0XFx0XFx0aGVpZ2h0OiBcIikuY29uY2F0KGRvdHNXSCwgXCJweDtcXG5cXHRcXHRcXHRcXHRcXHRib3JkZXItcmFkaXVzOiBcIikuY29uY2F0KGRvdHNSYWRpdXMsIFwicHg7XFxuXFx0XFx0XFx0XFx0XFx0YmFja2dyb3VuZC1jb2xvcjogXCIpLmNvbmNhdChkb3RzQ29sb3IsIFwiO1xcblxcdFxcdFxcdFxcdFxcdGNvbG9yOiBcIikuY29uY2F0KGRvdHNDb2xvciwgXCI7XFxuXFx0XFx0XFx0XFx0XFx0YW5pbWF0aW9uOiBteXNvbWUtc2hpZWxkLWRvdHMgMXMgaW5maW5pdGUgbGluZWFyIGFsdGVybmF0ZTtcXG5cXHRcXHRcXHRcXHRcXHRhbmltYXRpb24tZGVsYXk6IDAuNXM7XFxuXFx0XFx0XFx0XFx0fVxcblxcdFxcblxcdFxcdFxcdFxcdCNteXNvbWUtc2hpZWxkLWRvdHM6OmJlZm9yZSwgI215c29tZS1zaGllbGQtZG90czo6YWZ0ZXIge1xcblxcdFxcdFxcdFxcdFxcdGNvbnRlbnQ6IFxcXCJcXFwiO1xcblxcdFxcdFxcdFxcdFxcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcXG5cXHRcXHRcXHRcXHRcXHRwb3NpdGlvbjogYWJzb2x1dGU7XFxuXFx0XFx0XFx0XFx0XFx0dG9wOiAwO1xcblxcdFxcdFxcdFxcdH1cXG5cXHRcXG5cXHRcXHRcXHRcXHQjbXlzb21lLXNoaWVsZC1kb3RzOjpiZWZvcmUge1xcblxcdFxcdFxcdFxcdFxcdGxlZnQ6IC1cIikuY29uY2F0KGRvdHNMZWZ0T2Zmc2V0LCBcInB4O1xcblxcdFxcdFxcdFxcdFxcdHdpZHRoOiBcIikuY29uY2F0KGRvdHNXSCwgXCJweDtcXG5cXHRcXHRcXHRcXHRcXHRoZWlnaHQ6IFwiKS5jb25jYXQoZG90c1dILCBcInB4O1xcblxcdFxcdFxcdFxcdFxcdGJvcmRlci1yYWRpdXM6IFwiKS5jb25jYXQoZG90c1JhZGl1cywgXCJweDtcXG5cXHRcXHRcXHRcXHRcXHRiYWNrZ3JvdW5kLWNvbG9yOiBcIikuY29uY2F0KGRvdHNDb2xvciwgXCI7XFxuXFx0XFx0XFx0XFx0XFx0Y29sb3I6IFwiKS5jb25jYXQoZG90c0NvbG9yLCBcIjtcXG5cXHRcXHRcXHRcXHRcXHRhbmltYXRpb246IG15c29tZS1zaGllbGQtZG90cyAxcyBpbmZpbml0ZSBhbHRlcm5hdGU7XFxuXFx0XFx0XFx0XFx0XFx0YW5pbWF0aW9uLWRlbGF5OiAwcztcXG5cXHRcXHRcXHRcXHR9XFxuXFx0XFxuXFx0XFx0XFx0XFx0I215c29tZS1zaGllbGQtZG90czo6YWZ0ZXIge1xcblxcdFxcdFxcdFxcdFxcdGxlZnQ6IFwiKS5jb25jYXQoZG90c0xlZnRPZmZzZXQsIFwicHg7XFxuXFx0XFx0XFx0XFx0XFx0d2lkdGg6IFwiKS5jb25jYXQoZG90c1dILCBcInB4O1xcblxcdFxcdFxcdFxcdFxcdGhlaWdodDogXCIpLmNvbmNhdChkb3RzV0gsIFwicHg7XFxuXFx0XFx0XFx0XFx0XFx0Ym9yZGVyLXJhZGl1czogXCIpLmNvbmNhdChkb3RzUmFkaXVzLCBcInB4O1xcblxcdFxcdFxcdFxcdFxcdGJhY2tncm91bmQtY29sb3I6IFwiKS5jb25jYXQoZG90c0NvbG9yLCBcIjtcXG5cXHRcXHRcXHRcXHRcXHRjb2xvcjogXCIpLmNvbmNhdChkb3RzQ29sb3IsIFwiO1xcblxcdFxcdFxcdFxcdFxcdGFuaW1hdGlvbjogbXlzb21lLXNoaWVsZC1kb3RzIDFzIGluZmluaXRlIGFsdGVybmF0ZTtcXG5cXHRcXHRcXHRcXHRcXHRhbmltYXRpb24tZGVsYXk6IDFzO1xcblxcdFxcdFxcdFxcdH1cXG5cXG5cXHRcXHRcXHRcXHRAa2V5ZnJhbWVzIG15c29tZS1zaGllbGQtZG90cyB7XFxuXFx0XFx0XFx0XFx0XFx0MCUge1xcblxcdFxcdFxcdFxcdFxcdFxcdGJhY2tncm91bmQtY29sb3I6IFwiKS5jb25jYXQoZG90c0NvbG9yLCBcIjtcXG5cXHRcXHRcXHRcXHRcXHR9XFxuXFx0XFx0XFx0XFx0XFx0NTAlLCAxMDAlIHtcXG5cXHRcXHRcXHRcXHRcXHRcXHRiYWNrZ3JvdW5kLWNvbG9yOiBcIikuY29uY2F0KGRvdHNBbmltQ29sb3IsIFwiO1xcblxcdFxcdFxcdFxcdFxcdH1cXG5cXHRcXHRcXHRcXHR9XFxuXFxuXFx0XFx0XFx0XFx0I215c29tZS1zaGllbGQtY29udGFpbmVyICNteXNvbWUtc2hpZWxkLXRvb2x0aXAge1xcblxcdFxcdFxcdFxcdFxcdHZpc2liaWxpdHk6IGhpZGRlbjtcXG5cXHRcXHRcXHRcXHRcXHR3aWR0aDogMjAwcHg7XFxuXFx0XFx0XFx0XFx0XFx0YmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XFxuXFx0XFx0XFx0XFx0XFx0Y29sb3I6ICNmZmY7XFxuXFx0XFx0XFx0XFx0XFx0cGFkZGluZzogNXB4O1xcblxcdFxcdFxcdFxcdFxcdGJvcmRlci1yYWRpdXM6IDRweDtcXG5cXHRcXHRcXHRcXHRcXHRib3R0b206IDExMSU7XFxuXFx0XFx0XFx0XFx0XFx0bWFyZ2luLWxlZnQ6IC04N3B4O1xcblxcdFxcdFxcdFxcdFxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG5cXHRcXHRcXHRcXHRcXHR6LWluZGV4OiA5OTk5O1xcblxcdFxcdFxcdFxcdFxcdGZvbnQtc2l6ZTogMTRweDtcXG5cXHRcXHRcXHRcXHRcXHRtaW4taGVpZ2h0OiA2MHB4O1xcblxcdFxcdFxcdFxcdFxcdHRleHQtYWxpZ246IGNlbnRlcjtcXG5cXHRcXHRcXHRcXHRcXHRkaXNwbGF5OiBmbGV4O1xcblxcdFxcdFxcdFxcdFxcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuXFx0XFx0XFx0XFx0XFx0Y3Vyc29yOiBwb2ludGVyO1xcblxcdFxcdFxcdFxcdH1cXG5cXHRcXG5cXHRcXHRcXHRcXHQjbXlzb21lLXNoaWVsZC1jb250YWluZXIgI215c29tZS1zaGllbGQtdG9vbHRpcDo6YWZ0ZXIge1xcblxcdFxcdFxcdFxcdFxcdGNvbnRlbnQ6IFxcXCJcXFwiO1xcblxcdFxcdFxcdFxcdFxcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG5cXHRcXHRcXHRcXHRcXHR0b3A6IDEwMCU7XFxuXFx0XFx0XFx0XFx0XFx0bGVmdDogNTAlO1xcblxcdFxcdFxcdFxcdFxcdG1hcmdpbi1sZWZ0OiAtOXB4O1xcblxcdFxcdFxcdFxcdFxcdGJvcmRlci13aWR0aDogOHB4O1xcdFxcdFxcdFxcblxcdFxcdFxcdFxcdFxcdGJvcmRlci1zdHlsZTogc29saWQ7XFxuXFx0XFx0XFx0XFx0XFx0Ym9yZGVyLWNvbG9yOiAjMDAwIHRyYW5zcGFyZW50IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50O1xcblxcdFxcdFxcdFxcdH1cXG5cXHRcXG5cXHRcXHRcXHRcXHQjbXlzb21lLXNoaWVsZC1jb250YWluZXI6aG92ZXIgI215c29tZS1zaGllbGQtdG9vbHRpcCB7XFxuXFx0XFx0XFx0XFx0XFx0dmlzaWJpbGl0eTogdmlzaWJsZTtcXG5cXHRcXHRcXHRcXHR9XFxuXFx0XFxuXFx0XFx0XFx0PC9zdHlsZT5cXG5cXHRcXG5cXHRcXHRcXHQ8ZGl2IGlkPVxcXCJteXNvbWUtc2hpZWxkLWNvbnRhaW5lclxcXCIgc3R5bGU9XFxcImhlaWdodDogMjhweDt3aWR0aDogMXB4OyBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IFxcXCI+XFxuXFx0XFx0XFx0XFx0PGRpdiBpZD1cXFwibXlzb21lLXNoaWVsZC13aWRnZXRcXFwiIHN0eWxlPVxcXCJ3aWR0aDogMjVweDtoZWlnaHQ6IDI4cHg7bWFyZ2luLXRvcDogOHB4O2Rpc3BsYXk6IGJsb2NrOy13ZWJraXQtbWFzay1pbWFnZTogdXJsKFwiKS5jb25jYXQoc2hpZWxkU2hhcGUsIFwiKTstd2Via2l0LW1hc2stcG9zaXRpb246IGNlbnRlcjstd2Via2l0LW1hc2stc2l6ZTogMjNweDtiYWNrZ3JvdW5kOiBcIikuY29uY2F0KHNoaWVsZENvbG9yTG9hZGluZywgXCI7IC13ZWJraXQtbWFzay1yZXBlYXQ6IG5vLXJlcGVhdDtcXFwiIGFsdD1cXFwiXFxcIiBzcmM9XFxcIlxcXCI+XFxuXFx0XFx0XFx0XFx0XFx0PGRpdiBpZD1cXFwibXlzb21lLXNoaWVsZC1kb3RzXFxcIiBzdHlsZT1cXFwidG9wOiAxMXB4OyBsZWZ0OiAxMHB4O1xcXCIgPjwvZGl2PlxcblxcdFxcdFxcdFxcdFxcdDxkaXYgaWQ9XFxcIm15c29tZS1zaGllbGQtY2hlY2tcXFwiIHN0eWxlPVxcXCJiYWNrZ3JvdW5kOiB1cmwoXCIpLmNvbmNhdChjaGVja21hcmtTdmcsIFwiKTt3aWR0aDogMjZweDtoZWlnaHQ6IDI3cHg7YmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XFxcIj48L2Rpdj5cXG5cXHRcXHRcXHRcXHRcXHQ8ZGl2IGlkPVxcXCJteXNvbWUtc2hpZWxkLWV4Y2xhaW1cXFwiIHN0eWxlPVxcXCJiYWNrZ3JvdW5kOiB1cmwoXCIpLmNvbmNhdChleGNsYWltYXRpb25TdmcsIFwiKTt3aWR0aDogMjVweDtoZWlnaHQ6IDI3cHg7YmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XFxcIj48L2Rpdj5cXG5cXHRcXHRcXHRcXHQ8L2Rpdj5cXG5cXHRcXHRcXHRcXHQ8ZGl2IGlkPVxcXCJteXNvbWUtc2hpZWxkLXRvb2x0aXBcXFwiPlxcblxcdFxcdFxcdFxcdFxcdDxkaXYgc3R5bGU9XFxcImRpc3BsYXk6IGZsZXg7IHdpZHRoOiAxMDAlOyBwbGFjZS1jb250ZW50OiBjZW50ZXI7XFxcIj5cXG5cXHRcXHRcXHRcXHRcXHRcXHQ8c3BhbiBpZD1cXFwibXlzb21lLXNoaWVsZC10b29sdGlwLXRleHRcXFwiPlwiKS5jb25jYXQodG9vbHRpcFRleHRWZXJpZmllZCwgXCI8L3NwYW4+XFxuXFx0XFx0XFx0XFx0XFx0PC9kaXY+XFxuXFx0XFx0XFx0XFx0PC9kaXY+XFxuXFx0XFx0XFx0XFx0PGRpdiBpZD1cXFwibXlzb21lLXNoaWVsZC1kdW1teVxcXCIgc3R5bGU9XFxcImRpc3BsYXk6IG5vbmVcXFwiPjwvZGl2PlxcblxcdFxcdFxcdDwvZGl2PlxcblxcdFxcdFwiKTtcbiAgICAgICAgbmFtZUVsZW1lbnQuYXBwZW5kQ2hpbGQodmVyaWZpZWRFbGVtKTtcbiAgICAgICAgY3JlYXRlZCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB1dGlsc18xLmxvZ2dlci5pbmZvKCdTaGllbGQ6IFJvb3QgZWxlbWVudCBhbHJlYWR5IGV4aXN0ZWQnKTtcbiAgICB9XG4gICAgdmFyIHJvb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlzb21lLXNoaWVsZC1yb290Jyk7XG4gICAgaWYgKCFyb290KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU2hpZWxkOiBObyB3aWRnZXQgZm91bmQuJyk7XG4gICAgfVxuICAgIG5hbWVFbGVtZW50LmFwcGVuZENoaWxkKHJvb3QpO1xuICAgIHZhciBfYiA9IHJlc29sdmVSb290Q2hpbGRyZW4oKSwgY29udGFpbmVyID0gX2IuY29udGFpbmVyLCBzaGllbGQgPSBfYi5zaGllbGQsIGRvdHMgPSBfYi5kb3RzLCBjaGVjayA9IF9iLmNoZWNrLCBleGNsYWltID0gX2IuZXhjbGFpbSwgdG9vbHRpcCA9IF9iLnRvb2x0aXA7XG4gICAgaWYgKGNyZWF0ZWQpIHtcbiAgICAgICAgdmFyIGhhbmRsZUNsaWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgb25DbGlja2VkKHN0YXRlLCBwcm9vZlVybCk7XG4gICAgICAgIH07XG4gICAgICAgIHRvb2x0aXAuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBoYW5kbGVDbGljayk7XG4gICAgICAgIHNoaWVsZC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGhhbmRsZUNsaWNrKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZWxlbWVudHM6IHtcbiAgICAgICAgICAgIGNvbnRhaW5lcjogY29udGFpbmVyLFxuICAgICAgICAgICAgc2hpZWxkOiBzaGllbGQsXG4gICAgICAgICAgICBkb3RzOiBkb3RzLFxuICAgICAgICAgICAgY2hlY2s6IGNoZWNrLFxuICAgICAgICAgICAgZXhjbGFpbTogZXhjbGFpbSxcbiAgICAgICAgICAgIHRvb2x0aXA6IHRvb2x0aXAsXG4gICAgICAgIH0sXG4gICAgICAgIHNldEluaXRpYWxTdGF0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc3RhdGUgPSAnbm9uZSc7XG4gICAgICAgICAgICBjaGVjay5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgZG90cy5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBzaGllbGRDb2xvckxvYWRpbmc7XG4gICAgICAgICAgICB0b29sdGlwLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuY3Vyc29yID0gJ3BvaW50ZXInO1xuICAgICAgICAgICAgZXhjbGFpbS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgcHJvb2ZVcmwgPSAnJztcbiAgICAgICAgfSxcbiAgICAgICAgc2V0Tm9Db25uZWN0aW9uOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzdGF0ZSA9ICduby1jb25uZWN0aW9uJztcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBzaGllbGRDb2xvclllbGxvdztcbiAgICAgICAgICAgIGRvdHMuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgICAgIGNoZWNrLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuY3Vyc29yID0gJ3BvaW50ZXInO1xuICAgICAgICAgICAgdG9vbHRpcC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnO1xuICAgICAgICAgICAgZXhjbGFpbS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICAgICAgICAgIHZhciBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteXNvbWUtc2hpZWxkLXRvb2x0aXAtdGV4dCcpO1xuICAgICAgICAgICAgaWYgKGVsKVxuICAgICAgICAgICAgICAgIGVsLmlubmVySFRNTCA9IHRvb2x0aXBUZXh0Tm9Db25uZWN0aW9uO1xuICAgICAgICB9LFxuICAgICAgICBzZXRPd25Qcm9maWxlTm90VmVyaWZpZWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN0YXRlID0gJ293bi1wcm9maWxlLW5vdC12ZXJpZmllZCc7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gc2hpZWxkQ29sb3JZZWxsb3c7XG4gICAgICAgICAgICBkb3RzLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBjaGVjay5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgc2hpZWxkLnN0eWxlLmN1cnNvciA9ICdwb2ludGVyJztcbiAgICAgICAgICAgIHRvb2x0aXAuc3R5bGUuZGlzcGxheSA9ICdmbGV4JztcbiAgICAgICAgICAgIGV4Y2xhaW0uc3R5bGUuZGlzcGxheSA9ICdibG9jayc7XG4gICAgICAgICAgICB2YXIgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlzb21lLXNoaWVsZC10b29sdGlwLXRleHQnKTtcbiAgICAgICAgICAgIGlmIChlbClcbiAgICAgICAgICAgICAgICBlbC5pbm5lckhUTUwgPSB0b29sdGlwVGV4dE93blByb2ZpbGVOb3RWZXJpZmllZDtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0T3RoZXJQcm9maWxlTm90VmVyaWZpZWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN0YXRlID0gJ290aGVyLXByb2ZpbGUtbm90LXZlcmlmaWVkJztcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBzaGllbGRDb2xvclllbGxvdztcbiAgICAgICAgICAgIGRvdHMuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgICAgIGNoZWNrLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuY3Vyc29yID0gJ3BvaW50ZXInO1xuICAgICAgICAgICAgdG9vbHRpcC5zdHlsZS5kaXNwbGF5ID0gJ2ZsZXgnO1xuICAgICAgICAgICAgZXhjbGFpbS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICAgICAgICAgIHZhciBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdteXNvbWUtc2hpZWxkLXRvb2x0aXAtdGV4dCcpO1xuICAgICAgICAgICAgaWYgKGVsKVxuICAgICAgICAgICAgICAgIGVsLmlubmVySFRNTCA9IHRvb2x0aXBUZXh0T3RoZXJQcm9maWxlTm90VmVyaWZpZWQ7XG4gICAgICAgIH0sXG4gICAgICAgIHNldFZlcmlmaWVkOiBmdW5jdGlvbiAoX3Byb29mVXJsLCBvd25Qcm9maWxlKSB7XG4gICAgICAgICAgICBzdGF0ZSA9ICd2ZXJpZmllZCc7XG4gICAgICAgICAgICBwcm9vZlVybCA9IF9wcm9vZlVybDtcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBzaGllbGRDb2xvclZlcmlmaWVkO1xuICAgICAgICAgICAgZG90cy5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgY2hlY2suc3R5bGUuZGlzcGxheSA9ICdibG9jayc7XG4gICAgICAgICAgICB0b29sdGlwLnN0eWxlLmRpc3BsYXkgPSAnZmxleCc7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuY3Vyc29yID0gJ3BvaW50ZXInO1xuICAgICAgICAgICAgZXhjbGFpbS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgdmFyIGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ215c29tZS1zaGllbGQtdG9vbHRpcC10ZXh0Jyk7XG4gICAgICAgICAgICBpZiAoZWwpXG4gICAgICAgICAgICAgICAgZWwuaW5uZXJIVE1MID0gb3duUHJvZmlsZSA/IHRvb2x0aXBUZXh0T3duUHJvZmlsZVZlcmlmaWVkIDogdG9vbHRpcFRleHRWZXJpZmllZDtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0U3VzcGVjaW91c1Byb2ZpbGU6IGZ1bmN0aW9uIChfcHJvb2ZVcmwpIHtcbiAgICAgICAgICAgIHN0YXRlID0gJ3N1c3BlY2lvdXMnO1xuICAgICAgICAgICAgcHJvb2ZVcmwgPSBfcHJvb2ZVcmw7XG4gICAgICAgICAgICBzaGllbGQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gc2hpZWxkQ29sb3JSZWQ7XG4gICAgICAgICAgICBkb3RzLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBjaGVjay5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgZXhjbGFpbS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcbiAgICAgICAgICAgIHRvb2x0aXAuc3R5bGUuZGlzcGxheSA9ICdmbGV4JztcbiAgICAgICAgICAgIHNoaWVsZC5zdHlsZS5jdXJzb3IgPSAncG9pbnRlcic7XG4gICAgICAgICAgICB2YXIgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbXlzb21lLXNoaWVsZC10b29sdGlwLXRleHQnKTtcbiAgICAgICAgICAgIGlmIChlbClcbiAgICAgICAgICAgICAgICBlbC5pbm5lckhUTUwgPSB0b29sdGlwVGV4dE5vdFZlcmlmaWVkO1xuICAgICAgICB9LFxuICAgICAgICBoaWRlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjb250YWluZXIuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgfSxcbiAgICAgICAgc2hvdzogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY29udGFpbmVyLnN0eWxlLmRpc3BsYXkgPSAnaW5saW5lLWJsb2NrJztcbiAgICAgICAgfSxcbiAgICAgICAgaXNMb2FkaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gc3RhdGUgPT09ICdub25lJztcbiAgICAgICAgfSxcbiAgICB9O1xufTtcbmV4cG9ydHMuY3JlYXRlU2hpZWxkV2lkZ2V0ID0gY3JlYXRlU2hpZWxkV2lkZ2V0O1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLmVuZFRvdXIgPSBleHBvcnRzLmNyZWF0ZVRvdXIgPSBleHBvcnRzLmNyZWF0ZVRvdXJXaWRnZXQgPSB2b2lkIDA7XG52YXIgdXRpbHNfMSA9IHJlcXVpcmUoXCIuL3V0aWxzXCIpO1xudmFyIHJvb3RfMSA9IHJlcXVpcmUoXCIuL3Jvb3RcIik7XG52YXIgcG9wdXBfMSA9IHJlcXVpcmUoXCIuL3BvcHVwXCIpO1xudmFyIGluc3RhbmNlO1xudmFyIHNldFN0eWxlID0gZnVuY3Rpb24gKGUsIHN0eWxlKSB7XG4gICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IE9iamVjdC5rZXlzKHN0eWxlKTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgdmFyIGtleSA9IF9hW19pXTtcbiAgICAgICAgdmFyIHZhbHVlID0gc3R5bGVba2V5XTtcbiAgICAgICAgZS5zdHlsZVtrZXldID0gdmFsdWU7XG4gICAgfVxufTtcbmZ1bmN0aW9uIGdldFdpbmRvd1NpemUoKSB7XG4gICAgdmFyIHcgPSBNYXRoLm1heChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGgsIHdpbmRvdy5pbm5lcldpZHRoIHx8IDApO1xuICAgIHZhciBoID0gTWF0aC5tYXgoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudEhlaWdodCwgd2luZG93LmlubmVySGVpZ2h0IHx8IDApO1xuICAgIHJldHVybiB7IHc6IHcsIGg6IGggfTtcbn1cbnZhciBjcmVhdGVUb3VyV2lkZ2V0ID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG4gICAgfVxuICAgIHZhciByb290RWxlbU5hbWUgPSBcIm15c29tZS10b3VyLXJvb3RcIjtcbiAgICAvLyBjb25zdCBvdmVybGF5Q2xhc3MgPSBcIm15c29tZS10b3VyLW92ZXJsYXlcIjtcdFxuICAgIC8vIGNvbnN0IG92ZXJsYXlGb2N1c0NsYXNzID0gXCJteXNvbWUtdG91ci1mb2N1c1wiO1x0XG4gICAgdmFyIGZvY3VzID0ge1xuICAgICAgICB3aWR0aDogMTEwLFxuICAgICAgICBoZWlnaHQ6IDkwLFxuICAgICAgICBsZWZ0OiAxNDIsXG4gICAgICAgIHRvcDogOTAsXG4gICAgfTtcbiAgICB2YXIgbWFza0lEID0gXCJteXNvbWUtdG91ci1tYXNrXCI7XG4gICAgdmFyIGNsaXBJRCA9IFwibXlzb21lLXRvdXItY2xpcFwiO1xuICAgIHZhciByb290ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocm9vdEVsZW1OYW1lKTtcbiAgICBpZiAoIXJvb3QpIHtcbiAgICAgICAgcm9vdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICByb290LmlkID0gcm9vdEVsZW1OYW1lO1xuICAgICAgICByb290LnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgcm9vdC5pbm5lckhUTUwgPSBcIlxcblxcdFxcdFxcdDxzdHlsZT5cXG5cXHRcXHRcXHQ8L3N0eWxlPlxcblxcblxcdFxcdFxcdDxkaXYgaWQ9XFxcIm15c29tZS10b3VyLW92ZXJsYXktY29udGFpbmVyXFxcIiBzdHlsZT1cXFwib3BhY2l0eTogMC43OyBsZWZ0OiAwcHg7IHRvcDogMHB4OyBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk5OyBwb2ludGVyLWV2ZW50czogbm9uZTsgY29sb3I6IHJnYigwLCAwLCAwKTtcXFwiPlxcblxcdFxcdFxcdCAgIDxzdmcgaWQ9XFxcIm15c29tZS10b3VyLW92ZXJsYXktc3ZnXFxcIiB3aWR0aD1cXFwiMTI4MFxcXCIgaGVpZ2h0PVxcXCI1MjZcXFwiIHhtbG5zPVxcXCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1xcXCIgc3R5bGU9XFxcIndpZHRoOiAxMjgwcHg7IGhlaWdodDogNTI2cHg7IGxlZnQ6IDBweDsgdG9wOiAwcHg7IHBvc2l0aW9uOiBmaXhlZDtcXFwiPlxcblxcdFxcdFxcdCAgICAgIDxkZWZzPlxcblxcdFxcdFxcdCAgICAgICAgIDxtYXNrIGlkPVxcXCJcIi5jb25jYXQobWFza0lELCBcIlxcXCI+XFxuXFx0XFx0XFx0ICAgICAgICAgICAgPHJlY3QgaWQ9XFxcIlwiKS5jb25jYXQobWFza0lELCBcIi1yZWN0MVxcXCIgeD1cXFwiMFxcXCIgeT1cXFwiMFxcXCIgd2lkdGg9XFxcIjEyODBcXFwiIGhlaWdodD1cXFwiNTI2XFxcIiBmaWxsPVxcXCJ3aGl0ZVxcXCI+PC9yZWN0PlxcblxcdFxcdFxcdCAgICAgICAgICAgIDxyZWN0IGlkPVxcXCJcIikuY29uY2F0KG1hc2tJRCwgXCItcmVjdDJcXFwiIHN0eWxlPVxcXCJ4OiAzOTBweDsgeTogMjQwLjIwM3B4OyB3aWR0aDogNTAwcHg7IGhlaWdodDogODZweDsgZmlsbDogYmxhY2s7IHJ4OiAwcHg7XFxcIj48L3JlY3Q+XFxuXFx0XFx0XFx0ICAgICAgICAgPC9tYXNrPlxcblxcdFxcdFxcdCAgICAgICAgIDxjbGlwUGF0aCBpZD1cXFwiXCIpLmNvbmNhdChjbGlwSUQsIFwiXFxcIj5cXG5cXHRcXHRcXHQgICAgICAgICAgICA8cG9seWdvbiBpZD1cXFwiXCIpLmNvbmNhdChjbGlwSUQsIFwiLXBvbHlcXFwiIHBvaW50cz1cXFwiMCAwLCAwIDUyNiwgMzkwIDUyNiwgMzkwIDI0MC4yMDMxMjUsIDg5MCAyNDAuMjAzMTI1LCA4OTAgMzI2LjIwMzEyNSwgMzkwIDMyNi4yMDMxMjUsIDM5MCA1MjYsIDEyODAgNTI2LCAxMjgwIDBcXFwiPjwvcG9seWdvbj5cXG5cXHRcXHRcXHQgICAgICAgICA8L2NsaXBQYXRoPlxcblxcdFxcdFxcdCAgICAgIDwvZGVmcz5cXG5cXHRcXHRcXHQgICAgICA8cmVjdCBpZD1cXFwibXlzb21lLXRvdXItcmVhbC1tYXNrXFxcIiBzdHlsZT1cXFwieDogMHB4OyB5OiAwcHg7IHdpZHRoOiAxMjgwcHg7IGhlaWdodDogNTI2cHg7IGZpbGw6IGN1cnJlbnRjb2xvcjsgbWFzazogdXJsKCZxdW90OyNteXNvbWUtdG91ci1tYXNrJnF1b3Q7KTtcXFwiPjwvcmVjdD5cXG5cXHRcXHRcXHQgICAgICA8cmVjdCBpZD1cXFwibXlzb21lLXRvdXItY2xpY2thYmxlXFxcIiBzdHlsZT1cXFwieDogMHB4OyB5OiAwcHg7IHdpZHRoOiAxMjgwcHg7IGhlaWdodDogNTI2cHg7IGZpbGw6IGN1cnJlbnRjb2xvcjsgcG9pbnRlci1ldmVudHM6IGF1dG87IGNsaXAtcGF0aDogdXJsKCZxdW90OyNteXNvbWUtdG91ci1jbGlwJnF1b3Q7KTtcXFwiPjwvcmVjdD5cXG5cXHRcXHRcXHQgICAgICA8cmVjdCBpZD1cXFwibXlzb21lLXRvdXItaGlnaGxpZ2h0XFxcIiBzdHlsZT1cXFwieDogMzkwcHg7IHk6IDI0MC4yMDNweDsgd2lkdGg6IDUwMHB4OyBoZWlnaHQ6IDg2cHg7IHBvaW50ZXItZXZlbnRzOiBhdXRvOyBmaWxsOiB0cmFuc3BhcmVudDsgZGlzcGxheTogbm9uZTtcXFwiPjwvcmVjdD5cXG5cXHRcXHRcXHQgICA8L3N2Zz5cXG5cXHRcXHRcXHQ8L2Rpdj5cXG5cXG5cXHRcXHRcIik7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQocm9vdCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB1dGlsc18xLmxvZ2dlci5lcnJvcihcIlJvb3QgZWxlbWVudCBhbHJlYWR5IGV4aXN0ZWQhIFRoaXMgbWF5IG1ha2UgdGhlIHBsdWdpbiBzdG9wIHdvcmtpbmcuXCIpO1xuICAgIH1cbiAgICB2YXIgY29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtdG91ci1vdmVybGF5LWNvbnRhaW5lclwiKTtcbiAgICB2YXIgc3ZnID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtdG91ci1vdmVybGF5LXN2Z1wiKTtcbiAgICB2YXIgbWFzayA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibXlzb21lLXRvdXItbWFza1wiKTtcbiAgICB2YXIgcmVjdDEgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS10b3VyLW1hc2stcmVjdDFcIik7XG4gICAgdmFyIHJlY3QyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtdG91ci1tYXNrLXJlY3QyXCIpO1xuICAgIHZhciBwb2x5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtdG91ci1jbGlwLXBvbHlcIik7XG4gICAgdmFyIHJlYWxNYXNrID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJteXNvbWUtdG91ci1yZWFsLW1hc2tcIik7XG4gICAgdmFyIGNsaWNrYWJsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibXlzb21lLXRvdXItY2xpY2thYmxlXCIpO1xuICAgIHZhciBoaWdobGlnaHQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm15c29tZS10b3VyLWhpZ2hsaWdodFwiKTtcbiAgICBpZiAoIXN2ZyB8fCAhbWFzayB8fCAhcmVjdDEgfHwgIXJlY3QyIHx8ICFwb2x5IHx8ICFyZWFsTWFzayB8fCAhY2xpY2thYmxlIHx8ICFoaWdobGlnaHQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgZWxlbWVudC5cIik7XG4gICAgfVxuICAgIHZhciB0YXJnZXQgPSBudWxsO1xuICAgIHZhciBzZXRUYXJnZXQgPSBmdW5jdGlvbiAoZWxlbWVudCkge1xuICAgICAgICB0YXJnZXQgPSBlbGVtZW50O1xuICAgICAgICBjb25zb2xlLmxvZyhcInNldCB0YXJnZXRcIiwgdGFyZ2V0KTtcbiAgICB9O1xuICAgIHZhciBtYXNrQXJlYSA9IHtcbiAgICAgICAgeDogMCxcbiAgICAgICAgeTogMCxcbiAgICAgICAgdzogMCxcbiAgICAgICAgaDogMCxcbiAgICB9O1xuICAgIHZhciB1cGRhdGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwidXBkYXRlIFwiKTtcbiAgICAgICAgaWYgKHRhcmdldCkge1xuICAgICAgICAgICAgdmFyIGRvbVJlY3QgPSB0YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICBtYXNrQXJlYS54ID0gZG9tUmVjdC54O1xuICAgICAgICAgICAgbWFza0FyZWEueSA9IGRvbVJlY3QueTtcbiAgICAgICAgICAgIG1hc2tBcmVhLncgPSBkb21SZWN0LndpZHRoO1xuICAgICAgICAgICAgbWFza0FyZWEuaCA9IGRvbVJlY3QuaGVpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgbWFza0FyZWEueCA9IDA7XG4gICAgICAgICAgICBtYXNrQXJlYS55ID0gMDtcbiAgICAgICAgICAgIG1hc2tBcmVhLncgPSAwO1xuICAgICAgICAgICAgbWFza0FyZWEuaCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIF9hID0gZ2V0V2luZG93U2l6ZSgpLCBvdmVybGF5V2lkdGggPSBfYS53LCBvdmVybGF5SGVpZ2h0ID0gX2EuaDtcbiAgICAgICAgdmFyIHdpbmRvd0hlaWdodCA9IG92ZXJsYXlIZWlnaHQ7XG4gICAgICAgIHZhciB3aW5kb3dXaWR0aCA9IG92ZXJsYXlXaWR0aDtcbiAgICAgICAgc2V0U3R5bGUoc3ZnLCB7XG4gICAgICAgICAgICB3aWR0aDogXCJcIi5jb25jYXQob3ZlcmxheVdpZHRoLCBcInB4XCIpLFxuICAgICAgICAgICAgaGVpZ2h0OiBcIlwiLmNvbmNhdChvdmVybGF5SGVpZ2h0LCBcInB4XCIpLFxuICAgICAgICAgICAgbGVmdDogJzBweCcsXG4gICAgICAgICAgICB0b3A6ICcwcHgnLFxuICAgICAgICB9KTtcbiAgICAgICAgc2V0U3R5bGUocmVjdDEsIHtcbiAgICAgICAgICAgIHg6ICcwJyxcbiAgICAgICAgICAgIHk6ICcwJyxcbiAgICAgICAgICAgIHdpZHRoOiBcIlwiLmNvbmNhdChvdmVybGF5V2lkdGgsIFwicHhcIiksXG4gICAgICAgICAgICBoZWlnaHQ6IFwiXCIuY29uY2F0KG92ZXJsYXlIZWlnaHQsIFwicHhcIiksXG4gICAgICAgICAgICBmaWxsOiAnd2hpdGUnLFxuICAgICAgICB9KTtcbiAgICAgICAgc2V0U3R5bGUocmVjdDIsIHtcbiAgICAgICAgICAgIHg6IFwiXCIuY29uY2F0KG1hc2tBcmVhLngpLFxuICAgICAgICAgICAgeTogXCJcIi5jb25jYXQobWFza0FyZWEueSksXG4gICAgICAgICAgICB3aWR0aDogXCJcIi5jb25jYXQobWFza0FyZWEudyksXG4gICAgICAgICAgICBoZWlnaHQ6IFwiXCIuY29uY2F0KG1hc2tBcmVhLmgpLFxuICAgICAgICAgICAgZmlsbDogJ2JsYWNrJyxcbiAgICAgICAgfSk7XG4gICAgICAgIHZhciBzdHJQb2ludHMgPSBcIlxcblxcdFxcdFxcdDAgMCxcXG5cXHRcXHRcXHQwIFwiLmNvbmNhdCh3aW5kb3dIZWlnaHQsIFwiLFxcblxcdFxcdFxcdFwiKS5jb25jYXQobWFza0FyZWEueCwgXCIgXCIpLmNvbmNhdCh3aW5kb3dIZWlnaHQsIFwiLFxcblxcdFxcdFxcdFwiKS5jb25jYXQobWFza0FyZWEueCwgXCIgXCIpLmNvbmNhdChtYXNrQXJlYS55LCBcIixcXG5cXHRcXHRcXHRcIikuY29uY2F0KG1hc2tBcmVhLnggKyBtYXNrQXJlYS53LCBcIiBcIikuY29uY2F0KG1hc2tBcmVhLnksIFwiLFxcblxcdFxcdFxcdFwiKS5jb25jYXQobWFza0FyZWEueCArIG1hc2tBcmVhLncsIFwiIFwiKS5jb25jYXQobWFza0FyZWEueSArIG1hc2tBcmVhLmgsIFwiLFxcblxcdFxcdFxcdFwiKS5jb25jYXQobWFza0FyZWEueCwgXCIgXCIpLmNvbmNhdChtYXNrQXJlYS55ICsgbWFza0FyZWEuaCwgXCIsXFxuXFx0XFx0XFx0XCIpLmNvbmNhdChtYXNrQXJlYS54LCBcIiBcIikuY29uY2F0KHdpbmRvd0hlaWdodCwgXCIsXFxuXFx0XFx0XFx0XCIpLmNvbmNhdCh3aW5kb3dXaWR0aCwgXCIgXCIpLmNvbmNhdCh3aW5kb3dIZWlnaHQsIFwiLFxcblxcdFxcdFxcdFwiKS5jb25jYXQod2luZG93V2lkdGgsIFwiIDBcIikucmVwbGFjZUFsbChcIlxcdFwiLCBcIlwiKS5yZXBsYWNlQWxsKFwiXFxuXCIsIFwiXCIpLnJlcGxhY2VBbGwoXCIsXCIsIFwiLCBcIik7XG4gICAgICAgIHBvbHkuc2V0QXR0cmlidXRlKFwicG9pbnRzXCIsIHN0clBvaW50cyk7XG4gICAgICAgIHNldFN0eWxlKHJlYWxNYXNrLCB7XG4gICAgICAgICAgICB4OiAnMCcsXG4gICAgICAgICAgICB5OiAnMCcsXG4gICAgICAgICAgICB3aWR0aDogd2luZG93V2lkdGgudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIGhlaWdodDogd2luZG93SGVpZ2h0LnRvU3RyaW5nKCksXG4gICAgICAgICAgICBmaWxsOiAnY3VycmVudGNvbG9yJyxcbiAgICAgICAgICAgIG1hc2s6IFwidXJsKCNcIi5jb25jYXQobWFza0lELCBcIilcIiksXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRTdHlsZShjbGlja2FibGUsIHtcbiAgICAgICAgICAgIHg6IFwiMFwiLFxuICAgICAgICAgICAgeTogXCIwXCIsXG4gICAgICAgICAgICB3aWR0aDogd2luZG93V2lkdGgudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIGhlaWdodDogd2luZG93SGVpZ2h0LnRvU3RyaW5nKCksXG4gICAgICAgICAgICBmaWxsOiAnY3VycmVudGNvbG9yJyxcbiAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6ICdhdXRvJyxcbiAgICAgICAgICAgIGNsaXBQYXRoOiBcInVybCgjXCIuY29uY2F0KGNsaXBJRCwgXCIpXCIpLFxuICAgICAgICB9KTtcbiAgICAgICAgc2V0U3R5bGUoaGlnaGxpZ2h0LCB7XG4gICAgICAgICAgICB4OiBtYXNrQXJlYS54LnRvU3RyaW5nKCksXG4gICAgICAgICAgICB5OiBtYXNrQXJlYS55LnRvU3RyaW5nKCksXG4gICAgICAgICAgICB3aWR0aDogbWFza0FyZWEudy50b1N0cmluZygpLFxuICAgICAgICAgICAgaGVpZ2h0OiBtYXNrQXJlYS5oLnRvU3RyaW5nKCksXG4gICAgICAgICAgICBwb2ludGVyRXZlbnRzOiAnYXV0bycsXG4gICAgICAgICAgICBmaWxsOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHZhciB1cGRhdGVUaW1lcjtcbiAgICB2YXIgc2hvdyA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIGlmICghcm9vdCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRhcmdldCA9IGU7XG4gICAgICAgIHJvb3Quc3R5bGUuZGlzcGxheSA9ICdpbmxpbmUtYmxvY2snO1xuICAgICAgICAvLyBjcmVhdGVUb29sdGlwV2lkZ2V0KCkuc2hvdyhlKTtcbiAgICAgICAgY2xlYXJJbnRlcnZhbCh1cGRhdGVUaW1lcik7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHVwZGF0ZSk7XG4gICAgICAgIHVwZGF0ZSgpO1xuICAgICAgICB1cGRhdGVUaW1lciA9IHNldEludGVydmFsKHVwZGF0ZSwgMjUpO1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB1cGRhdGUpO1xuICAgIH07XG4gICAgdmFyIGhpZGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNsZWFySW50ZXJ2YWwodXBkYXRlVGltZXIpO1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInJlc2l6ZVwiLCB1cGRhdGUpO1xuICAgICAgICBpZiAoIXJvb3QpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICByb290LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgfTtcbiAgICBpbnN0YW5jZSA9IHtcbiAgICAgICAgZWxlbWVudHM6IHtcbiAgICAgICAgICAgIHJvb3Q6IHJvb3QsXG4gICAgICAgIH0sXG4gICAgICAgIHNldFRhcmdldDogc2V0VGFyZ2V0LFxuICAgICAgICBzZXRJbml0aWFsU3RhdGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgfSxcbiAgICAgICAgaGlkZTogaGlkZSxcbiAgICAgICAgc2hvdzogc2hvdyxcbiAgICB9O1xuICAgIHJldHVybiBpbnN0YW5jZTtcbn07XG5leHBvcnRzLmNyZWF0ZVRvdXJXaWRnZXQgPSBjcmVhdGVUb3VyV2lkZ2V0O1xudmFyIGNyZWF0ZVRvdXIgPSBmdW5jdGlvbiAodHlwZSkge1xuICAgIC8vIChteXNvbWUgYXMgYW55KS50b3VycyA9IChteXNvbWUgYXMgYW55KS50b3VycyA/PyBbXTtcbiAgICB2YXIgX2EgPSByb290XzEubXlzb21lLnRvdXJzW3R5cGVdLCBzdGVwcyA9IF9hLnN0ZXBzLCBvblRvdXJTdGFydCA9IF9hLm9uVG91clN0YXJ0LCBvblRvdXJEb25lID0gX2Eub25Ub3VyRG9uZSwgb25Ub3VyRXJyb3IgPSBfYS5vblRvdXJFcnJvciwgb25Ub3VyQ2FuY2VsID0gX2Eub25Ub3VyQ2FuY2VsO1xuICAgIHZhciBzdGVwID0gMDtcbiAgICB2YXIgY29udGV4dCA9IHN0ZXBzW3N0ZXBdO1xuICAgIHJvb3RfMS5teXNvbWUudG91ciA9IHtcbiAgICAgICAgc3RlcDogc3RlcCxcbiAgICAgICAgc3RlcHM6IHN0ZXBzLFxuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBjYW5jZWw6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNvbnRleHQuZGVhY3RpdmF0ZSAmJlxuICAgICAgICAgICAgICAgIGNvbnRleHQuZGVhY3RpdmF0ZShyb290XzEubXlzb21lLnRvdXIpLnRoZW4oKS5jYXRjaChjb25zb2xlLmVycm9yKTtcbiAgICAgICAgICAgIG9uVG91ckNhbmNlbChyb290XzEubXlzb21lLnRvdXIpO1xuICAgICAgICAgICAgb25Ub3VyRG9uZShyb290XzEubXlzb21lLnRvdXIpO1xuICAgICAgICAgICAgY29udGV4dCA9IG51bGw7XG4gICAgICAgICAgICByb290XzEubXlzb21lLnRvdXIgPSBudWxsO1xuICAgICAgICB9LFxuICAgICAgICBkb25lOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjb250ZXh0LmRlYWN0aXZhdGUgJiZcbiAgICAgICAgICAgICAgICBjb250ZXh0LmRlYWN0aXZhdGUocm9vdF8xLm15c29tZS50b3VyKS50aGVuKCkuY2F0Y2goY29uc29sZS5lcnJvcik7XG4gICAgICAgICAgICBvblRvdXJEb25lKHJvb3RfMS5teXNvbWUudG91cik7XG4gICAgICAgICAgICBjb250ZXh0ID0gbnVsbDtcbiAgICAgICAgICAgIHJvb3RfMS5teXNvbWUudG91ciA9IG51bGw7XG4gICAgICAgIH0sXG4gICAgICAgIG5leHRTdGVwOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAoY29udGV4dCA9PT0gbnVsbCB8fCBjb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb250ZXh0Lm5leHQpICYmIGNvbnRleHQubmV4dCgpO1xuICAgICAgICB9LFxuICAgICAgICBuZXh0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAoY29udGV4dCA9PT0gbnVsbCB8fCBjb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb250ZXh0Lm5leHQpICYmIGNvbnRleHQubmV4dCgpO1xuICAgICAgICB9LFxuICAgICAgICBlbmRXaXRoRXJyb3I6IGZ1bmN0aW9uICh0aXRsZSwgbWVzc2FnZSkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb250ZXh0LmRlYWN0aXZhdGUgJiZcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dC5kZWFjdGl2YXRlKHJvb3RfMS5teXNvbWUudG91cikudGhlbigpLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuICAgICAgICAgICAgICAgIG9uVG91ckRvbmUocm9vdF8xLm15c29tZS50b3VyKTtcbiAgICAgICAgICAgICAgICBjb250ZXh0ID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgb25Ub3VyRXJyb3Iocm9vdF8xLm15c29tZS50b3VyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJvb3RfMS5teXNvbWUudG91ciA9IG51bGw7XG4gICAgICAgICAgICAoMCwgcG9wdXBfMS5zaG93TWVzc2FnZVBvcHVwKSh7IHRpdGxlOiB0aXRsZSwgbWVzc2FnZTogbWVzc2FnZSB9KTtcbiAgICAgICAgfSxcbiAgICB9O1xuICAgIG9uVG91clN0YXJ0KHJvb3RfMS5teXNvbWUudG91cik7XG4gICAgY29udGV4dC5hY3RpdmF0ZSAmJlxuICAgICAgICBjb250ZXh0LmFjdGl2YXRlKHJvb3RfMS5teXNvbWUudG91cikudGhlbigpLmNhdGNoKGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgY29udGV4dCA9PT0gbnVsbCB8fCBjb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb250ZXh0Lm9uQWN0aXZhdGVFeGNlcHRpb24ocm9vdF8xLm15c29tZS50b3VyKTtcbiAgICAgICAgfSk7XG4gICAgdmFyIG5leHQ7XG4gICAgY29udGV4dC5uZXh0ID0gbmV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY29udGV4dC5kZWFjdGl2YXRlICYmXG4gICAgICAgICAgICBjb250ZXh0LmRlYWN0aXZhdGUocm9vdF8xLm15c29tZS50b3VyKS50aGVuKCkuY2F0Y2goY29uc29sZS5lcnJvcik7XG4gICAgICAgIGlmICgrK3N0ZXAgPj0gc3RlcHMubGVuZ3RoKSB7XG4gICAgICAgICAgICBvblRvdXJEb25lKHJvb3RfMS5teXNvbWUudG91cik7XG4gICAgICAgICAgICBjb250ZXh0ID0gbnVsbDtcbiAgICAgICAgICAgIHJvb3RfMS5teXNvbWUudG91ciA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb250ZXh0ID0gc3RlcHNbc3RlcF07XG4gICAgICAgICAgICBjb250ZXh0Lm5leHQgPSBuZXh0O1xuICAgICAgICAgICAgcm9vdF8xLm15c29tZS50b3VyLnN0ZXAgPSBzdGVwO1xuICAgICAgICAgICAgY29udGV4dC5hY3RpdmF0ZSAmJlxuICAgICAgICAgICAgICAgIGNvbnRleHQuYWN0aXZhdGUocm9vdF8xLm15c29tZS50b3VyKS50aGVuKCkuY2F0Y2goZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dCA9PT0gbnVsbCB8fCBjb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb250ZXh0Lm9uQWN0aXZhdGVFeGNlcHRpb24ocm9vdF8xLm15c29tZS50b3VyKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG59O1xuZXhwb3J0cy5jcmVhdGVUb3VyID0gY3JlYXRlVG91cjtcbnZhciBlbmRUb3VyID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYTtcbiAgICB2YXIgYmFja2dyb3VuZCA9ICgoX2EgPSByb290XzEubXlzb21lLnRvdXIpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHt9KS5iYWNrZ3JvdW5kO1xuICAgIGJhY2tncm91bmQgPT09IG51bGwgfHwgYmFja2dyb3VuZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogYmFja2dyb3VuZC5oaWRlKCk7XG59O1xuZXhwb3J0cy5lbmRUb3VyID0gZW5kVG91cjtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5jcmVhdGVUcmFja2VyID0gZXhwb3J0cy50cmFja2luZyA9IHZvaWQgMDtcbnZhciB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XG5leHBvcnRzLnRyYWNraW5nID0ge307XG52YXIgdHJhY2tpbmdTdWJzY3JpYmVycyA9IHt9O1xuZXhwb3J0cy50cmFja2luZy5vbiA9IGZ1bmN0aW9uIChuYW1lLCBmbikge1xuICAgIHZhciBfYTtcbiAgICB0cmFja2luZ1N1YnNjcmliZXJzW25hbWVdID0gKF9hID0gdHJhY2tpbmdTdWJzY3JpYmVyc1tuYW1lXSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW107XG4gICAgdHJhY2tpbmdTdWJzY3JpYmVyc1tuYW1lXS5wdXNoKGZuKTtcbn07XG5leHBvcnRzLnRyYWNraW5nLm9mZiA9IGZ1bmN0aW9uIChuYW1lLCBmbikge1xuICAgIHZhciBfYTtcbiAgICB0cmFja2luZ1N1YnNjcmliZXJzW25hbWVdID0gKF9hID0gdHJhY2tpbmdTdWJzY3JpYmVyc1tuYW1lXSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW107XG4gICAgdmFyIGluZGV4ID0gdHJhY2tpbmdTdWJzY3JpYmVyc1tuYW1lXS5maW5kSW5kZXgoZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHggPT09IGZuOyB9KTtcbiAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICB0cmFja2luZ1N1YnNjcmliZXJzW25hbWVdLnNsaWNlKGluZGV4LCAxKTtcbiAgICB9XG59O1xuZXhwb3J0cy50cmFja2luZy5maXJlID0gZnVuY3Rpb24gKG5hbWUsIHZhbHVlKSB7XG4gICAgdmFyIF9hO1xuICAgICgoX2EgPSB0cmFja2luZ1N1YnNjcmliZXJzW25hbWVdKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbXSkuZm9yRWFjaChmdW5jdGlvbiAocykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcyAmJiBzKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbmZ1bmN0aW9uIGNyZWF0ZVRyYWNrZXIoYXJncykge1xuICAgIHZhciBuYW1lID0gYXJncy5uYW1lLCBxdWVyeSA9IGFyZ3MucXVlcnksIF9hID0gYXJncy5pbml0aWFsVmFsdWUsIGluaXRpYWxWYWx1ZSA9IF9hID09PSB2b2lkIDAgPyBudWxsIDogX2EsIF9iID0gYXJncy5tb2RlLCBtb2RlID0gX2IgPT09IHZvaWQgMCA/ICdub3JtYWwnIDogX2IsIF9jID0gYXJncy50aHJvdHRsZSwgdGhyb3R0bGUgPSBfYyA9PT0gdm9pZCAwID8gMCA6IF9jLCBkZWZhdWx0Q29tcGFyZUZuID0gYXJncy5jbXA7XG4gICAgaWYgKFsnb2ZmJywgJ29uJywgJ2ZpcmUnXS5pbmRleE9mKG5hbWUpID49IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgdXNlIGZpZWxkIG5hbWUuJyk7XG4gICAgfVxuICAgIHZhciB0cmFja2VyU3RhdGUgPSB7XG4gICAgICAgIHZhbHVlOiBpbml0aWFsVmFsdWUsXG4gICAgICAgIGxhc3RDaGFuZ2VkOiAwLFxuICAgICAgICBsYXN0VXBkYXRlOiAwLFxuICAgIH07XG4gICAgZXhwb3J0cy50cmFja2luZ1tuYW1lXSA9IHRyYWNrZXJTdGF0ZS52YWx1ZTtcbiAgICB2YXIgdXBkYXRlID0gZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICB2YXIgX2IgPSBhcmdzICE9PSBudWxsICYmIGFyZ3MgIT09IHZvaWQgMCA/IGFyZ3MgOiB7fSwgZm5TZXQgPSBfYi5vbiwgZm5PdmVycmlkZVF1ZXJ5ID0gX2IucXVlcnksIGZuQ29tcGFyZU92ZXJyaWRlID0gX2IuY21wLCBwcmVyZXF1aXNpdGVzID0gX2IucHJlcmVxdWlzaXRlcywgX2MgPSBfYi50aHJvdHRsZSwgdGhyb3R0bGVPdmVycmlkZSA9IF9jID09PSB2b2lkIDAgPyAwIDogX2MsIF9kID0gX2IucmVzZXRUaHJvdHRsZSwgcmVzZXRUaHJvdHRsZSA9IF9kID09PSB2b2lkIDAgPyBmYWxzZSA6IF9kO1xuICAgICAgICB2YXIgX3Rocm90dGxlID0gdGhyb3R0bGUgIT09IG51bGwgJiYgdGhyb3R0bGUgIT09IHZvaWQgMCA/IHRocm90dGxlIDogdGhyb3R0bGVPdmVycmlkZTtcbiAgICAgICAgdmFyIHRocm90dGxlV2FpdCA9IGZhbHNlO1xuICAgICAgICBpZiAoX3Rocm90dGxlID4gMCkge1xuICAgICAgICAgICAgdmFyIHRzID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICB2YXIgZGVsdGEgPSBNYXRoLm1heCh0cmFja2VyU3RhdGUubGFzdFVwZGF0ZSwgdHMpIC0gTWF0aC5taW4odHJhY2tlclN0YXRlLmxhc3RVcGRhdGUsIHRzKTtcbiAgICAgICAgICAgIHRocm90dGxlV2FpdCA9IGRlbHRhIDwgX3Rocm90dGxlICYmICFyZXNldFRocm90dGxlO1xuICAgICAgICB9XG4gICAgICAgIHZhciB2YWx1ZSA9IG51bGw7XG4gICAgICAgIHZhciBwcmVyZXF1aXNpdGVzTWV0ID0gIXRocm90dGxlV2FpdCAmJiAoIXByZXJlcXVpc2l0ZXMgfHwgcHJlcmVxdWlzaXRlcy5yZWR1Y2UoZnVuY3Rpb24gKGFyciwgaXQpIHsgcmV0dXJuIGFyciAmJiBpdDsgfSwgdHJ1ZSkpO1xuICAgICAgICBpZiAocHJlcmVxdWlzaXRlc01ldCkge1xuICAgICAgICAgICAgdHJhY2tlclN0YXRlLmxhc3RVcGRhdGUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICAgICAgICAgIHZhciB3aGF0ID0gZm5PdmVycmlkZVF1ZXJ5ICE9PSBudWxsICYmIGZuT3ZlcnJpZGVRdWVyeSAhPT0gdm9pZCAwID8gZm5PdmVycmlkZVF1ZXJ5IDogcXVlcnk7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdoYXQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdoYXQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiB3aGF0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gISFkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHdoYXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHR5cGUgJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgY29tcGFyZSA9IChfYSA9IGRlZmF1bHRDb21wYXJlRm4gIT09IG51bGwgJiYgZGVmYXVsdENvbXBhcmVGbiAhPT0gdm9pZCAwID8gZGVmYXVsdENvbXBhcmVGbiA6IGZuQ29tcGFyZU92ZXJyaWRlKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiAoZnVuY3Rpb24gKG9sZFZhbCwgbmV3VmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9sZFZhbCAhPT0gbmV3VmFsO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAocHJlcmVxdWlzaXRlc01ldCAmJiBjb21wYXJlKHRyYWNrZXJTdGF0ZS52YWx1ZSwgdmFsdWUpIHx8IHRyYWNrZXJTdGF0ZS5sYXN0Q2hhbmdlZCA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHZhciBpZ25vcmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAobW9kZSA9PT0gJ29ic2VydmVkJyAmJiB0cmFja2VyU3RhdGUubGFzdENoYW5nZWQgIT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaWdub3JlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCFpZ25vcmUpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlQmVmb3JlID0gdHJhY2tlclN0YXRlLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB0cmFja2VyU3RhdGUudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgdHJhY2tlclN0YXRlLmxhc3RDaGFuZ2VkID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICAgICAgICAgICgwLCB1dGlsc18xLnZlcmJvc2UpKFwiXCIuY29uY2F0KG5hbWUsIFwiIFwiKS5jb25jYXQobW9kZSA9PT0gJ25vcm1hbCcgPyAnY2hhbmdlZCcgOiAnb2JzZXJ2ZWQnLCBcIiA9PiBcIiksIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgZm5TZXQgJiYgZm5TZXQodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLnRyYWNraW5nW25hbWVdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydHMudHJhY2tpbmcuZmlyZShcIlwiLmNvbmNhdChuYW1lKSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBleHBvcnRzLnRyYWNraW5nLmZpcmUoXCJcIi5jb25jYXQobmFtZSkuY29uY2F0KChtb2RlID09PSAnbm9ybWFsJyA/ICdDaGFuZ2VkJyA6ICdPYnNlcnZlZCcpKSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGlydHk6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBiZWZvcmU6IHZhbHVlQmVmb3JlLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgICAgICAgZGlydHk6IGZhbHNlXG4gICAgICAgIH07XG4gICAgfTtcbiAgICB2YXIgdGltZXIgPSBudWxsO1xuICAgIHZhciBzdGFydCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGltZXIgPSBzZXRJbnRlcnZhbCh1cGRhdGUsIDEwMDApO1xuICAgIH07XG4gICAgdmFyIHN0b3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNsZWFySW50ZXJ2YWwodGltZXIpO1xuICAgIH07XG4gICAgdmFyIHJlc2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0cmFja2VyU3RhdGUubGFzdENoYW5nZWQgPSAwO1xuICAgICAgICB0cmFja2VyU3RhdGUudmFsdWUgPSBpbml0aWFsVmFsdWUgIT09IG51bGwgJiYgaW5pdGlhbFZhbHVlICE9PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBudWxsO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdXBkYXRlOiB1cGRhdGUsXG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJhY2tlclN0YXRlLnZhbHVlOyB9LFxuICAgICAgICBzdGFydDogc3RhcnQsXG4gICAgICAgIHN0b3A6IHN0b3AsXG4gICAgICAgIHJlc2V0OiByZXNldCxcbiAgICAgICAgY2hhbmdlRXZlbnROYW1lOiBuYW1lICsgJ0NoYW5nZWQnLFxuICAgIH07XG59XG5leHBvcnRzLmNyZWF0ZVRyYWNrZXIgPSBjcmVhdGVUcmFja2VyO1xuO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19hc3NpZ24gPSAodGhpcyAmJiB0aGlzLl9fYXNzaWduKSB8fCBmdW5jdGlvbiAoKSB7XG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKVxuICAgICAgICAgICAgICAgIHRbcF0gPSBzW3BdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0O1xuICAgIH07XG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59O1xudmFyIF9fYXdhaXRlciA9ICh0aGlzICYmIHRoaXMuX19hd2FpdGVyKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XG4gICAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcbiAgICB9KTtcbn07XG52YXIgX19nZW5lcmF0b3IgPSAodGhpcyAmJiB0aGlzLl9fZ2VuZXJhdG9yKSB8fCBmdW5jdGlvbiAodGhpc0FyZywgYm9keSkge1xuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XG4gICAgICAgIHdoaWxlIChnICYmIChnID0gMCwgb3BbMF0gJiYgKF8gPSAwKSksIF8pIHRyeSB7XG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcbiAgICB9XG59O1xudmFyIF9fc3ByZWFkQXJyYXkgPSAodGhpcyAmJiB0aGlzLl9fc3ByZWFkQXJyYXkpIHx8IGZ1bmN0aW9uICh0bywgZnJvbSwgcGFjaykge1xuICAgIGlmIChwYWNrIHx8IGFyZ3VtZW50cy5sZW5ndGggPT09IDIpIGZvciAodmFyIGkgPSAwLCBsID0gZnJvbS5sZW5ndGgsIGFyOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIGlmIChhciB8fCAhKGkgaW4gZnJvbSkpIHtcbiAgICAgICAgICAgIGlmICghYXIpIGFyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoZnJvbSwgMCwgaSk7XG4gICAgICAgICAgICBhcltpXSA9IGZyb21baV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRvLmNvbmNhdChhciB8fCBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tKSk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5wbGF0Zm9ybVJlcXVlc3RzID0gZXhwb3J0cy5yZWdpc3RyYXRpb25zID0gZXhwb3J0cy5zdG9yYWdlID0gZXhwb3J0cy5vbk93bkxpbmtlZEluUHJvZmlsZU9yRmVlZFVybCA9IGV4cG9ydHMub2JqVG9VcmxQYXJtcyA9IGV4cG9ydHMuZGV0ZWN0UGxhdGZvcm0gPSBleHBvcnRzLmJsb2JUb0Jhc2U2NCA9IGV4cG9ydHMuZ2V0VXJsVG9DcmVhdGVQcm9vZiA9IGV4cG9ydHMuZ2V0VXNlcnNOYW1lT25Qcm9maWxlID0gZXhwb3J0cy5nZXRVc2Vyc05hbWVPbkZlZWQgPSBleHBvcnRzLiRhcnJheSA9IGV4cG9ydHMuJCA9IGV4cG9ydHMuJCQgPSBleHBvcnRzLmdldFVzZXJJZE9uUGFnZUZlZWQgPSBleHBvcnRzLmJhc2U2NFRvQmxvYiA9IGV4cG9ydHMuZ2V0VXNlcklkSW5VcmwgPSBleHBvcnRzLmdldFBsYXRmb3JtID0gZXhwb3J0cy5pc09uTGlua2VkSW5GZWVkVXJsID0gZXhwb3J0cy5pc09uTGlua2VkSW5Qcm9maWxlVXJsID0gZXhwb3J0cy5iNjRfdG9fdXRmOCA9IGV4cG9ydHMudXRmOF90b19iNjQgPSBleHBvcnRzLmxvZ2dlciA9IGV4cG9ydHMudmVyYm9zZSA9IGV4cG9ydHMudHJhdmVyc2VEb21BbGxXaXRoVGltZW91dCA9IGV4cG9ydHMudHJhdmVyc2VEb21XaXRoVGltZW91dCA9IHZvaWQgMDtcbnZhciBjb250ZW50X21lc3NhZ2luZ18xID0gcmVxdWlyZShcIi4vY29udGVudC1tZXNzYWdpbmdcIik7XG52YXIgcm9vdF8xID0gcmVxdWlyZShcIi4vcm9vdFwiKTtcbmZ1bmN0aW9uIHRyYXZlcnNlRG9tV2l0aFRpbWVvdXQocGF0aCwgdGltZW91dCwgaW50ZXJ2YWwsIHRocm93SWZOb3RGb3VuZCkge1xuICAgIGlmIChpbnRlcnZhbCA9PT0gdm9pZCAwKSB7IGludGVydmFsID0gMTAwOyB9XG4gICAgaWYgKHRocm93SWZOb3RGb3VuZCA9PT0gdm9pZCAwKSB7IHRocm93SWZOb3RGb3VuZCA9IHRydWU7IH1cbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlLCB0cztcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHRzID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gMTtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIGlmICghIWUpIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xuICAgICAgICAgICAgICAgICAgICBlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihwYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXcgRGF0ZSgpLmdldFRpbWUoKSAtIHRzID4gdGltZW91dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgKG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJldHVybiBzZXRUaW1lb3V0KHJlc29sdmUsIGludGVydmFsKTsgfSkpXTtcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMV07XG4gICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIWUgJiYgdGhyb3dJZk5vdEZvdW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmluZCBlbGVtZW50IDogXCIgKyBwYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgZV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuZXhwb3J0cy50cmF2ZXJzZURvbVdpdGhUaW1lb3V0ID0gdHJhdmVyc2VEb21XaXRoVGltZW91dDtcbmZ1bmN0aW9uIHRyYXZlcnNlRG9tQWxsV2l0aFRpbWVvdXQocGF0aCwgdGltZW91dCwgaW50ZXJ2YWwsIHRocm93SWZOb3RGb3VuZCkge1xuICAgIGlmIChpbnRlcnZhbCA9PT0gdm9pZCAwKSB7IGludGVydmFsID0gMTAwOyB9XG4gICAgaWYgKHRocm93SWZOb3RGb3VuZCA9PT0gdm9pZCAwKSB7IHRocm93SWZOb3RGb3VuZCA9IHRydWU7IH1cbiAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlLCB0cztcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIHRzID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gMTtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIGlmICghIWUpIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xuICAgICAgICAgICAgICAgICAgICBlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChwYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMyAvKmJyZWFrKi8sIDNdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXcgRGF0ZSgpLmdldFRpbWUoKSAtIHRzID4gdGltZW91dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgM107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgKG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJldHVybiBzZXRUaW1lb3V0KHJlc29sdmUsIGludGVydmFsKTsgfSkpXTtcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFszIC8qYnJlYWsqLywgMV07XG4gICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIWUgJiYgdGhyb3dJZk5vdEZvdW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmluZCBlbGVtZW50IDogXCIgKyBwYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgZV07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuZXhwb3J0cy50cmF2ZXJzZURvbUFsbFdpdGhUaW1lb3V0ID0gdHJhdmVyc2VEb21BbGxXaXRoVGltZW91dDtcbnZhciB2ZXJib3NlID0gZnVuY3Rpb24gKHMpIHtcbiAgICB2YXIgcmVzdCA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMTsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHJlc3RbX2kgLSAxXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIGNvbnNvbGUubG9nLmFwcGx5KGNvbnNvbGUsIF9fc3ByZWFkQXJyYXkoWydNeVNvTWU6IFZFUkJPU0U6J10sIF9fc3ByZWFkQXJyYXkoW3NdLCByZXN0LCB0cnVlKSwgZmFsc2UpKTtcbn07XG5leHBvcnRzLnZlcmJvc2UgPSB2ZXJib3NlO1xuZXhwb3J0cy5sb2dnZXIgPSB7XG4gICAgaW5mbzogZnVuY3Rpb24gKHMpIHtcbiAgICAgICAgdmFyIHJlc3QgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAxOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHJlc3RbX2kgLSAxXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgX19zcHJlYWRBcnJheShbJ015U29NZTonXSwgX19zcHJlYWRBcnJheShbc10sIHJlc3QsIHRydWUpLCBmYWxzZSkpO1xuICAgIH0sXG4gICAgbG9nOiBmdW5jdGlvbiAocykge1xuICAgICAgICB2YXIgcmVzdCA9IFtdO1xuICAgICAgICBmb3IgKHZhciBfaSA9IDE7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgcmVzdFtfaSAtIDFdID0gYXJndW1lbnRzW19pXTtcbiAgICAgICAgfVxuICAgICAgICBjb25zb2xlLmxvZy5hcHBseShjb25zb2xlLCBfX3NwcmVhZEFycmF5KFtcIk15U29NZTpcIl0sIF9fc3ByZWFkQXJyYXkoW3NdLCByZXN0LCB0cnVlKSwgZmFsc2UpKTtcbiAgICB9LFxuICAgIC8vIGluZm86IChzOiBzdHJpbmcsIC4uLnJlc3Q6IGFueVtdICkgPT4ge30sXG4gICAgZXJyb3I6IGZ1bmN0aW9uIChzKSB7XG4gICAgICAgIHZhciByZXN0ID0gW107XG4gICAgICAgIGZvciAodmFyIF9pID0gMTsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICByZXN0W19pIC0gMV0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUuZXJyb3IuYXBwbHkoY29uc29sZSwgX19zcHJlYWRBcnJheShbJ015U29NZTonXSwgX19zcHJlYWRBcnJheShbc10sIHJlc3QsIHRydWUpLCBmYWxzZSkpO1xuICAgIH0sXG4gICAgLy8gZXJyb3I6IChzOiBzdHJpbmcsIC4uLnJlc3Q6IGFueVtdICkgPT4ge30sXG4gICAgdmVyYm9zZTogZnVuY3Rpb24gKHMpIHtcbiAgICAgICAgdmFyIHJlc3QgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAxOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHJlc3RbX2kgLSAxXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgX19zcHJlYWRBcnJheShbJ015U29NZTonXSwgX19zcHJlYWRBcnJheShbc10sIHJlc3QsIHRydWUpLCBmYWxzZSkpO1xuICAgIH0sXG4gICAgdG9kbzogZnVuY3Rpb24gKHMpIHtcbiAgICAgICAgdmFyIHJlc3QgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAxOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHJlc3RbX2kgLSAxXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgX19zcHJlYWRBcnJheShbJ1RPRE86J10sIF9fc3ByZWFkQXJyYXkoW3NdLCByZXN0LCB0cnVlKSwgZmFsc2UpKTtcbiAgICB9LFxuICAgIC8vIHZlcmJvc2U6IChzOiBzdHJpbmcsIC4uLnJlc3Q6IGFueVtdICkgPT4ge30sXG59O1xuZnVuY3Rpb24gdXRmOF90b19iNjQoc3RyKSB7XG4gICAgcmV0dXJuIHdpbmRvdy5idG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKSk7XG59XG5leHBvcnRzLnV0ZjhfdG9fYjY0ID0gdXRmOF90b19iNjQ7XG5mdW5jdGlvbiBiNjRfdG9fdXRmOChzdHIpIHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGVzY2FwZSh3aW5kb3cuYXRvYihzdHIpKSk7XG59XG5leHBvcnRzLmI2NF90b191dGY4ID0gYjY0X3RvX3V0Zjg7XG52YXIgaXNPbkxpbmtlZEluUHJvZmlsZVVybCA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgb2sgPSB3aW5kb3cubG9jYXRpb24uaG9zdC5pbmRleE9mKFwibGlua2VkaW4uY29tXCIpID49IDAgJiYgd2luZG93LmxvY2F0aW9uLmhyZWYuaW5kZXhPZihcIi9pbi9cIikgPj0gMDtcbiAgICByZXR1cm4gb2s7XG59O1xuZXhwb3J0cy5pc09uTGlua2VkSW5Qcm9maWxlVXJsID0gaXNPbkxpbmtlZEluUHJvZmlsZVVybDtcbnZhciBpc09uTGlua2VkSW5GZWVkVXJsID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBvayA9IHdpbmRvdy5sb2NhdGlvbi5ob3N0LmluZGV4T2YoXCJsaW5rZWRpbi5jb21cIikgPj0gMCAmJiB3aW5kb3cubG9jYXRpb24uaHJlZi5pbmRleE9mKFwiL2ZlZWQvXCIpID49IDA7XG4gICAgcmV0dXJuIG9rO1xufTtcbmV4cG9ydHMuaXNPbkxpbmtlZEluRmVlZFVybCA9IGlzT25MaW5rZWRJbkZlZWRVcmw7XG52YXIgZ2V0UGxhdGZvcm0gPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ob3N0LmluZGV4T2YoXCJsaW5rZWRpbi5jb21cIikgPj0gMCkge1xuICAgICAgICByZXR1cm4gJ2xpJztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59O1xuZXhwb3J0cy5nZXRQbGF0Zm9ybSA9IGdldFBsYXRmb3JtO1xuLy8gVE9ETzogdGhpcyBpcyBsaW5rZWRpbiBvbmx5ISEhXG4vLyBUT0RPOiBtb3ZlIHRoaXMgdG8gYSB1dGlscyBmb2xkZXIgaW4gdGhlIGxpbmtlZGluIGludGVncmF0aW9uIVxudmFyIGdldFVzZXJJZEluVXJsID0gZnVuY3Rpb24gKCkge1xuICAgIGlmICghKDAsIGV4cG9ydHMuaXNPbkxpbmtlZEluUHJvZmlsZVVybCkoKSkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zcGxpdChcIi9cIilbMl07XG59O1xuZXhwb3J0cy5nZXRVc2VySWRJblVybCA9IGdldFVzZXJJZEluVXJsO1xuLypleHBvcnQgY29uc3QgYmFzZTY0VG9CbG9iMiA9IChiNjREYXRhOiBzdHJpbmcsIGNvbnRlbnRUeXBlPScnLCBzbGljZVNpemU9NTEyKSA9PiB7XG4gICAgY29uc3QgYnl0ZUNoYXJhY3RlcnMgPSBhdG9iKGI2NERhdGEpO1xuICAgIGNvbnN0IGJ5dGVOdW1iZXJzID0gbmV3IEFycmF5KGJ5dGVDaGFyYWN0ZXJzLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlQ2hhcmFjdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBieXRlTnVtYmVyc1tpXSA9IGJ5dGVDaGFyYWN0ZXJzLmNoYXJDb2RlQXQoaSk7XG4gICAgfVxuICAgIGNvbnN0IGJ5dGVBcnJheSA9IG5ldyBVaW50OEFycmF5KGJ5dGVOdW1iZXJzKTtcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2J5dGVBcnJheV0sIHt0eXBlOiBjb250ZW50VHlwZX0pO1xuICAgIHJldHVybiBibG9iO1xufTsqL1xuZnVuY3Rpb24gYmFzZTY0VG9CbG9iKGJhc2U2NEltYWdlKSB7XG4gICAgLy8gU3BsaXQgaW50byB0d28gcGFydHNcbiAgICB2YXIgcGFydHMgPSBiYXNlNjRJbWFnZS5zcGxpdCgnO2Jhc2U2NCwnKTtcbiAgICAvLyBIb2xkIHRoZSBjb250ZW50IHR5cGVcbiAgICB2YXIgaW1hZ2VUeXBlID0gcGFydHNbMF0uc3BsaXQoJzonKVsxXTtcbiAgICAvLyBEZWNvZGUgQmFzZTY0IHN0cmluZ1xuICAgIHZhciBkZWNvZGVkRGF0YSA9IHdpbmRvdy5hdG9iKHBhcnRzWzFdKTtcbiAgICAvLyBDcmVhdGUgVU5JVDhBUlJBWSBvZiBzaXplIHNhbWUgYXMgcm93IGRhdGEgbGVuZ3RoXG4gICAgdmFyIHVJbnQ4QXJyYXkgPSBuZXcgVWludDhBcnJheShkZWNvZGVkRGF0YS5sZW5ndGgpO1xuICAgIC8vIEluc2VydCBhbGwgY2hhcmFjdGVyIGNvZGUgaW50byB1SW50OEFycmF5XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBkZWNvZGVkRGF0YS5sZW5ndGg7ICsraSkge1xuICAgICAgICB1SW50OEFycmF5W2ldID0gZGVjb2RlZERhdGEuY2hhckNvZGVBdChpKTtcbiAgICB9XG4gICAgLy8gUmV0dXJuIEJMT0IgaW1hZ2UgYWZ0ZXIgY29udmVyc2lvblxuICAgIHJldHVybiB7XG4gICAgICAgIGJsb2I6IG5ldyBCbG9iKFt1SW50OEFycmF5XSwgeyB0eXBlOiBpbWFnZVR5cGUgfSksXG4gICAgICAgIGltYWdlVHlwZTogaW1hZ2VUeXBlXG4gICAgfTtcbn1cbmV4cG9ydHMuYmFzZTY0VG9CbG9iID0gYmFzZTY0VG9CbG9iO1xuLy8gVE9ETzogbW92ZSB0aGlzIHRvIGEgdXRpbHMgZm9sZGVyIGluIHRoZSBsaW5rZWRpbiBpbnRlZ3JhdGlvbiFcbnZhciBnZXRVc2VySWRPblBhZ2VGZWVkID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYSwgX2I7XG4gICAgdmFyIGxvYyA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvZmVlZC9cIjtcbiAgICBpZiAoIWxvYykge1xuICAgICAgICAvLyBjb25zb2xlLmVycm9yKFwiTm90IG9uIGZlZWQgdXJsXCIpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgdmFyIGEgPSAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmZlZWQtaWRlbnRpdHktbW9kdWxlXCIpKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EucXVlcnlTZWxlY3RvcihcImFcIik7XG4gICAgdmFyIHVybCA9IGEgPT09IG51bGwgfHwgYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogYS5ocmVmO1xuICAgIC8vIGNvbnNvbGUuZXJyb3IoXCJ1cmwgdHBvIGdldCBwcm9maWxlIG5hbWUgb24gZmVlZCBwYWdlIFwiLCB1cmwpO1xuICAgIHJldHVybiAoX2IgPSB1cmwgPT09IG51bGwgfHwgdXJsID09PSB2b2lkIDAgPyB2b2lkIDAgOiB1cmwuc3BsaXQoXCIvXCIpWzRdKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiBudWxsO1xufTtcbmV4cG9ydHMuZ2V0VXNlcklkT25QYWdlRmVlZCA9IGdldFVzZXJJZE9uUGFnZUZlZWQ7XG52YXIgJCQgPSBmdW5jdGlvbiAocykge1xuICAgIHJldHVybiBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHMpKTtcbn07XG5leHBvcnRzLiQkID0gJCQ7XG52YXIgJCA9IGZ1bmN0aW9uIChzKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Iocyk7XG59O1xuZXhwb3J0cy4kID0gJDtcbnZhciAkYXJyYXkgPSBmdW5jdGlvbiAobm9kZUxpc3QpIHtcbiAgICByZXR1cm4gbm9kZUxpc3QgPyBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChub2RlTGlzdCkgOiBbXTtcbn07XG5leHBvcnRzLiRhcnJheSA9ICRhcnJheTtcbi8vIFRPRE86IE1vdmUgdG8gbGlua2VkIGluIGZpbGUuICggdGhpcyBpcyBhIGxpbmtlZGluIG9ubHkgdG9vbCApXG52YXIgZ2V0VXNlcnNOYW1lT25GZWVkID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYSwgX2IsIF9jO1xuICAgIHZhciBsb2MgPSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgPT09IFwiL2ZlZWQvXCI7XG4gICAgaWYgKCFsb2MpIHtcbiAgICAgICAgLy8gY29uc29sZS5lcnJvcihcIk5vdCBvbiBmZWVkIHVybFwiKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBuYW1lID0gKF9jID0gKF9iID0gKDAsIGV4cG9ydHMuJGFycmF5KSgoX2EgPSAoMCwgZXhwb3J0cy4kKShcIi5mZWVkLWlkZW50aXR5LW1vZHVsZV9fYWN0b3ItbWV0YVwiKSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnF1ZXJ5U2VsZWN0b3JBbGwoJ2RpdicpKVxuICAgICAgICAubWFwKGZ1bmN0aW9uICh4KSB7IHZhciBfYTsgcmV0dXJuIChfYSA9IHggPT09IG51bGwgfHwgeCA9PT0gdm9pZCAwID8gdm9pZCAwIDogeC5pbm5lclRleHQpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS50cmltKCk7IH0pLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4gISEoeCA9PT0gbnVsbCB8fCB4ID09PSB2b2lkIDAgPyB2b2lkIDAgOiB4LnRyaW0oKSkgJiYgKHggPT09IG51bGwgfHwgeCA9PT0gdm9pZCAwID8gdm9pZCAwIDogeC50cmltKCkpICE9PSAnJzsgfSkpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYlswXSkgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDogbnVsbDtcbiAgICAvLyBJZiBhZGQgYSBwaG90byBpcyBkaXNwbGF5ZWQgaXQgbWVhbnMgdGhhdCB0aGUgdXNlciBoYXNudCBnb3QgYSBwaG90b1xuICAgIC8vIGFuZCB0aGUgdXNlciB3aWxsIGJlIHNob3duIGFzIFwiV2VsY29tZSwgPFVzZXJuYW1lPiFcIiAtIGluc3RlYWQgd2UgY2FuIHVzZSBcbiAgICAvLyB0aGUgYWx0IHBhcmFtdGVyIGluIHRoZSB0b3BiYXIuICggd29ya3MgaWYgdGhlIHRvcGJhciBpcyB2aXNpYmxlIGJ1dCBpZiB0aGUgd2luZG93IGlzIHNtYWxsIGl0IHdpbGwgbm90IGJlIHByZXNlbnQuICkuXG4gICAgdmFyIEFkZEFQaG90byA9ICEhKDAsIGV4cG9ydHMuJCQpKCdhID4gZGl2ID4gc3BhbicpLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4geC5pbm5lclRleHQgPT09ICdBZGQgYSBwaG90byc7IH0pWzBdO1xuICAgIHZhciBhdmF0YXJHaG9zdEJ1dHRvbiA9ICgwLCBleHBvcnRzLiQkKSgnYnV0dG9uID4gaW1nLmdob3N0LXBlcnNvbicpWzBdO1xuICAgIGlmIChBZGRBUGhvdG8gJiYgYXZhdGFyR2hvc3RCdXR0b24pIHtcbiAgICAgICAgbmFtZSA9IGF2YXRhckdob3N0QnV0dG9uLmFsdDtcbiAgICB9XG4gICAgaWYgKChuYW1lID09PSBudWxsIHx8IG5hbWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5hbWUubGVuZ3RoKSA+IDApIHtcbiAgICAgICAgcmV0dXJuIG5hbWU7XG4gICAgfVxuICAgIC8vIEZhbGxiYWNrOiBXZSBjYW4gZmFsbCBiYWNrIG9uIHRoZSBjb2RlIGVsZW1lbnQgaWYgdGhlIG90aGVyIG1ldGhvZHMgZmFpbHMuXG4gICAgLy8gTmVlZHMgbW9yZSB0ZXN0aW5nIHRvIHNlZSBob3cgcm9idXN0IGl0IGlzOyBidXQgdGhpcyBtYXkgYmUgdGhlIGJlc3Qgc29sdXRpb24gb2YgdGhlbSBhbGxcbiAgICAvLyBob3dldmVyIGl0cyB1bmNsZWFyIHdoZW4gdGhlIGVsZW1lbnQgZ2V0cyBjcmVhdGVkIGFzIHRoZSBpbnRlbnRpb24gaXMgZm9yIGFuYWx5dGljcyBhbmQgbm90IFxuICAgIC8vIHBhcnQgb2YgdGhlIGFjdHVhbCB3ZWJzaXRlLlxuICAgIHZhciBjb2RlT2JqZWN0ID0gKDAsIGV4cG9ydHMuJCQpKCdjb2RlJykuZmlsdGVyKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4LmlubmVyVGV4dC5pbmRleE9mKCdjb20ubGlua2VkaW4udm95YWdlci5jb21tb24uTWUnKSA+PSAwOyB9KVxuICAgICAgICAubWFwKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh4LmlubmVyVGV4dCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgfSlbMF07XG4gICAgdmFyIGZpcnN0TmFtZSA9IGNvZGVPYmplY3QuaW5jbHVkZWRbMF0uZmlyc3ROYW1lO1xuICAgIHZhciBsYXN0TmFtZSA9IGNvZGVPYmplY3QuaW5jbHVkZWRbMF0ubGFzdE5hbWU7XG4gICAgbmFtZSA9IGZpcnN0TmFtZSArICcgJyArIGxhc3ROYW1lO1xuICAgIGlmICgobmFtZSA9PT0gbnVsbCB8fCBuYW1lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBuYW1lLmxlbmd0aCkgPiAwKSB7XG4gICAgICAgIHJldHVybiBuYW1lO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn07XG5leHBvcnRzLmdldFVzZXJzTmFtZU9uRmVlZCA9IGdldFVzZXJzTmFtZU9uRmVlZDtcbi8vIFRPRE86IE1vdmUgdG8gbGlua2VkaW4uXG52YXIgZ2V0VXNlcnNOYW1lT25Qcm9maWxlID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYSwgX2I7XG4gICAgdmFyIG5hbWVFbGVtZW50ID0gKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJoMVwiKVswXSk7XG4gICAgaWYgKCEobmFtZUVsZW1lbnQgPT09IG51bGwgfHwgbmFtZUVsZW1lbnQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5hbWVFbGVtZW50LnBhcmVudEVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgbmFtZSA9IChfYiA9IChfYSA9IG5hbWVFbGVtZW50ID09PSBudWxsIHx8IG5hbWVFbGVtZW50ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBuYW1lRWxlbWVudC5pbm5lclRleHQpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS50cmltKCkpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IG51bGw7XG4gICAgcmV0dXJuIG5hbWUgPyBuYW1lIDogbnVsbDtcbn07XG5leHBvcnRzLmdldFVzZXJzTmFtZU9uUHJvZmlsZSA9IGdldFVzZXJzTmFtZU9uUHJvZmlsZTtcbnZhciBnZXRVcmxUb0NyZWF0ZVByb29mID0gZnVuY3Rpb24gKHBsYXRmb3JtKSB7XG4gICAgaWYgKHBsYXRmb3JtID09PSB2b2lkIDApIHsgcGxhdGZvcm0gPSAnbGknOyB9XG4gICAgaWYgKHBsYXRmb3JtID09PSAnbGknIHx8IHBsYXRmb3JtID09PSAndGVzdCcpIHtcbiAgICAgICAgdmFyIHUgPSAoMCwgZXhwb3J0cy5nZXRVc2VySWRJblVybCkoKTtcbiAgICAgICAgaWYgKCF1KSB7XG4gICAgICAgICAgICBleHBvcnRzLmxvZ2dlci5lcnJvcihcIkZhaWxlZCB0byBnZXQgdXNlcm5hbWUgZnJvbSB1cmxcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHAgPSAoMCwgZXhwb3J0cy5kZXRlY3RQbGF0Zm9ybSkoKTtcbiAgICAgICAgaWYgKCFwKSB7XG4gICAgICAgICAgICBleHBvcnRzLmxvZ2dlci5lcnJvcihcIkZhaWxlZCB0byBkZXRlY3QgcGxhdGZvcm0uXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgICgwLCBleHBvcnRzLnZlcmJvc2UpKFwidXNlcm5hbWUgdG8gY3JlYXRlIHByb29mIHdpdGggXCIsIHUpO1xuICAgICAgICB2YXIgZGF0YSA9IGVuY29kZVVSSUNvbXBvbmVudCh1dGY4X3RvX2I2NChKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICB1OiB1LFxuICAgICAgICAgICAgcDogcCxcbiAgICAgICAgfSkpKTtcbiAgICAgICAgaWYgKHBsYXRmb3JtID09PSAndGVzdCcpIHtcbiAgICAgICAgICAgIHJldHVybiBcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9jcmVhdGUvMj90ZW1wbGF0ZT1cIi5jb25jYXQoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9hcHAudGVzdG5ldC5teXNvbWVpZC5kZXYvY3JlYXRlLzI/dGVtcGxhdGU9XCIuY29uY2F0KGRhdGEpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgcGxhdGZvcm0gOiAnICsgcGxhdGZvcm0pO1xufTtcbmV4cG9ydHMuZ2V0VXJsVG9DcmVhdGVQcm9vZiA9IGdldFVybFRvQ3JlYXRlUHJvb2Y7XG52YXIgYmxvYlRvQmFzZTY0ID0gZnVuY3Rpb24gKGJsb2IpIHtcbiAgICB2YXIgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgcmVhZGVyLm9ubG9hZGVuZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJlc29sdmUocmVhZGVyLnJlc3VsdCk7XG4gICAgICAgIH07XG4gICAgfSk7XG59O1xuZXhwb3J0cy5ibG9iVG9CYXNlNjQgPSBibG9iVG9CYXNlNjQ7XG52YXIgZGV0ZWN0UGxhdGZvcm0gPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGhvc3QgPSB3aW5kb3cubG9jYXRpb24uaG9zdC50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChob3N0LmluZGV4T2YoXCJsaW5rZWRpblwiKSA+PSAwKSB7XG4gICAgICAgIHJldHVybiAnbGknO1xuICAgIH1cbiAgICBpZiAoaG9zdC5pbmRleE9mKFwibG9jYWxob3N0OjgwODJcIikgPj0gMCkge1xuICAgICAgICByZXR1cm4gJ3Rlc3QnO1xuICAgIH1cbiAgICBpZiAoaG9zdC5pbmRleE9mKFwibG9jYWxob3N0OjMwMDBcIikgPj0gMCB8fCBob3N0LmluZGV4T2YoXCJhcHAubXlzb21laWQuZGV2XCIpID49IDAgfHwgaG9zdC5pbmRleE9mKFwiYXBwLm15c29tZS5pZFwiKSA+PSAwIHx8IGhvc3QuaW5kZXhPZihcImFwcC50ZXN0bmV0Lm15c29tZS5pZFwiKSA+PSAwKSB7XG4gICAgICAgIHJldHVybiAnbXlzb21laWQnO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn07XG5leHBvcnRzLmRldGVjdFBsYXRmb3JtID0gZGV0ZWN0UGxhdGZvcm07XG52YXIgb2JqVG9VcmxQYXJtcyA9IGZ1bmN0aW9uIChvYmopIHsgcmV0dXJuIE9iamVjdC5rZXlzKG9iaikubWFwKGZ1bmN0aW9uIChrZXkpIHsgcmV0dXJuIFtrZXksIG9ialtrZXldXS5qb2luKCc9Jyk7IH0pLmpvaW4oJyYnKTsgfTtcbmV4cG9ydHMub2JqVG9VcmxQYXJtcyA9IG9ialRvVXJsUGFybXM7XG52YXIgb25Pd25MaW5rZWRJblByb2ZpbGVPckZlZWRVcmwgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIG9uRmVlZCA9ICgwLCBleHBvcnRzLmlzT25MaW5rZWRJbkZlZWRVcmwpKCk7XG4gICAgdmFyIG9uUHJvZmlsZVBhZ2UgPSAoMCwgZXhwb3J0cy5pc09uTGlua2VkSW5Qcm9maWxlVXJsKSgpO1xuICAgIHZhciBmb3VuZEVkaXRJbnRyb0VsZW1lbnQgPSAhIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJidXR0b25bYXJpYS1sYWJlbD1cXFwiRWRpdCBpbnRyb1xcXCJdXCIpO1xuICAgIC8vIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5wcm9maWxlLXRvcGNhcmQtYmFja2dyb3VuZC1pbWFnZS1lZGl0X19pY29uJylcbiAgICB2YXIgb2sgPSBvbkZlZWQgfHwgKG9uUHJvZmlsZVBhZ2UgJiYgZm91bmRFZGl0SW50cm9FbGVtZW50KTtcbiAgICByZXR1cm4gb2s7XG59O1xuZXhwb3J0cy5vbk93bkxpbmtlZEluUHJvZmlsZU9yRmVlZFVybCA9IG9uT3duTGlua2VkSW5Qcm9maWxlT3JGZWVkVXJsO1xudmFyIG1lc3NhZ2VIYW5kbGVyID0gKDAsIGNvbnRlbnRfbWVzc2FnaW5nXzEuZ2V0TWVzc2FnZUhhbmRsZXIpKCk7XG5leHBvcnRzLnN0b3JhZ2UgPSBuZXcgKC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBjbGFzc18xKCkge1xuICAgICAgICB0aGlzLnN0YXRlID0gbnVsbDtcbiAgICB9XG4gICAgY2xhc3NfMS5wcm90b3R5cGUuaW5pdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHN0YXRlO1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTdG9yYWdlOiBJbml0XCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuc3RhdGUgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiQWxyZWFkeSBpbml0aWFsaXNlZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJnZXQtc3RhdGVcIiwgeyB0eXBlOiAnZ2V0LXN0YXRlJywgc3RvcmU6ICdzdGF0ZScgfSldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZSA9IChfYS5zZW50KCkpLnN0YXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJJbml0aWFsIHN0b3JhZ2UgXCIsIHN0YXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBzdGF0ZSAhPT0gbnVsbCAmJiBzdGF0ZSAhPT0gdm9pZCAwID8gc3RhdGUgOiB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjbGFzc18xLnByb3RvdHlwZS5zZXQgPSBmdW5jdGlvbiAoa2V5LCB2YWx1ZSkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBfYjtcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2MpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9jLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU3RvcmFnZTogc2V0IFwiLCB7IGtleToga2V5LCB2YWx1ZTogdmFsdWUgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoISh0aGlzLnN0YXRlID09PSBudWxsKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCB0aGlzLmluaXQoKV07XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIF9jLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9jLmxhYmVsID0gMjtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOiByZXR1cm4gWzQgLyp5aWVsZCovLCBtZXNzYWdlSGFuZGxlci5zZW5kTWVzc2FnZVdSZXNwb25zZShcImJhY2tncm91bmRcIiwgXCJzZXQtc3RhdGVcIiwgeyB0eXBlOiAnc2V0LXN0YXRlJywgc3RvcmU6ICdzdGF0ZScsIGtleToga2V5LCB2YWx1ZTogdmFsdWUgfSldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgICAgICAgICBfYy5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlID0gX19hc3NpZ24oX19hc3NpZ24oe30sICgoX2EgPSB0aGlzLnN0YXRlKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB7fSkpLCAoX2IgPSB7fSwgX2Jba2V5XSA9IHZhbHVlLCBfYikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNsYXNzXzEucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChrZXksIHN5bmMpIHtcbiAgICAgICAgaWYgKHN5bmMgPT09IHZvaWQgMCkgeyBzeW5jID0gZmFsc2U7IH1cbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEodGhpcy5zdGF0ZSA9PT0gbnVsbCB8fCBzeW5jKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3luYykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU3RvcmFnZTogUmVmcmVzaGluZyBzdG9yYWdlIHN0YXRlXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5pbml0KCldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5zdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkVycm9yIG5vIHN0b3JhZ2Ugc3RhdGUgb2JqZWN0IGF2YWlsYWJsZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCB0aGlzLnN0YXRlW2tleV1dO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHJldHVybiBjbGFzc18xO1xufSgpKSkoKTtcbmV4cG9ydHMucmVnaXN0cmF0aW9ucyA9IG5ldyAoLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGNsYXNzXzIoKSB7XG4gICAgfVxuICAgIGNsYXNzXzIucHJvdG90eXBlLmZldGNoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciByZWdzO1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYikge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2IubGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCBleHBvcnRzLnN0b3JhZ2UuZ2V0KFwicmVnc1wiLCB0cnVlKV07XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZ3MgPSAoX2EgPSAoX2Iuc2VudCgpKSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDoge307XG4gICAgICAgICAgICAgICAgICAgICAgICByb290XzEubXlzb21lLnJlZ3MgPSByZWdzO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSZWdzXCIsIHJlZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIHJlZ3NdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNsYXNzXzIucHJvdG90eXBlLnNlbGVjdCA9IGZ1bmN0aW9uIChwbGF0Zm9ybSwgdXNlcklkKSB7XG4gICAgICAgIHZhciBfYSwgX2IsIF9jO1xuICAgICAgICB2YXIgcmVnID0gKF9jID0gKF9iID0gKF9hID0gcm9vdF8xLm15c29tZS5yZWdzKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2FbcGxhdGZvcm1dKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2JbdXNlcklkXSkgIT09IG51bGwgJiYgX2MgIT09IHZvaWQgMCA/IF9jIDogbnVsbDtcbiAgICAgICAgcmV0dXJuIHJlZztcbiAgICB9O1xuICAgIGNsYXNzXzIucHJvdG90eXBlLnNldFJlZ1N0ZXAgPSBmdW5jdGlvbiAocGxhdGZvcm0sIHVzZXJJZCwgc3RlcCkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYztcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIHJlZ3M7XG4gICAgICAgICAgICB2YXIgX2Q7XG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9lKSB7XG4gICAgICAgICAgICAgICAgc3dpdGNoIChfZS5sYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDA6IHJldHVybiBbNCAvKnlpZWxkKi8sIGV4cG9ydHMuc3RvcmFnZS5nZXQoXCJyZWdzXCIsIHRydWUpXTtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVncyA9IChfYSA9IChfZS5zZW50KCkpKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZ3NbcGxhdGZvcm1dID0gKF9kID0ge30sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX2RbdXNlcklkXSA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCAoKF9jID0gKF9iID0gcmVnc1twbGF0Zm9ybV0pID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYlt1c2VySWRdKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiB7fSkpLCB7IHN0ZXA6IHN0ZXAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX2QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcm9vdF8xLm15c29tZS5yZWdzID0gcmVnczsgLy8gdXBkYXRlZCByZWdzXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInN0b3JpbmcgbmV3IHJlZ3NcIiwgcmVncyk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCBleHBvcnRzLnN0b3JhZ2Uuc2V0KCdyZWdzJywgcmVncyldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICBfZS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qL107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIGNsYXNzXzI7XG59KCkpKTtcbmV4cG9ydHMucGxhdGZvcm1SZXF1ZXN0cyA9IG5ldyAoLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGNsYXNzXzMoKSB7XG4gICAgICAgIHRoaXMucGxhdGZvcm1SZXF1ZXN0cyA9IG51bGw7XG4gICAgfVxuICAgIGNsYXNzXzMucHJvdG90eXBlLmZldGNoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBzdG9yZTtcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9iLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnBsYXRmb3JtUmVxdWVzdHMgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgdGhpcy5wbGF0Zm9ybVJlcXVlc3RzXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU3RvcmFnZTogSW5pdFwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlV1Jlc3BvbnNlKFwiYmFja2dyb3VuZFwiLCBcImdldC1zdGF0ZVwiLCB7IHR5cGU6ICdnZXQtc3RhdGUnLCBzdG9yZTogJ3BsYXRmb3JtLXJlcXVlc3RzJyB9KV07XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0b3JlID0gKF9iLnNlbnQoKSkuc3RvcmU7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlBsYXRmb3JtIHJlcXVlc3RzIChsb2FkZWQgd2hlbiBpbml0aWFsaXNlZCkgXCIsIHN0b3JlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGxhdGZvcm1SZXF1ZXN0cyA9IChfYSA9IHN0b3JlID09PSBudWxsIHx8IHN0b3JlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzdG9yZS5hcnJheSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogW107XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5wbGF0Zm9ybVJlcXVlc3RzID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi8sIFtdXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovLCB0aGlzLnBsYXRmb3JtUmVxdWVzdHNdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNsYXNzXzMucHJvdG90eXBlLnJlbW92ZVJlcXVlc3QgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGtleSwgdmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgc3dpdGNoIChfYS5sYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMucGxhdGZvcm1SZXF1ZXN0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTGlzdCB3aGVyZSBub3QgaW5pdGlhbGlzZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGxhdGZvcm1SZXF1ZXN0cyA9IHRoaXMucGxhdGZvcm1SZXF1ZXN0cy5maWx0ZXIoZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHguaWQgIT09IGlkOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSA9ICdhcnJheSc7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IHRoaXMucGxhdGZvcm1SZXF1ZXN0cztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCAvKnlpZWxkKi8sIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlV1Jlc3BvbnNlKFwiYmFja2dyb3VuZFwiLCBcInNldC1zdGF0ZVwiLCB7IHR5cGU6ICdzZXQtc3RhdGUnLCBzdG9yZTogJ3BsYXRmb3JtLXJlcXVlc3RzJywga2V5OiBrZXksIHZhbHVlOiB2YWx1ZSB9KV07XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjbGFzc18zLnByb3RvdHlwZS5yZW1vdmVSZXF1ZXN0cyA9IGZ1bmN0aW9uIChwbGF0Zm9ybSkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIHJldHVybiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBrZXksIHZhbHVlLCBzdG9yZTtcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2IpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9iLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5wbGF0Zm9ybVJlcXVlc3RzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdMaXN0IHdoZXJlIG5vdCBpbml0aWFsaXNlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wbGF0Zm9ybVJlcXVlc3RzID0gdGhpcy5wbGF0Zm9ybVJlcXVlc3RzLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4geC5wbGF0Zm9ybSAhPT0gcGxhdGZvcm07IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5ID0gJ2FycmF5JztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gdGhpcy5wbGF0Zm9ybVJlcXVlc3RzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoXCJiYWNrZ3JvdW5kXCIsIFwic2V0LXN0YXRlXCIsIHsgdHlwZTogJ3NldC1zdGF0ZScsIHN0b3JlOiAncGxhdGZvcm0tcmVxdWVzdHMnLCBrZXk6IGtleSwgdmFsdWU6IHZhbHVlIH0pXTtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICAgICAgX2Iuc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoXCJiYWNrZ3JvdW5kXCIsIFwiZ2V0LXN0YXRlXCIsIHsgdHlwZTogJ2dldC1zdGF0ZScsIHN0b3JlOiAncGxhdGZvcm0tcmVxdWVzdHMnIH0pXTtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RvcmUgPSAoX2Iuc2VudCgpKS5zdG9yZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUGxhdGZvcm0gcmVxdWVzdHMgKGxvYWRlZCB3aGVuIGluaXRpYWxpc2VkKSBcIiwgc3RvcmUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wbGF0Zm9ybVJlcXVlc3RzID0gKF9hID0gc3RvcmUgPT09IG51bGwgfHwgc3RvcmUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHN0b3JlLmFycmF5KSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjbGFzc18zLnByb3RvdHlwZS5zZXQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGtleTtcbiAgICAgICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKF9hLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSA9ICdhcnJheSc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlBsYXRmb3JtIHJlcXVlc3RzOiBzZXQgXCIsIHsga2V5OiBrZXksIHZhbHVlOiB2YWx1ZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghKHRoaXMucGxhdGZvcm1SZXF1ZXN0cyA9PT0gbnVsbCkpIHJldHVybiBbMyAvKmJyZWFrKi8sIDJdO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0IC8qeWllbGQqLywgdGhpcy5mZXRjaCgpXTtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgX2EubGFiZWwgPSAyO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6IHJldHVybiBbNCAvKnlpZWxkKi8sIG1lc3NhZ2VIYW5kbGVyLnNlbmRNZXNzYWdlV1Jlc3BvbnNlKFwiYmFja2dyb3VuZFwiLCBcInNldC1zdGF0ZVwiLCB7IHR5cGU6ICdzZXQtc3RhdGUnLCBzdG9yZTogJ3BsYXRmb3JtLXJlcXVlc3RzJywga2V5OiBrZXksIHZhbHVlOiB2YWx1ZSB9KV07XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMiAvKnJldHVybiovXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjbGFzc18zLnByb3RvdHlwZS5zZXRTdGF0ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIga2V5O1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5ID0gJ2FycmF5JztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUGxhdGZvcm0gcmVxdWVzdHM6IHNldCBcIiwgeyBrZXk6IGtleSwgdmFsdWU6IHZhbHVlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEodGhpcy5wbGF0Zm9ybVJlcXVlc3RzID09PSBudWxsKSkgcmV0dXJuIFszIC8qYnJlYWsqLywgMl07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQgLyp5aWVsZCovLCB0aGlzLmZldGNoKCldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDI7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgMjogcmV0dXJuIFs0IC8qeWllbGQqLywgbWVzc2FnZUhhbmRsZXIuc2VuZE1lc3NhZ2VXUmVzcG9uc2UoXCJiYWNrZ3JvdW5kXCIsIFwic2V0LXN0YXRlXCIsIHsgdHlwZTogJ3NldC1zdGF0ZScsIHN0b3JlOiAncGxhdGZvcm0tcmVxdWVzdHMnLCBrZXk6IGtleSwgdmFsdWU6IHZhbHVlIH0pXTtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgX2Euc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyIC8qcmV0dXJuKi9dO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNsYXNzXzMucHJvdG90eXBlLnNlbGVjdCA9IGZ1bmN0aW9uIChwbGF0Zm9ybSwgc3RhdHVzLCByZXF1ZXN0VHlwZSkge1xuICAgICAgICByZXR1cm4gX19hd2FpdGVyKHRoaXMsIHZvaWQgMCwgdm9pZCAwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgYXJyYXksIHJlcXVlc3RzO1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAwOiByZXR1cm4gWzQgLyp5aWVsZCovLCB0aGlzLmZldGNoKCldO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBhcnJheSA9IF9hLnNlbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RzID0gYXJyYXkuZmlsdGVyKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4LnBsYXRmb3JtID09PSBwbGF0Zm9ybSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHguY3JlYXRlZCA+IG5ldyBEYXRlKCkuZ2V0VGltZSgpIC0gNjAwMDAgKiAzMCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHguc3RhdHVzID09PSBzdGF0dXMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB4LnJlcXVlc3RUeXBlID09PSByZXF1ZXN0VHlwZTsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzIgLypyZXR1cm4qLywgcmVxdWVzdHMgIT09IG51bGwgJiYgcmVxdWVzdHMgIT09IHZvaWQgMCA/IHJlcXVlc3RzIDogbnVsbF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIGNsYXNzXzM7XG59KCkpKSgpO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjLWNvbnRlbnQvaW5kZXgudHNcIik7XG4iLCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=