"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TEST = false;
var verbose = false;
var SERVICE_BASE_URL = function () { return TEST ? 'http://0.0.0.0:8080/v1' : "https://api.mysomeid.dev/v1"; };
var stores = {};
var initStore = function (storeName) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        storeName = storeName !== null && storeName !== void 0 ? storeName : 'state';
        console.log("initStore ", { storeName: storeName });
        return [2 /*return*/, new Promise(function (resolve) {
                chrome.storage.local.get(storeName, function (result) {
                    var _a;
                    console.log("Init ".concat(storeName, " store"), result === null || result === void 0 ? void 0 : result[storeName]);
                    if (!(result === null || result === void 0 ? void 0 : result[storeName])) {
                        console.log("Creating empty store");
                    }
                    stores[storeName] = (_a = result === null || result === void 0 ? void 0 : result[storeName]) !== null && _a !== void 0 ? _a : {};
                    resolve();
                });
            })];
    });
}); };
var fetchStore = function (storeName, allowCached) {
    if (allowCached === void 0) { allowCached = false; }
    return __awaiter(void 0, void 0, void 0, function () {
        return __generator(this, function (_a) {
            storeName = storeName !== null && storeName !== void 0 ? storeName : 'state';
            console.log("fetchStore ", { storeName: storeName, allowCached: allowCached });
            if (allowCached && stores[storeName] !== undefined) {
                return [2 /*return*/, stores[storeName]];
            }
            return [2 /*return*/, new Promise(function (resolve) {
                    chrome.storage.local.get(storeName, function (result) {
                        var _a;
                        var _b;
                        var store = __assign({}, ((_b = result === null || result === void 0 ? void 0 : result[storeName]) !== null && _b !== void 0 ? _b : {}));
                        stores[storeName] = store;
                        chrome.storage.local.set((_a = {}, _a[storeName] = store, _a), function () {
                            stores[storeName] = store;
                            resolve(store);
                        });
                    });
                })];
        });
    });
};
var saveStore = function (storeName, value) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        storeName = storeName !== null && storeName !== void 0 ? storeName : 'state';
        console.log("saveStore ", { storeName: storeName, value: value });
        return [2 /*return*/, new Promise(function (resolve) {
                var _a;
                // console.log("setting registration");
                chrome.storage.local.set((_a = {}, _a[storeName] = value, _a), function () {
                    stores[storeName] = value;
                    resolve();
                });
            })];
    });
}); };
var getCachedStore = function (storeName) {
    storeName = storeName !== null && storeName !== void 0 ? storeName : 'state';
    return stores[storeName];
};
var upsertStore = function (storeName, data) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        storeName = storeName !== null && storeName !== void 0 ? storeName : 'state';
        console.log("upsertStore ", { storeName: storeName, data: data });
        return [2 /*return*/, new Promise(function (resolve) {
                chrome.storage.local.get(storeName, function (result) {
                    var _a;
                    var _b;
                    var store = __assign(__assign({}, ((_b = result === null || result === void 0 ? void 0 : result[storeName]) !== null && _b !== void 0 ? _b : {})), (data !== null && data !== void 0 ? data : {}));
                    stores[storeName] = store;
                    chrome.storage.local.set((_a = {}, _a[storeName] = store, _a), function () {
                        stores[storeName] = store;
                        resolve(store);
                    });
                });
            })];
    });
}); };
chrome.runtime.onInstalled.addListener(function () {
    console.log("ChromeExtension: Installed");
    chrome.tabs.query({}, function (tabs) {
        tabs.map(function (tab) { return ({ tabId: tab.id, tabUrl: tab.url }); })
            .forEach(function (_a) {
            var tabId = _a.tabId, tabUrl = _a.tabUrl;
            // Reload tabs
            if (tabUrl.toLowerCase().indexOf('/create/1') >= 0 || tabUrl.indexOf('linkedin') >= 0) {
                chrome.tabs.reload(tabId);
            }
        });
    });
});
chrome.runtime.onMessage.addListener(function (request, sender, sendResponseImpl) {
    var _a;
    var _b, _c, _d, _e;
    var sendResponse = function (what) {
        verbose && console.log("Sending message ", what);
        return sendResponseImpl(what);
    };
    verbose && console.log("onMessage", {
        request: request,
        sender: sender,
        sendResponse: sendResponse,
    });
    var type = request.type, from = request.from, s = request.serial, payload = request.payload;
    var resp = function (s) { return "".concat(s, "-response"); };
    var serial = Math.round(Math.random() * 99999999999);
    var sendErrorResponse = function (msg) {
        sendResponse({
            to: from, from: 'background', type: resp(type),
            serial: serial,
            responseTo: s, origin: 'mysome', payload: {
                error: msg,
            }
        });
    };
    var sendAck = function () {
        verbose && console.log('send ack');
        sendResponse({});
    };
    if (type === 'validate-proof') {
        var _f = (_b = request === null || request === void 0 ? void 0 : request.payload) !== null && _b !== void 0 ? _b : {}, proofUrl = _f.proofUrl, firstName = _f.firstName, lastName = _f.lastName, platform = _f.platform, userData = _f.userData;
        if (platform !== 'li' || !proofUrl || !firstName || !lastName || !userData) {
            sendErrorResponse('invalid args');
            return;
        }
        var base = SERVICE_BASE_URL();
        proofUrl = encodeURIComponent(proofUrl);
        firstName = encodeURIComponent(firstName);
        lastName = encodeURIComponent(lastName);
        userData = encodeURIComponent(userData);
        var url = "".concat(base, "/proof/validate-proof-url?url=").concat(proofUrl, "&firstName=").concat(firstName, "&lastName=").concat(lastName, "&platform=").concat(platform, "&userData=").concat(userData);
        fetch(url).then(function (res) {
            return res.json();
        }).then(function (obj) {
            if (obj === null) {
                setTimeout(function () {
                    sendErrorResponse('no connection');
                });
            }
            else {
                setTimeout(function () {
                    sendResponse({
                        to: from,
                        from: 'background',
                        type: resp(type),
                        serial: serial,
                        responseTo: s,
                        origin: 'mysome',
                        payload: __assign({}, obj),
                    });
                });
            }
        });
        return true;
    }
    else if (type === 'reload-tabs') {
        var contains_1 = ((_c = request === null || request === void 0 ? void 0 : request.payload) !== null && _c !== void 0 ? _c : {}).contains;
        chrome.tabs.query({}, function (tabs) {
            tabs.map(function (tab) { return ({ tabId: tab.id, tabUrl: tab.url }); })
                .forEach(function (_a) {
                var tabId = _a.tabId, tabUrl = _a.tabUrl;
                if (tabUrl.toLowerCase().indexOf(contains_1 === null || contains_1 === void 0 ? void 0 : contains_1.toLowerCase())) {
                    chrome.tabs.reload(tabId);
                }
            });
        });
    }
    else if (type === 'update-registration') {
        (function () { return __awaiter(void 0, void 0, void 0, function () {
            var registrationState, platform, username, state, current, updated;
            var _a, _b, _c, _d, _e;
            return __generator(this, function (_f) {
                switch (_f.label) {
                    case 0:
                        registrationState = ((_a = request === null || request === void 0 ? void 0 : request.payload) !== null && _a !== void 0 ? _a : {}).state;
                        platform = registrationState.platform, username = registrationState.username;
                        if (!platform || typeof platform !== 'string') {
                            sendErrorResponse('No platform given');
                            return [2 /*return*/];
                        }
                        if (!username || typeof username !== 'string') {
                            sendErrorResponse('No username given');
                            return [2 /*return*/];
                        }
                        if (!registrationState || typeof registrationState !== 'object') {
                            sendErrorResponse('No state given');
                            return [2 /*return*/];
                        }
                        return [4 /*yield*/, fetchStore('state', true)];
                    case 1:
                        state = _f.sent();
                        // Make sure the state object contains at least an empty regs and object for the platform.
                        state.regs = (_b = state.regs) !== null && _b !== void 0 ? _b : {};
                        state.regs[platform] = (_c = state.regs[platform]) !== null && _c !== void 0 ? _c : {};
                        current = (_e = (_d = state === null || state === void 0 ? void 0 : state.regs[platform]) === null || _d === void 0 ? void 0 : _d[username]) !== null && _e !== void 0 ? _e : {};
                        updated = __assign(__assign({}, (current !== null && current !== void 0 ? current : {})), (registrationState !== null && registrationState !== void 0 ? registrationState : {}));
                        // update the state object with the update info.
                        state.regs[platform][username] = updated;
                        return [4 /*yield*/, saveStore('state', state)];
                    case 2:
                        _f.sent();
                        sendResponse({
                            state: state,
                            to: from,
                            from: 'background',
                            type: resp(type),
                            serial: serial,
                            responseTo: s,
                            origin: 'mysome'
                        });
                        console.log("Updated registrations ", state.regs);
                        return [2 /*return*/];
                }
            });
        }); })().then().catch(console.error);
        return true;
    }
    else if (type === "get-url") {
        var file = (_e = (_d = request === null || request === void 0 ? void 0 : request.payload) === null || _d === void 0 ? void 0 : _d.file) !== null && _e !== void 0 ? _e : '';
        if (!file) {
            console.error("No file given");
            sendErrorResponse('No file given');
            return;
        }
        var url = void 0;
        try {
            url = chrome.runtime.getURL(file);
        }
        catch (e) {
            console.error(e);
        }
        var payload_1 = {
            url: url,
        };
        sendResponse({
            to: from,
            from: 'background',
            type: resp(type),
            serial: serial,
            responseTo: s,
            origin: 'mysome',
            payload: payload_1
        });
        return;
    }
    else if (type === 'refresh-platform-pages') {
        // TODO: Loop through all tabs and refresh them.
        sendResponse({
            to: from,
            from: 'background',
            type: resp(type),
            serial: serial,
            responseTo: s,
            origin: 'mysome',
            payload: {}
        });
        return;
    }
    else if (type === 'get-state') {
        var storeName = (payload !== null && payload !== void 0 ? payload : {}).store;
        fetchStore(storeName, true).then(function (store) {
            sendResponse({
                state: store,
                store: store,
                to: from,
                from: 'background',
                type: resp(type),
                serial: serial,
                responseTo: s,
                origin: 'mysome'
            });
        });
        return true;
    }
    else if (type === 'set-state') {
        var _g = payload !== null && payload !== void 0 ? payload : {}, key = _g.key, value = _g.value, storeName = _g.store;
        upsertStore(storeName, (_a = {},
            _a[key] = value,
            _a)).then(function (store) {
            sendResponse({
                state: store,
                store: store,
                to: from,
                from: 'background',
                type: resp(type),
                serial: serial,
                responseTo: s,
                origin: 'mysome'
            });
        });
        return true;
    }
    else {
        console.warn("Sending default not recognised ack : " + type);
        sendResponse({});
    }
});
initStore('state').then(function () {
    if (stores.state['staging'] === undefined) {
        stores.state['staging'] = false;
    }
    TEST = stores.state ? stores.state['staging'] : null;
    console.log("Config: Test ", TEST);
});
initStore('platform-requests');
